BOW - Book Online  Web
===============================================================================================

O que é?
--------

Book Online Web - Sistema que se propõe a relatar os níveis de serviço prestados pelas Unidades de Negócio, possibilitando exibir uma visão de como o cliente final está sendo afetado, assim como auxiliar os envolvidos em tomada de decisão das suas respectivas Unidades de Negócio.

Este projeto esta desenvolvido utilizando o Apache Maven 3 e seus respectivos componentes com Java EE 8 and Spring. Utilizando o Wildfly Application Server 10.0 ou superior.

Este projeto é configurado para compilar com Java EE 8, a aplicação esta usando as seguintes tecnologias:

BackEnd - Hibernate 4.0, JPA 2.1 e Spring 4.2.RELEASE
FrontEnd - Boostrap 3, JavaScript, JSP, Apache Tiles 3.0
Servidor de Aplicação: WildFly 10.0
Banco de Dados: MySQL 5.5

Este projeto inclui controle de transação e unidade de persistencia para comunicação do Servidor de Aplicação com o banco de dados, através do `java:jboss/datasources/bowDS` configurado e implantado na aplicação.

* Em `spring-core-config.xml` `<context:component-scan base-package="br.com.netservicos.coti.bow" />` são usado para registrar todos os modelos, serviços, assim como os recursos utilizados no backend

* Em `spring-mvc-servlet.xml` `<context:component-scan base-package="br.com.netservicos.coti.bow" />` `<mvc:annotation-driven />` são usado para registrar todos os Controller, assim como configuração dos recursos utilizados no frontend.

* O mapa de Controller para suas respectivas url é utilizada o método `@RequestMapping(url)`

* O datasource and entitymanager são utilizados via JNDI.

Requisitos Obrigatórios
-----------------------

A aplicação foi produzida e desenhada para executar no WildFly 10.0 ou superior.

Para executar a aplicação segue os passos:

1. Baixar e instalar o Java 1.8, para executar o WildFly e Maven e IDE (Eclise ou JBoss Studio)
	* OpenJDK
    * Oracle Java SE
    * Oracle JRockit
	
2. Maven 3.3.9 ou superior, para realizar build and deploy da aplicação
	* Se você não tem instalado ou não conhece o Maven, segue o guia para maiores detalhes (http://maven.apache.org/guides/getting-started/index.html)
	* Se você tem instalado o Maven, é aconselhavél verificar qual versão se encontra instalado através do prompt executando o comando:
		
		mvn --version
		
3. O WildFly 10.0
	* Para informações onde instalar e executar o WildFly, segue referência (http://wildfly.org)
	

Configurando o Maven
--------------------

1. Caso não tenha criado, criar a pasta .m2 no diretório:
	
	PASTA_USUARIO_SISTEMA_OPERACIONAL/.m2

2. Caso não tenha criado, criar o arquivo settings.xml dentro da pasta .m2
	
	PASTA_USUARIO_SISTEMA_OPERACIONAL/.m2/settings.xml

3. Dentro do arquivo settings.xml colocar a seguinte configuração:
	
	<?xml version="1.0" encoding="UTF-8" standalone="no"?>
	<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 		xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 http://maven.apache.org/xsd/settings-1.0.0.xsd">
	
	</settings>


Start o WildFly
---------------

1. Abra a linha de comando e navegue até o diretório do WildFly.
2. Após abrir a linha de comando e navegar no diretório execute o arquivo:

        Para Linux:   JBOSS_HOME/bin/standalone.sh
        Para Windows: JBOSS_HOME\bin\standalone.bat

 
Build e Deploy o BOW
--------------------

_NOTA: Para realizar o build e deploy do projeto é necessário o seu Maven esta configurado. Se você não configurou o Maven, verifique configurar na guia (../README.md#Configurando o Maven).

1. Abra a linha de comando e navegue até o diretório do projeto
2. Após navegar no diretório, executar o seguinte comando:
	
	mvn clean package
	
3. o arquivo para deploy estará disponível `target/bow-app.ear` para executar na instância do servidor de aplicação.

Acesso a Aplicação
------------------

A aplicação será acessada através da seguinte URL: <http://localhost:8080/bow/>.


Executando e configurando a aplicação no JBoss Developer Studio ou Eclipse
--------------------------------------------------------------------------

1. Abra a sua IDE de preferência

2. Configurando Workspace
	* Clique na aba `Window`, logo em seguida em `Preferences`
	* Abra a guia `General`, logo em seguinda clique em `Workspace`
	* Modifique o encoding para UTF-8

3. Desabilitando as Validação
	* Clique na aba `Window`, logo em seguida em `Preferences`
	* Abra a guia `Validation`, logo em seguida `Disable All`
	
4. Importando o formatador de Classe
	* Clique na aba `Window`, logo em seguida em `Preferences`
	* Abra a guia `Java`, logo em seguida `formatter`
	* Importe o formatter (o mesmo se encontra no repositório do projeto)

5. Importe o projeto dentro da sua IDE executando os seguintes passos:
	* Clique na aba `Arquivo`, logo em seguinda em `import`
	* Navegue até a pasta `Maven`, logo em seguida `Existing Maven Project`
	* Selecione o diretório em que o projeto se encontra 
	* Finalize
