package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Operacao;
import br.com.netservicos.bow.service.PaggableSelect;

public interface OperacaoDAO extends Serializable {

    public List<Operacao> findAllAtivas();

    public void salvar(Operacao operacao);

    public Optional<Operacao> findById(Long id);

    public Integer deletar(Long id);

    public List<Operacao> findFetchAll();

    public Optional<Operacao> findByIdFetchAll(Long id);
    
    public List<Operacao> findByIds(List<Long> operacoesId);

    public Optional<Operacao> findByNome(String nome);
    
    public List<Operacao> findByPaggebleSelect(PaggableSelect paggable);
}
