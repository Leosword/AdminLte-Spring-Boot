package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.Optional;

import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

public interface TipoIndisponibilidadeEventoDAO extends Serializable {

    public Optional<TipoIndisponibilidadeEvento> findByNome(String nome);

}
