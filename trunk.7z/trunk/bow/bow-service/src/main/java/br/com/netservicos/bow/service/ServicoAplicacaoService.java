package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.dao.ServicoAplicacaoDAO;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.Servico;
import br.com.netservicos.bow.model.ServicoAplicacao;

@Service
public class ServicoAplicacaoService implements Serializable {

    private static final long serialVersionUID = -2993828375705274993L;

    private static final Logger LOGGER = LoggerFactory.getLogger(ServicoAplicacaoService.class);

    @Autowired
    private ServicoAplicacaoDAO servicoAplicacaoDAO;

    public List<ServicoAplicacao> findByAplicacoes(Long servicoId) {

        LOGGER.debug("Pesquisando a serviço com o Id: {}", servicoId);

        return servicoAplicacaoDAO.findByServicoId(servicoId);
    }

    public List<ServicoAplicacao> findByEmpresa(Empresa empresa, Servico servico) {

        LOGGER.debug("Pesquisando o serviço-aplicação com serviço: {} e empresa: {}", servico, empresa);

        return servicoAplicacaoDAO.findByEmpresa(empresa, servico);
    }

    public List<ServicoAplicacao> findByEmpresa(Empresa empresa) {

        LOGGER.debug("Pesquisando o serviço-aplicação para empresa: {}", empresa);

        return servicoAplicacaoDAO.findByEmpresa(empresa);
    }

}
