package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.dao.RegionalAplicacaoDAO;
import br.com.netservicos.bow.model.RegionalAplicacao;

@Service
public class RegionalAplicacaoService implements Serializable {

    private static final long serialVersionUID = -2378362750863843511L;

    private static final Logger LOGGER = LoggerFactory.getLogger(RegionalAplicacaoService.class);

    @Autowired
    private RegionalAplicacaoDAO regionalAplicacaoDAO;

    public List<RegionalAplicacao> findByAplicacoes(Long regionalId) {

        LOGGER.debug("Pesquisando a regional com o Id: {}", regionalId);

        return regionalAplicacaoDAO.findByRegionalId(regionalId);
    }

    public List<RegionalAplicacao> findByPaggebleSelect(PaggableSelect paggable) {

        LOGGER.debug("Pesquisando as regionais com aplicações com página: {}", paggable);

        return regionalAplicacaoDAO.findByPaggebleSelect(paggable);
    }

    public Optional<RegionalAplicacao> findFetchAllById(Long regionalAplicacaoId) {

        LOGGER.debug("Pesquisando a regional aplicação com Id: {}", regionalAplicacaoId);

        return regionalAplicacaoDAO.findFetchAllById(regionalAplicacaoId);
    }

}
