package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.service.PaggableSelect;

public interface RegionalDAO extends Serializable {

    public List<Regional> findAllAtivas();

    public void salvar(Regional regional);

    public Optional<Regional> findById(Long regionalId);

    public Optional<Regional> findByIdFetchAll(Long regionalId);

    public Integer deletar(Long regionalId);

    public List<Regional> findFetchAllAtivas();

    public Optional<Regional> findByNome(String nome, Empresa empresa);

    public List<Regional> findByPaggebleSelect(PaggableSelect paggable);

    public List<Regional> findByEmpresa(Empresa empresa);

}
