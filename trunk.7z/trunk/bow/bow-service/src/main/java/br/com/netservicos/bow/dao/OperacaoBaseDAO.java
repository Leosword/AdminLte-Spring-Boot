package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;

import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.OperacaoBase;

public interface OperacaoBaseDAO extends Serializable {

    public void salvar(List<OperacaoBase> operacoesBases);

    public List<OperacaoBase> findByOperacaoId(Long operacaoId);

    public Integer deleteFromOperacao(Long operacaoId);

    public List<OperacaoBase> findByBase(Base base);

}
