package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.dao.EstadoDAO;
import br.com.netservicos.bow.model.Cidade;
import br.com.netservicos.bow.model.Estado;

@Service
public class EstadoService implements Serializable {

    private static final long serialVersionUID = -6623497605460277995L;

    private static final Logger LOGGER = LoggerFactory.getLogger(EstadoService.class);

    @Autowired
    private EstadoDAO estadoDAO;

    public List<Estado> findByPaggebleSelect(PaggableSelect paggable) {

        LOGGER.debug("Pesquisando os estados com a pagina: {}", paggable);

        return estadoDAO.findByPaggebleSelect(paggable);
    }

    public Optional<Estado> findById(Long estadoId) {

        LOGGER.debug("Pesquisando o estado com Id: {}", estadoId);

        return estadoDAO.findById(estadoId);
    }

    public List<Estado> transform(List<Cidade> cidades) {

        Function<Cidade, Estado> cidadeFunction = new Function<Cidade, Estado>() {

            @Override
            public Estado apply(Cidade cidade) {
                return cidade.getEstado();
            }
        };

        List<Estado> estados = cidades.stream().map(cidadeFunction).collect(Collectors.<Estado> toList());

        return estados;
    }

}
