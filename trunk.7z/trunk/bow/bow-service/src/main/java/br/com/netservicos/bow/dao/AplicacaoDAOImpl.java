package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class AplicacaoDAOImpl implements AplicacaoDAO {

    private static final long serialVersionUID = -5882110561765536380L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<Aplicacao> findAll() {

        TypedQuery<Aplicacao> query = getEntityManager().createNamedQuery("Aplicacao.findAllAtivas", Aplicacao.class);

        return query.getResultList();
    }

    @Override
    public void persistir(Aplicacao aplicacao) {

        if (aplicacao.getId() == null) {

            getEntityManager().persist(aplicacao);

        } else {

            getEntityManager().merge(aplicacao);
        }

    }

    @Override
    public Long countByTipo(TipoAplicacao tipo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("select ");
        jpql.append("    count(aplicacao.id) as total ");
        jpql.append("from ");
        jpql.append("    Aplicacao as aplicacao ");
        jpql.append("    inner join aplicacao.tipo as tipo ");
        jpql.append("where ");
        jpql.append("    tipo.id = :tipoid ");

        Query query = getEntityManager().createQuery(jpql.toString());
        query.setParameter("tipoid", tipo.getId());

        return DAOUtil.getSingleResult(query);
    }

    @Override
    public List<Aplicacao> findByTipo(TipoAplicacao tipo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select aplicacao from Aplicacao aplicacao ");
        jpql.append("       inner join fetch aplicacao.tipo tipo ");
        jpql.append("       inner join fetch aplicacao.empresa as empresa ");
        jpql.append("           where tipo.id = :tipoId ");

        TypedQuery<Aplicacao> query = getEntityManager().createQuery(jpql.toString(), Aplicacao.class);

        query.setParameter("tipoId", tipo.getId());

        return query.getResultList();
    }

    @Override
    public List<Aplicacao> findByEmpresa(Empresa empresa, TipoAplicacao tipo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select aplicacao from Aplicacao aplicacao ");
        jpql.append("       inner join aplicacao.tipo tipo ");
        jpql.append("       inner join fetch aplicacao.empresa empresa ");
        jpql.append("           where tipo.id = :tipoId ");
        jpql.append("           and empresa.id = :empresaId ");

        TypedQuery<Aplicacao> query = getEntityManager().createQuery(jpql.toString(), Aplicacao.class);

        query.setParameter("tipoId", tipo.getId());
        query.setParameter("empresaId", empresa.getId());

        return query.getResultList();
    }

    @Override
    public List<Aplicacao> findByEmpresa(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select aplicacao from Aplicacao aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("       where aplicacao.descricao like :descricao ");
        jpql.append("       and empresa.id in (:empresaId) ");

        TypedQuery<Aplicacao> query = getEntityManager().createQuery(jpql.toString(), Aplicacao.class);

        query.setParameter("descricao", '%' + paggable.getTerm() + '%');
        query.setParameter("empresaId", paggable.getConvertValues());

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public List<Aplicacao> findFetchAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select aplicacao from Aplicacao aplicacao ");
        jpql.append("       inner join fetch aplicacao.tipo tipo ");
        jpql.append("       inner join fetch aplicacao.empresa empresa ");

        TypedQuery<Aplicacao> query = getEntityManager().createQuery(jpql.toString(), Aplicacao.class);

        return query.getResultList();
    }

    @Override
    public List<Aplicacao> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select aplicacao from Aplicacao aplicacao ");
        jpql.append("       inner join fetch aplicacao.empresa as empresa ");
        jpql.append("       where aplicacao.descricao like :descricao ");

        TypedQuery<Aplicacao> query = getEntityManager().createQuery(jpql.toString(), Aplicacao.class);

        query.setParameter("descricao", '%' + paggable.getTerm() + '%');

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public List<Aplicacao> findByIds(List<Long> aplicacoesId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select aplicacao from Aplicacao aplicacao ");
        jpql.append("   where aplicacao.id in (:aplicacoesId) ");

        TypedQuery<Aplicacao> query = getEntityManager().createQuery(jpql.toString(), Aplicacao.class);

        query.setParameter("aplicacoesId", aplicacoesId);

        return query.getResultList();
    }

    @Override
    public Optional<Aplicacao> findById(Long aplicacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select aplicacao from Aplicacao aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa empresa ");
        jpql.append("   where aplicacao.id = :aplicacaoId ");

        TypedQuery<Aplicacao> query = getEntityManager().createQuery(jpql.toString(), Aplicacao.class);

        query.setParameter("aplicacaoId", aplicacaoId);
        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
