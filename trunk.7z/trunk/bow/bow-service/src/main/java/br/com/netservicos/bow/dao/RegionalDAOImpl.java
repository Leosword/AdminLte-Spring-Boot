package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class RegionalDAOImpl implements RegionalDAO {

    private static final long serialVersionUID = 290001580240263697L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<Regional> findAllAtivas() {

        TypedQuery<Regional> query = getEntityManager().createNamedQuery("Regional.findAllAtivas", Regional.class);

        return query.getResultList();
    }

    @Override
    public void salvar(Regional regional) {

        if (regional.getId() == null) {

            getEntityManager().persist(regional);

        } else {

            getEntityManager().merge(regional);
        }
    }

    @Override
    public Integer deletar(Long regionalId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" update Regional set ");
        jpql.append("   status = :status ");
        jpql.append(" where id = :regionalId ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("status", false);
        query.setParameter("regionalId", regionalId);

        return query.executeUpdate();

    }

    @Override
    public Optional<Regional> findById(Long regionalId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select regional from Regional regional ");
        jpql.append(" where regional.id = :regionalId");

        TypedQuery<Regional> query = entityManager.createQuery(jpql.toString(), Regional.class);

        query.setParameter("regionalId", regionalId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<Regional> findFetchAllAtivas() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select regional from Regional regional ");
        jpql.append(" inner join fetch regional.empresa as empresa ");

        TypedQuery<Regional> query = entityManager.createQuery(jpql.toString(), Regional.class);

        return query.getResultList();
    }

    @Override
    public Optional<Regional> findByIdFetchAll(Long regionalId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select regional from Regional regional ");
        jpql.append(" inner join fetch regional.empresa as empresa ");
        jpql.append(" where regional.id = :regionalId");

        TypedQuery<Regional> query = entityManager.createQuery(jpql.toString(), Regional.class);

        query.setParameter("regionalId", regionalId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Regional> findByNome(String nome, Empresa empresa) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select regional from Regional regional ");
        jpql.append("   inner join regional.empresa as empresa ");
        jpql.append(" where regional.nome = :nome ");
        jpql.append("   and empresa.id = :empresaId ");

        TypedQuery<Regional> query = entityManager.createQuery(jpql.toString(), Regional.class);

        query.setParameter("nome", nome);
        query.setParameter("empresaId", empresa.getId());

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<Regional> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select regional from Regional regional ");
        jpql.append("       inner join fetch regional.empresa as empresa ");
        jpql.append("   where operacao.nome like :nome ");

        TypedQuery<Regional> query = getEntityManager().createQuery(jpql.toString(), Regional.class);

        query.setParameter("nome", '%' + paggable.getTerm() + '%');
        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public List<Regional> findByEmpresa(Empresa empresa) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select regional from Regional regional ");
        jpql.append("   inner join regional.empresa as empresa ");
        jpql.append(" where empresa.id = :empresaId ");

        TypedQuery<Regional> query = entityManager.createQuery(jpql.toString(), Regional.class);

        query.setParameter("empresaId", empresa.getId());

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
