package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.Servico;
import br.com.netservicos.bow.model.ServicoAplicacao;

public interface ServicoAplicacaoDAO extends Serializable {

    public void salvar(List<ServicoAplicacao> servicosAplicacoes);

    public List<ServicoAplicacao> findByServicoId(Long servicoId);

    public Integer deleteFromServico(Long servicoId);

    public List<ServicoAplicacao> findByEmpresa(Empresa empresa, Servico servico);

    public List<ServicoAplicacao> findByEmpresa(Empresa empresa);

}
