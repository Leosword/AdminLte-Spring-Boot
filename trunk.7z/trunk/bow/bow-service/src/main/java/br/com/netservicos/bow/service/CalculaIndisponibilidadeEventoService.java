package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.google.common.collect.Multimap;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.service.collector.MultimapCollector;

@Service
public class CalculaIndisponibilidadeEventoService implements Serializable {

    private static final long serialVersionUID = 1026424861180027329L;

    private static final Logger LOGGER = LoggerFactory.getLogger(CalculaIndisponibilidadeEventoService.class);

    private static final String POS_PATCH = "Pós-Patch";

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    public MinutosIndisponibilidade calculaMinutosBase(List<IndisponibilidadeEvento> indisponibilidadesEvento, String minutosDia) {

        Multimap<Base, IndisponibilidadeEvento> bases = indisponibilidadesEvento.stream()
                .filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getBase()))
                .collect(MultimapCollector.toMultimap(IndisponibilidadeEvento::getBase));

        List<BigDecimal> values = calculaPorBase(bases);

        BigDecimal percentual = values.stream().filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal percentualBase = NumberUtil.BIG_DECIMAL_CEM.subtract(percentual);

        BigDecimal totalMinutos = calculaTotalMinutos(percentualBase, minutosDia);

        BigDecimal minutos = converter.convert(totalMinutos);

        return new MinutosIndisponibilidade(minutos, percentual);
    }

    public MinutosIndisponibilidade calculaMinutosRegional(List<IndisponibilidadeEvento> indisponibilidadesEvento, String minutosDia) {

        Multimap<Regional, IndisponibilidadeEvento> regionais = indisponibilidadesEvento.stream()
                .filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getRegional()))
                .collect(MultimapCollector.toMultimap(IndisponibilidadeEvento::getRegional));

        List<BigDecimal> values = calculaPorRegional(regionais);

        BigDecimal percentual = values.stream().filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal percentualRegional = NumberUtil.BIG_DECIMAL_CEM.subtract(percentual);

        BigDecimal totalMinutos = calculaTotalMinutos(percentualRegional, minutosDia);

        BigDecimal minutos = converter.convert(totalMinutos);

        return new MinutosIndisponibilidade(minutos, percentual);
    }

    private List<BigDecimal> calculaPorRegional(Multimap<Regional, IndisponibilidadeEvento> regionais) {

        List<BigDecimal> values = new ArrayList<>();

        regionais.asMap().keySet().iterator().forEachRemaining(regional -> {

            Collection<IndisponibilidadeEvento> eventosIndisponiveis = regionais.get(regional);

            BigDecimal total = eventosIndisponiveis.stream().map(IndisponibilidadeEvento::getPercentualBase).reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal resultado = NumberUtil.BIG_DECIMAL_CEM.multiply(regional.getPeso()).subtract(total);

            values.add(resultado);
        });

        return values;
    }

    private List<BigDecimal> calculaPorBase(Multimap<Base, IndisponibilidadeEvento> bases) {

        List<BigDecimal> values = new ArrayList<>();

        bases.asMap().keySet().iterator().forEachRemaining(base -> {

            Collection<IndisponibilidadeEvento> eventosIndisponiveis = bases.get(base);

            BigDecimal total = eventosIndisponiveis.stream().map(IndisponibilidadeEvento::getPercentualBase).reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal resultado = NumberUtil.BIG_DECIMAL_CEM.multiply(base.getPeso()).subtract(total);

            values.add(resultado);
        });

        return values;
    }

    public MinutosIndisponibilidade calculaMinutosPosPatchBase(List<IndisponibilidadeEvento> indisponibilidades, String minutosDia) {

        Multimap<Base, IndisponibilidadeEvento> basesPosPatch = filterPosPatch(indisponibilidades);

        List<BigDecimal> valuesPosPatch = calculaPorBase(basesPosPatch);

        MinutosIndisponibilidade indisponibilidade = createIndisponibilidade(minutosDia, valuesPosPatch);

        return indisponibilidade;
    }

    public MinutosIndisponibilidade calculaMinutosPosPatchRegional(List<IndisponibilidadeEvento> indisponibilidades, String minutosDia) {

        Multimap<Regional, IndisponibilidadeEvento> regionaisPosPatch = indisponibilidades.stream()
                .filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getRegional())
                        && POS_PATCH.equals(indisponibilidade.getEvento().getOrigem().getDescricao()))
                .collect(MultimapCollector.toMultimap(IndisponibilidadeEvento::getRegional));

        List<BigDecimal> valuesPosPatch = calculaPorRegional(regionaisPosPatch);

        MinutosIndisponibilidade indisponibilidade = createIndisponibilidade(minutosDia, valuesPosPatch);

        return indisponibilidade;
    }

    private MinutosIndisponibilidade createIndisponibilidade(String minutosDia, List<BigDecimal> valuesPosPatch) {

        BigDecimal minutos = null;

        BigDecimal percentual = null;

        if (!CollectionUtil.isEmpty(valuesPosPatch)) {

            BigDecimal percentualPosPatch = valuesPosPatch.stream().filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);

            percentual = NumberUtil.BIG_DECIMAL_CEM.subtract(percentualPosPatch);

            BigDecimal totalMinutosPosPatch = calculaTotalMinutos(percentual, minutosDia);

            minutos = converter.convert(totalMinutosPosPatch);
        }

        return new MinutosIndisponibilidade(minutos, percentual);
    }

    private Multimap<Base, IndisponibilidadeEvento> filterPosPatch(List<IndisponibilidadeEvento> indisponibilidadesEvento) {

        return indisponibilidadesEvento.stream()
                .filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getBase())
                        && POS_PATCH.equals(indisponibilidade.getEvento().getOrigem().getDescricao()))
                .collect(MultimapCollector.toMultimap(IndisponibilidadeEvento::getBase));
    }

    private BigDecimal calculaTotalMinutos(BigDecimal percentualBase, String valor) throws BusinessException {

        BigDecimal totalMinutos = BigDecimal.ZERO;

        BigDecimal totalMinutosDia = new BigDecimal(valor);

        try {

            return totalMinutosDia.subtract(percentualBase.multiply(totalMinutosDia, MathContext.DECIMAL32).divide(NumberUtil.BIG_DECIMAL_CEM),
                    MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        } catch (ArithmeticException ae) {

            LOGGER.error("Erro ao realizar a operação de cálculo de Total de Minutos por Indisponbilidade de Aplicação com percentual: {}",
                    percentualBase);

            return totalMinutos;
        }
    }

}
