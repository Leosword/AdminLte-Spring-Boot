package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.TipoAplicacao;

public interface TipoAplicacaoDAO extends Serializable {

    public Optional<TipoAplicacao> findByAtivo(String nome);

    public List<TipoAplicacao> findByNomes(List<String> nomes);
}