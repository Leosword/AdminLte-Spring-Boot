package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Estado;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class EstadoDAOImpl implements EstadoDAO {

    private static final long serialVersionUID = -928522657267224557L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<Estado> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select estado from Estado estado ");
        jpql.append("       where estado.nome like :nome ");

        TypedQuery<Estado> query = getEntityManager().createQuery(jpql.toString(), Estado.class);

        query.setParameter("nome", '%' + paggable.getTerm() + '%');

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public Optional<Estado> findById(Long estadoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select estado from Estado estado ");
        jpql.append("       where estado.id = :estadoId ");

        TypedQuery<Estado> query = getEntityManager().createQuery(jpql.toString(), Estado.class);

        query.setParameter("estadoId", estadoId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
