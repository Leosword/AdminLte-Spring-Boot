package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Estado;
import br.com.netservicos.bow.service.PaggableSelect;

public interface EstadoDAO extends Serializable {

    public List<Estado> findByPaggebleSelect(PaggableSelect paggable);

    public Optional<Estado> findById(Long estadoId);

}
