package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Multimap;

import br.com.netservicos.bow.account.CalculaImpacto;
import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.dao.IndisponibilidadeEventoDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.ImapctoIndisponibilidadeParameter;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.model.ImpactoIndicadorEventoBook;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.Periodo;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;
import br.com.netservicos.bow.service.collector.MultimapCollector;

@Service
public class IndisponibilidadeEventoService implements Serializable {

    private static final long serialVersionUID = -7759504943022103356L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeEventoService.class);

    @Autowired
    private IndisponibilidadeAplicacaoService indispobilidadeAplicacaoService;

    @Autowired
    private IndisponibilidadeEventoDAO dao;

    @Autowired
    private ParametroService parametroService;

    @Transactional
    public void salvar(List<IndisponibilidadeEvento> indisponibilidades) {

        LOGGER.debug("Persistindo o total de indiponibilidade: {}", indisponibilidades.size());

        dao.salvar(indisponibilidades);
    }

    /**
     * <p>
     * Método responsavél por realizar consolidação dos eventos com Impacto é
     * um(a) ou todas operações ou cidades
     * </p>
     * 
     * @param impactoUma
     * @param impactoTodas
     * @param eventos
     */
    public void consolidar(CalculaImpacto impactoUma, CalculaImpacto impactoTodas, List<EventoClassificado> eventos) {

        Parametro parametro = parametroService.findByNome(ParametroConstants.MINUTOS_DIA);

        BigDecimal totalMinutosDia = new BigDecimal(parametro.getValor());

        Multimap<Aplicacao, EventoClassificado> aplicacoes = eventos.stream().collect(MultimapCollector.toMultimap(EventoClassificado::getAplicacao));

        List<IndisponibilidadeEvento> indisponibilidades = new ArrayList<>();

        try {

            aplicacoes.asMap().keySet().iterator().forEachRemaining(aplicacao -> {

                Collection<EventoClassificado> eventosAplicacao = aplicacoes.get(aplicacao);

                Multimap<TipoIndisponibilidadeEvento, EventoClassificado> tipos = eventosAplicacao.stream()
                        .collect(MultimapCollector.toMultimap(EventoClassificado::getTipoIndisponibilidade));

                tipos.asMap().keySet().iterator().forEachRemaining(tipo -> {

                    Collection<EventoClassificado> eventosPorTipo = tipos.get(tipo);

                    eventosPorTipo.forEach(evento -> {

                        Set<ImpactoIndicadorEvento> impactos = evento.getImpactosIndicador();

                        Multimap<Base, ImpactoIndicadorEvento> bases = impactos.stream()
                                .collect(MultimapCollector.toMultimap(ImpactoIndicadorEvento::getBase));

                        bases.asMap().keySet().iterator().forEachRemaining(base -> {

                            Collection<ImpactoIndicadorEvento> basesImpactadas = bases.get(base);

                            Set<ImpactoIndicadorEventoBook> impactosBook = collectImpactosBook(basesImpactadas);

                            Multimap<Date, ImpactoIndicadorEventoBook> dias = impactosBook.stream()
                                    .collect(MultimapCollector.toMultimap(ImpactoIndicadorEventoBook::getInicio));

                            dias.asMap().keySet().iterator().forEachRemaining(dia -> {

                                LOGGER.debug("Iniciando o processo de consolidação dos eventos com aplicação: {} para dia: {}", aplicacao, dia);

                                Collection<ImpactoIndicadorEventoBook> diasImpactados = dias.get(dia);

                                Integer duracao = diasImpactados.stream().mapToInt(ImpactoIndicadorEventoBook::getDuracao).sum();

                                List<BigDecimal> values = new ArrayList<>();

                                BigDecimal valorUma = impactoUma
                                        .calcula(new ImapctoIndisponibilidadeParameter(basesImpactadas, aplicacao, base, totalMinutosDia, dia));

                                BigDecimal valorTodas = impactoTodas
                                        .calcula(new ImapctoIndisponibilidadeParameter(basesImpactadas, totalMinutosDia, dia));

                                values.add(valorUma);

                                values.add(valorTodas);

                                BigDecimal percentualMinutos = values.stream().filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);

                                BigDecimal percentualBase = calculaIndisponibilidadePorPeso(percentualMinutos, base.getPeso());

                                atualizarPorEvento(evento, dia);

                                IndisponibilidadeEvento indisponibilidade = new IndisponibilidadeEvento(aplicacao, base, evento, tipo, duracao,
                                        percentualMinutos, percentualBase, dia);

                                LOGGER.debug("Finalizando o processo de consolidação dos eventos com indisponibilidade: {} para dia: {}",
                                        indisponibilidade, dia);

                                indisponibilidades.add(indisponibilidade);

                            });
                        });

                    });

                });

            });

            salvar(indisponibilidades);

            indispobilidadeAplicacaoService.consolidar(indisponibilidades);

        } catch (Exception ex) {

            LOGGER.error("Houve um erro! Não foi possível cálcula a indisponbilidade por Evento. Exception: {}", ex);

            throw new BusinessException("Houve um erro! Não foi possível calcular a indisponbilidade por Evento.", ex.getMessage());
        }
    }

    public Set<ImpactoIndicadorEventoBook> collectImpactosBook(Collection<ImpactoIndicadorEvento> basesImpactadas) {

        Set<ImpactoIndicadorEventoBook> impactosBook = new HashSet<>();

        basesImpactadas.forEach(impacto -> {

            impactosBook.addAll(impacto.getImpactosBook());

        });

        return impactosBook;
    }

    public void atualizarPorEvento(EventoClassificado evento, Date dia) {

        LOGGER.debug("Pesquisando a indisponibilidade de Evento para o evento: {}", evento);

        Optional<IndisponibilidadeEvento> indisponibilidadeEvento = dao.findByEvento(evento, dia);

        if (indisponibilidadeEvento.isPresent()) {

            IndisponibilidadeEvento indisponibilidade = indisponibilidadeEvento.get();

            indisponibilidade.setDesativacao(new Date());

            atualizar(indisponibilidade);
        }
    }

    public BigDecimal calculaIndisponibilidadePorPeso(BigDecimal minutos, BigDecimal valor) {

        BigDecimal percentualBase = BigDecimal.ZERO; // 100

        try {

            BigDecimal peso = valor.multiply(NumberUtil.BIG_DECIMAL_CEM, MathContext.DECIMAL32);

            BigDecimal resultado = minutos.divide(NumberUtil.BIG_DECIMAL_CEM).multiply(peso, MathContext.DECIMAL32);

            percentualBase = peso.subtract(resultado).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

            if (percentualBase.compareTo(BigDecimal.ZERO) == NumberUtil.MINUS_ONE) {

                LOGGER.warn("Valor negativo para o cálculo da Peso: {} e minutos: {}", valor, minutos);

                return BigDecimal.ZERO;
            }

        } catch (ArithmeticException ae) {

            LOGGER.error("Erro ao realizar operação de cálculo de Indiponibilidade com Peso: {} e minutos: {}", valor, minutos);

            return BigDecimal.ZERO;
        }

        return percentualBase;
    }

    public Optional<IndisponibilidadeEvento> findByBase(Base base, Aplicacao aplicacao, Date dia, TipoIndisponibilidadeEvento tipo) {

        LOGGER.debug("Pesquisando a indisponibilidae de evento para Base: {}, aplicação {}, dia: {}", base, aplicacao, dia);

        return dao.findByBase(base, aplicacao, dia, tipo);
    }

    public void atualizar(IndisponibilidadeEvento indisponibilidade) {

        LOGGER.debug("Atualizando a indisponbilidade do evento: {}", indisponibilidade);

        dao.atualizar(indisponibilidade);
    }

    public List<IndisponibilidadeEvento> findByPeriodo(Date inicio, Date fim) {

        LOGGER.debug("Pesquisando indisponbilidade do evento no periodo: {}, {}", inicio, fim);

        return dao.findByPeriodo(inicio, fim);
    }

    public List<IndisponibilidadeEvento> findByRegional(Regional regional, List<Aplicacao> aplicacoes, int mes, int ano) {

        LOGGER.debug("Pesquisando Eventos da regional: {}, para o mês: {} e ano: {}", regional, mes, ano);

        return dao.findByRegional(regional, aplicacoes, mes, ano);
    }

    public List<IndisponibilidadeEvento> findByRegional(Regional regional, Aplicacao aplicacao, int mes, int ano) {

        LOGGER.debug("Pesquisando Eventos da regional: {}, para o mês: {} e ano: {} e aplicacao: {}", regional, mes, ano, aplicacao);

        return dao.findByRegional(regional, aplicacao, mes, ano);
    }

    public List<IndisponibilidadeEvento> findByPeriodo(Integer ano, Integer mes, Empresa empresa) {

        LOGGER.debug("Pesquisando os Eventos para o ano: {}, mes: {} e empresa: {}", ano, mes, empresa);

        return dao.findByPeriodo(ano, mes, empresa);
    }

    public void remover(EventoClassificado evento) {

        LOGGER.debug("Desativando a indisponibilidade para o evento: {}", evento);

        dao.remover(evento);
    }

    public List<IndisponibilidadeEvento> findByPeriodoAplicacao(Aplicacao aplicacao, TipoIndisponibilidadeEvento tipo, Periodo periodo) {

        LOGGER.debug("Pesquisando as indisponibilidades dos eventos para Aplicação: {}, tipo: {} e periodo: {}", aplicacao, tipo, periodo);

        return dao.findByPeriodoAplicacao(aplicacao, tipo, periodo);
    }

    public Optional<IndisponibilidadeEvento> findByEvento(EventoClassificado evento) {

        LOGGER.debug("Pesquisando indisponibilidade com evento: {}", evento);

        return dao.findByEvento(evento);
    }
}