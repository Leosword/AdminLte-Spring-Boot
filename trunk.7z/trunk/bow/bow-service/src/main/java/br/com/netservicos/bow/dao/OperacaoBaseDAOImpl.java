package br.com.netservicos.bow.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.OperacaoBase;

@Repository
public class OperacaoBaseDAOImpl implements OperacaoBaseDAO {

    private static final long serialVersionUID = 3946528601614262889L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public void salvar(List<OperacaoBase> operacaoAplicacoes) {

        operacaoAplicacoes.forEach(operacaoBase -> {

            getEntityManager().persist(operacaoBase);
        });
    }

    @Override
    public Integer deleteFromOperacao(Long operacaoId) {

        StringBuilder jpqlBuilder = new StringBuilder();

        jpqlBuilder.append("delete from ");
        jpqlBuilder.append("    OperacaoBase operacaoBase ");
        jpqlBuilder.append(" where ");
        jpqlBuilder.append("    operacaoBase.operacao.id = :operacaoId  ");

        Query query = getEntityManager().createQuery(jpqlBuilder.toString());

        query.setParameter("operacaoId", operacaoId);

        return query.executeUpdate();
    }

    @Override
    public List<OperacaoBase> findByOperacaoId(Long operacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select operacaoBase from OperacaoBase operacaoBase ");
        jpql.append("   inner join fetch operacaoBase.base as base ");
        jpql.append("   inner join operacaoBase.operacao as operacao ");
        jpql.append(" where operacao.id = :operacaoId");

        TypedQuery<OperacaoBase> query = getEntityManager().createQuery(jpql.toString(), OperacaoBase.class);

        query.setParameter("operacaoId", operacaoId);

        return query.getResultList();
    }

    @Override
    public List<OperacaoBase> findByBase(Base base) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select operacaoBase from OperacaoBase operacaoBase ");
        jpql.append("   inner join operacaoBase.base as base ");
        jpql.append("   inner join fetch operacaoBase.operacao as operacao ");
        jpql.append(" where base.id = :baseId");

        TypedQuery<OperacaoBase> query = getEntityManager().createQuery(jpql.toString(), OperacaoBase.class);

        query.setParameter("baseId", base.getId());

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
