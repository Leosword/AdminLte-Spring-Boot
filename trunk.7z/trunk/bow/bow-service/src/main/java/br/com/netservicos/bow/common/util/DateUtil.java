package br.com.netservicos.bow.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public final class DateUtil {

    private DateUtil() {
        // Construtor padrão
    }

    public static Integer getYear(Date date) {

        Instant instant = Instant.ofEpochMilli(date.getTime());

        LocalDate localDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();

        return localDate.getYear();
    }

    public static Integer getMonth(Date date) {

        Instant instant = Instant.ofEpochMilli(date.getTime());

        LocalDate localDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();

        return localDate.getMonthValue();
    }

    public static LocalDate getLocalDate(Date date) {

        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static LocalDateTime getLocalDateTime(Date date) {

        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static Date getDate(LocalDate localDate) {

        return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date getDate(LocalDateTime localDateTime) {

        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date getDate(String date, String pattern) {

        SimpleDateFormat formatter = new SimpleDateFormat(pattern);

        try {

            return formatter.parse(date);

        } catch (ParseException e) {

            return null;
        }
    }

    public static Date firstDayOfMonth(Integer year, Integer month) {

        LocalDate localDate = LocalDate.of(year, month, NumberUtil.INTEGER_ONE);

        return Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    public static Boolean isSameDate(Date first, Date next) {

        LocalDate dateFirst = getLocalDate(first);

        LocalDate dateLast = getLocalDate(next);

        return dateFirst.equals(dateLast);
    }

}
