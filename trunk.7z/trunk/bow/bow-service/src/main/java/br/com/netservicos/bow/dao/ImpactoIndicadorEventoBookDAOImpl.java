package br.com.netservicos.bow.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.model.ImpactoIndicadorEventoBook;

@Repository
public class ImpactoIndicadorEventoBookDAOImpl implements ImpactoIndicadorEventoBookDAO {

    private static final long serialVersionUID = -3505256799877815860L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<ImpactoIndicadorEventoBook> findByImpactos(List<ImpactoIndicadorEvento> impactos) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select impacto from ImpactoIndicadorEventoBook impacto ");
        jpql.append("       inner join impacto.impactoIndicadorEvento impactoIndicadorEvento ");
        jpql.append("       where impactoIndicadorEvento in (:impactos) ");

        TypedQuery<ImpactoIndicadorEventoBook> query = getEntityManager().createQuery(jpql.toString(), ImpactoIndicadorEventoBook.class);

        query.setParameter("impactos", impactos);

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
