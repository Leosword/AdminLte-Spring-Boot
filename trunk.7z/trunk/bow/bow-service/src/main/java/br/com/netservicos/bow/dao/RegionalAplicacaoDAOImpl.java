package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.RegionalAplicacao;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class RegionalAplicacaoDAOImpl implements RegionalAplicacaoDAO {

    private static final long serialVersionUID = 8650012337736916786L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public void salvar(List<RegionalAplicacao> regionaisAplicacoes) {

        regionaisAplicacoes.forEach(regionalAplicacao -> {

            getEntityManager().persist(regionalAplicacao);
        });
    }

    @Override
    public Integer deleteFromRegional(Long regionalId) {

        StringBuilder jpqlBuilder = new StringBuilder();

        jpqlBuilder.append("update RegionalAplicacao regionalAplicacao set ");
        jpqlBuilder.append("    desativacao = :desativacao ");
        jpqlBuilder.append(" where ");
        jpqlBuilder.append("    regionalAplicacao.regional.id = :regionalId  ");

        Query query = getEntityManager().createQuery(jpqlBuilder.toString());

        query.setParameter("regionalId", regionalId);
        query.setParameter("desativacao", new Date());

        return query.executeUpdate();
    }

    @Override
    public List<RegionalAplicacao> findByRegionalId(Long regionalId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select regionalAplicacao from RegionalAplicacao regionalAplicacao ");
        jpql.append("   inner join fetch regionalAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join regionalAplicacao.regional as regional ");
        jpql.append(" where regional.id = :regionalId ");
        jpql.append(" and regionalAplicacao.desativacao is null ");

        TypedQuery<RegionalAplicacao> query = getEntityManager().createQuery(jpql.toString(), RegionalAplicacao.class);

        query.setParameter("regionalId", regionalId);

        return query.getResultList();
    }

    @Override
    public List<RegionalAplicacao> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select regionalAplicacao from RegionalAplicacao regionalAplicacao ");
        jpql.append("       inner join fetch regionalAplicacao.aplicacao as aplicacao ");
        jpql.append("       inner join fetch aplicacao.empresa as empresa ");
        jpql.append("       inner join fetch regionalAplicacao.regional as regional ");
        jpql.append("   where aplicacao.descricao like :descricao ");
        jpql.append("       and regionalAplicacao.desativacao is null ");

        TypedQuery<RegionalAplicacao> query = getEntityManager().createQuery(jpql.toString(), RegionalAplicacao.class);

        query.setParameter("descricao", '%' + paggable.getTerm() + '%');

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public Optional<RegionalAplicacao> findFetchAllById(Long regionalAplicacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select regionalaplicacao from RegionalAplicacao regionalaplicacao ");
        jpql.append("       inner join fetch regionalaplicacao.aplicacao ");
        jpql.append("       inner join fetch regionalaplicacao.regional ");
        jpql.append("       where regionalaplicacao.id = :regionalAplicacaoId ");

        TypedQuery<RegionalAplicacao> query = getEntityManager().createQuery(jpql.toString(), RegionalAplicacao.class);

        query.setParameter("regionalAplicacaoId", regionalAplicacaoId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<RegionalAplicacao> findById(Long regionalAplicacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select regionalaplicacao from RegionalAplicacao regionalaplicacao ");
        jpql.append("       where regionalaplicacao.id = :regionalAplicacaoId ");

        TypedQuery<RegionalAplicacao> query = getEntityManager().createQuery(jpql.toString(), RegionalAplicacao.class);

        query.setParameter("regionalAplicacaoId", regionalAplicacaoId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Integer deleteFromBase(Long regionalAplicacaoId) {

        StringBuilder jpqlBuilder = new StringBuilder();

        jpqlBuilder.append("update RegionalAplicacao regionalaplicacao set ");
        jpqlBuilder.append("    desativacao = :desativacao ");
        jpqlBuilder.append(" where ");
        jpqlBuilder.append("    regionalaplicacao.regional.id = :regionalAplicacaoId  ");

        Query query = getEntityManager().createQuery(jpqlBuilder.toString());

        query.setParameter("regionalAplicacaoId", regionalAplicacaoId);
        query.setParameter("desativacao", new Date());

        return query.executeUpdate();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}