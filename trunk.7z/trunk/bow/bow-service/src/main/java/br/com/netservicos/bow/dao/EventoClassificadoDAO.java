package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

public interface EventoClassificadoDAO extends Serializable {

    public List<EventoClassificado> findByAtivos();

    public List<EventoClassificado> findByFetchAllAtivos();

    public Set<EventoClassificado> findFetchAllByIds(List<Long> eventoIds);

    public EventoClassificado findFetchAllById(Long eventoId);

    public List<EventoClassificado> findByIds(List<Long> eventoIds);

    public void atualizar(EventoClassificado evento);

    public List<EventoClassificado> findUtimosSemAprovacao();

    public List<EventoClassificado> findByPeriodo(Date dia, Empresa empresa, TipoIndisponibilidadeEvento tipo);

}