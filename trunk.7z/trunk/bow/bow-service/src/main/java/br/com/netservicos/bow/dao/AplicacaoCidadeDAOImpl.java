package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoCidade;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.model.Cidade;

@Repository
public class AplicacaoCidadeDAOImpl implements AplicacaoCidadeDAO {

    private static final long serialVersionUID = 1355551050735736566L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<AplicacaoCidade> findAll() {

        TypedQuery<AplicacaoCidade> query = getEntityManager().createNamedQuery("AplicacaoCidade.findAll", AplicacaoCidade.class);

        return query.getResultList();
    }

    @Override
    public List<AplicacaoCidade> findFecthAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoCidade from AplicacaoCidade aplicacaoCidade ");
        jpql.append("   inner join fetch aplicacaoCidade.baseAplicacao as baseAplicacao ");
        jpql.append("   inner join fetch baseAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join fetch baseAplicacao.base as base ");
        jpql.append("   inner join fetch aplicacaoCidade.cidade as cidade ");
        jpql.append("   where aplicacaoCidade.desativacao is null ");

        TypedQuery<AplicacaoCidade> query = getEntityManager().createQuery(jpql.toString(), AplicacaoCidade.class);

        return query.getResultList();
    }

    @Override
    public void salvar(List<AplicacaoCidade> aplicacaoCidades) {

        aplicacaoCidades.forEach(aplicacaoCidade -> {

            getEntityManager().persist(aplicacaoCidade);
        });
    }

    @Override
    public Integer deletar(Long aplicacaoCidadeId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" update AplicacaoCidade set ");
        jpql.append("   desativacao = :desativacao ");
        jpql.append(" where id = :aplicacaoCidadeId ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("desativacao", new Date());
        query.setParameter("aplicacaoCidadeId", aplicacaoCidadeId);

        return query.executeUpdate();
    }

    @Override
    public Long findTotalByAplicacao(Base base, Aplicacao aplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select count(*) from AplicacaoCidade aplicacaoCidade ");
        jpql.append("   inner join aplicacaoCidade.baseAplicacao as baseAplicacao ");
        jpql.append("   inner join baseAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join baseAplicacao.base as base ");
        jpql.append("   inner join aplicacaoCidade.cidade as cidade ");
        jpql.append(" where aplicacaoCidade.desativacao is null ");
        jpql.append("   and base.id = :baseId ");
        jpql.append("   and aplicacao.id = :aplicacaoId ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("baseId", base.getId());
        query.setParameter("aplicacaoId", aplicacao.getId());

        return DAOUtil.getSingleResult(query);
    }

    @Override
    public Optional<AplicacaoCidade> findByBaseCidade(BaseAplicacao baseAplicacao, Cidade cidade) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoCidade from AplicacaoCidade aplicacaoCidade ");
        jpql.append("   inner join aplicacaoCidade.baseAplicacao as baseAplicacao ");
        jpql.append("   inner join aplicacaoCidade.cidade as cidade ");
        jpql.append(" where baseAplicacao.id = :baseAplicacaoId ");
        jpql.append("   and cidade.id = :cidadeId ");
        jpql.append("   and baseAplicacao.desativacao is null ");
        jpql.append("   and aplicacaoCidade.desativacao is null ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("baseAplicacaoId", baseAplicacao.getId());
        query.setParameter("cidadeId", cidade.getId());
        
        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
