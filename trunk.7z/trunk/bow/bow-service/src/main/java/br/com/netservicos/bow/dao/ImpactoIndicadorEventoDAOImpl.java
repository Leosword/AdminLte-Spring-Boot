package br.com.netservicos.bow.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.ImpactoIndicadorEvento;

@Repository
public class ImpactoIndicadorEventoDAOImpl implements ImpactoIndicadorEventoDAO {

    private static final long serialVersionUID = -6035716163606357310L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<ImpactoIndicadorEvento> findByEvento(Long eventoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select impacto from ImpactoIndicadorEvento impacto ");
        jpql.append("       inner join impacto.evento evento ");
        jpql.append("       left join fetch impacto.base base ");
        jpql.append("       left join fetch impacto.cidade cidade ");
        jpql.append("       left join fetch impacto.operacao operacao ");
        jpql.append("       left join fetch impacto.regional regional ");
        jpql.append("       inner join fetch impacto.impactosBook impactosBook ");
        jpql.append("   where evento.eventoId = :eventoId ");

        TypedQuery<ImpactoIndicadorEvento> query = getEntityManager().createQuery(jpql.toString(), ImpactoIndicadorEvento.class);

        query.setParameter("eventoId", eventoId);

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
