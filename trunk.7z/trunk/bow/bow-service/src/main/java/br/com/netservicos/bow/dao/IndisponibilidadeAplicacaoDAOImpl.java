package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacao;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

@Repository
public class IndisponibilidadeAplicacaoDAOImpl implements IndisponibilidadeAplicacaoDAO {

    private static final long serialVersionUID = 3098432506125076023L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public void salvar(IndisponibilidadeAplicacao indisponibilidade) {

        getEntityManager().persist(indisponibilidade);
    }

    @Override
    public Optional<IndisponibilidadeAplicacao> findByDia(Aplicacao aplicacao, Date dia, TipoIndisponibilidadeEvento tipo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacao indisponibilidade ");
        jpql.append("       inner join indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join indisponibilidade.tipoIndisponbilidade tipo ");
        jpql.append("   where aplicacao.id = :aplicacaoId ");
        jpql.append("       and tipo.id = :tipoId ");
        jpql.append("       and date(indisponibilidade.inicio) = :dia ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeAplicacao> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacao.class);

        query.setParameter("aplicacaoId", aplicacao.getId());
        query.setParameter("dia", dia);
        query.setParameter("tipoId", tipo.getId());

        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public void atualizar(IndisponibilidadeAplicacao indisponibilidadeAplicacao) {

        getEntityManager().merge(indisponibilidadeAplicacao);
    }

    @Override
    public List<IndisponibilidadeAplicacao> findByPeriodo(Date inicio, Date fim, List<Aplicacao> aplicacoes) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacao indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join fetch indisponibilidade.tipoIndisponbilidade tipoIndisponbilidade ");
        jpql.append("   where indisponibilidade.inicio between :inicio and :fim ");
        jpql.append("       and aplicacao in (:aplicacoes) ");
        jpql.append("       and indisponibilidade.desativacao is null ");
        jpql.append("       order by indisponibilidade.inicio asc ");

        TypedQuery<IndisponibilidadeAplicacao> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacao.class);

        query.setParameter("inicio", inicio, TemporalType.DATE);
        query.setParameter("fim", fim, TemporalType.DATE);
        query.setParameter("aplicacoes", aplicacoes);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeAplicacao> findByPeriodo(Date inicio, Date fim, Empresa empresa) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacao indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join aplicacao.empresa empresa ");
        jpql.append("       inner join fetch indisponibilidade.tipoIndisponbilidade tipoIndisponbilidade ");
        jpql.append("   where indisponibilidade.inicio between :inicio and :fim ");
        jpql.append("       and empresa.id = :empresaId ");
        jpql.append("       and indisponibilidade.desativacao is null ");
        jpql.append("       order by indisponibilidade.inicio asc ");

        TypedQuery<IndisponibilidadeAplicacao> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacao.class);

        query.setParameter("inicio", inicio, TemporalType.DATE);
        query.setParameter("fim", fim, TemporalType.DATE);
        query.setParameter("empresaId", empresa.getId());

        return query.getResultList();

    }

    @Override
    public List<IndisponibilidadeAplicacao> findByPeriodo(Integer ano, Integer mes, Aplicacao aplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacao indisponibilidade ");
        jpql.append("       inner join indisponibilidade.aplicacao aplicacao ");
        jpql.append("   where YEAR(indisponibilidade.inicio) = :ano ");
        jpql.append("       and MONTH(indisponibilidade.inicio) = :mes  ");
        jpql.append("       and aplicacao.id = :aplicacaoId ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeAplicacao> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacao.class);

        query.setParameter("aplicacaoId", aplicacao.getId());
        query.setParameter("ano", ano);
        query.setParameter("mes", mes);

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
