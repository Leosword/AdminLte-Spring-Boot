package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.Periodo;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

public interface IndisponibilidadeEventoDAO extends Serializable {

    public List<IndisponibilidadeEvento> findAll();

    public List<IndisponibilidadeEvento> findFetchAll();

    public void salvar(List<IndisponibilidadeEvento> consolidados);

    public void atualizar(IndisponibilidadeEvento indisponibilidade);

    public Optional<IndisponibilidadeEvento> findByBase(Base base, Aplicacao aplicacao, Date dia, TipoIndisponibilidadeEvento tipo);

    public Optional<IndisponibilidadeEvento> findByEvento(EventoClassificado evento, Date dia);

    public List<IndisponibilidadeEvento> findByPeriodo(Date inicio, Date fim);

    public List<IndisponibilidadeEvento> findByAplicacao(Date dia, Aplicacao aplicacao, TipoIndisponibilidadeEvento tipo);

    public List<IndisponibilidadeEvento> findByRegional(Regional regional, List<Aplicacao> aplicacoes, Integer mes, Integer ano);

    public List<IndisponibilidadeEvento> findByRegional(Regional regional, Aplicacao aplicacao, Integer mes, Integer ano);

    public List<IndisponibilidadeEvento> findByPeriodo(Integer ano, Integer mes, Empresa empresa);

    public Integer remover(EventoClassificado evento);

    public List<IndisponibilidadeEvento> findByPeriodoAplicacao(Aplicacao aplicacao, TipoIndisponibilidadeEvento tipo, Periodo periodo);

    public Optional<IndisponibilidadeEvento> findByEvento(EventoClassificado evento);
}
