package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Cidade;
import br.com.netservicos.bow.service.PaggableSelect;

public interface CidadeDAO extends Serializable {

    public Optional<Cidade> findById(Long cidadeId);

    public List<Cidade> findByPaggebleSelect(PaggableSelect paggable);

    public List<Cidade> findByBase(Long baseId);
    
    public List<Cidade> findByFetchAllBase(Long baseId);

    public List<Cidade> findByIds(List<Long> idCidades);
    
    public void merge(Cidade cidade);

}
