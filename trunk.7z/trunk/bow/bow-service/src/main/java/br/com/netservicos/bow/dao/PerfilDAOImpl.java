package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Perfil;

@Repository
public class PerfilDAOImpl implements PerfilDAO {

    private static final long serialVersionUID = -8077681451546646375L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<Perfil> findAll() {

        TypedQuery<Perfil> query = entityManager.createQuery("select perfil from Perfil perfil", Perfil.class);

        return query.getResultList();
    }

    @Override
    public void persistir(Perfil perfil) {

        entityManager.persist(perfil);
    }

    @Override
    public Optional<Perfil> findByNome(String nome) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select perfil from Perfil perfil ");
        jpql.append(" where perfil.nome = :nome");

        TypedQuery<Perfil> query = entityManager.createQuery(jpql.toString(), Perfil.class);

        query.setParameter("nome", nome);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

}
