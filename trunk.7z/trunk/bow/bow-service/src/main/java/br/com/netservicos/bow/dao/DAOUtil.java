package br.com.netservicos.bow.dao;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DAOUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(DAOUtil.class);

    private static final String EMPTY = "";

    private static final String LIKE_WILDCARD = "%";

    private DAOUtil() {
        // Utility class
    }

    @SuppressWarnings("unchecked")
    public static <T> T getSingleResult(Query query) {

        try {
            return (T) query.getSingleResult();
        } catch (NoResultException e) {
            LOGGER.debug("Not checked");
        }

        return null;

    }

    public static void setParameterMap(Query query, Map<String, Object> parameters) {
        for (Entry<String, Object> parameter : parameters.entrySet()) {
            query.setParameter(parameter.getKey(), parameter.getValue());
        }
    }

    public static String getLikeParameter(String value) {
        Optional<String> optional = Optional.ofNullable(value);

        if (!optional.isPresent()) {
            return LIKE_WILDCARD;
        }

        StringBuilder valueBuilder = new StringBuilder();

        valueBuilder.append(LIKE_WILDCARD);
        valueBuilder.append(optional.get().replaceAll(LIKE_WILDCARD, DAOUtil.EMPTY));
        valueBuilder.append(LIKE_WILDCARD);

        return valueBuilder.toString();
    }

    public static String getBeginWithParameter(String value) {

        Optional<String> optional = Optional.ofNullable(value);

        if (!optional.isPresent()) {
            return LIKE_WILDCARD;
        }

        StringBuilder valueBuilder = new StringBuilder();

        valueBuilder.append(optional.get().replaceAll(LIKE_WILDCARD, DAOUtil.EMPTY));
        valueBuilder.append(LIKE_WILDCARD);

        return valueBuilder.toString();
    }

    public static String getEndWithParameter(String value) {

        Optional<String> optional = Optional.ofNullable(value);
        
        if (!optional.isPresent()) {
            return LIKE_WILDCARD;
        }

        StringBuilder valueBuilder = new StringBuilder();

        valueBuilder.append(LIKE_WILDCARD);
        valueBuilder.append(value.replaceAll(LIKE_WILDCARD, DAOUtil.EMPTY));

        return valueBuilder.toString();
    }

}
