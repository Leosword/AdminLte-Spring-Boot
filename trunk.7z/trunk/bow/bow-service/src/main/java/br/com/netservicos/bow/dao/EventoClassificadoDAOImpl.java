package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

@Repository
public class EventoClassificadoDAOImpl implements EventoClassificadoDAO {

    private static final long serialVersionUID = 3581200401841383642L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<EventoClassificado> findByAtivos() {

        TypedQuery<EventoClassificado> query = getEntityManager().createNamedQuery("EventoClassificado.findAllAtivos", EventoClassificado.class);

        return query.getResultList();
    }

    @Override
    public void atualizar(EventoClassificado evento) {

        getEntityManager().merge(evento);
    }

    @Override
    public Set<EventoClassificado> findFetchAllByIds(List<Long> eventoIds) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select evento from EventoClassificado evento ");
        jpql.append("   inner join fetch evento.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join fetch aplicacao.tipo as tipo ");
        jpql.append("   inner join fetch evento.tipoIndisponibilidade as tipoIndisponibilidade ");
        jpql.append("   inner join fetch evento.impactosIndicador as impactosIndicador ");
        jpql.append("   inner join fetch impactosIndicador.impactosBook as impactosBook ");
        jpql.append("   left join fetch impactosIndicador.base as base ");
        jpql.append("   left join fetch impactosIndicador.cidade as cidade ");
        jpql.append("   left join fetch impactosIndicador.operacao as operacao ");
        jpql.append("   left join fetch impactosIndicador.regional as regional ");
        jpql.append(" where evento.id in (:eventoIds) ");
        jpql.append("   and evento.impactoContactRate = :impacto ");
        jpql.append("   and evento.aprovado is null ");
        jpql.append("   and evento.classificacao = :classificacao ");

        TypedQuery<EventoClassificado> query = getEntityManager().createQuery(jpql.toString(), EventoClassificado.class);

        query.setParameter("eventoIds", eventoIds);
        query.setParameter("impacto", true);
        query.setParameter("classificacao", NumberUtil.LONG_THREE);

        return new HashSet<>(query.getResultList());
    }

    public EventoClassificado findFetchAllById(Long eventoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select evento from EventoClassificado evento ");
        jpql.append("   inner join fetch evento.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join fetch evento.primario as ofensor ");
        jpql.append("   inner join fetch evento.grupo as grupo ");
        jpql.append("   inner join fetch aplicacao.tipo as tipo ");
        jpql.append("   inner join fetch evento.tipoIndisponibilidade as tipoIndisponibilidade ");
        jpql.append("   inner join fetch evento.impactosIndicador as impactosIndicador ");
        jpql.append("   left join fetch impactosIndicador.base as base ");
        jpql.append("   left join fetch impactosIndicador.cidade as cidade ");
        jpql.append("   left join fetch impactosIndicador.operacao as operacao ");
        jpql.append("   left join fetch impactosIndicador.regional as regional ");
        jpql.append(" where evento.eventoId = :eventoId ");

        TypedQuery<EventoClassificado> query = getEntityManager().createQuery(jpql.toString(), EventoClassificado.class);

        query.setParameter("eventoId", eventoId);

        return DAOUtil.getSingleResult(query);

    }

    @Override
    public List<EventoClassificado> findByFetchAllAtivos() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select evento from EventoClassificado evento ");
        jpql.append("   inner join fetch evento.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join fetch evento.grupo as grupo ");
        jpql.append("   inner join fetch evento.tipoIndisponibilidade as tipoIndisponibilidade ");
        jpql.append("   inner join fetch evento.origem as origem ");
        jpql.append("   inner join fetch evento.primario as ofensor ");
        jpql.append("   inner join fetch aplicacao.tipo as tipo ");
        jpql.append(" where evento.aprovado is null ");
        jpql.append("   and evento.impactoContactRate = :impacto ");
        jpql.append("   and evento.classificacao = :classificacao ");

        TypedQuery<EventoClassificado> query = getEntityManager().createQuery(jpql.toString(), EventoClassificado.class);

        query.setParameter("impacto", true);
        query.setParameter("classificacao", NumberUtil.LONG_THREE);

        return query.getResultList();
    }

    @Override
    public List<EventoClassificado> findByIds(List<Long> eventoIds) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select evento from EventoClassificado evento ");
        jpql.append(" where evento.id in (:eventoIds) ");
        jpql.append("   and evento.aprovado is null ");
        jpql.append("   and evento.impactoContactRate = :impacto ");
        jpql.append("   and evento.classificacao = :classificacao ");

        TypedQuery<EventoClassificado> query = getEntityManager().createQuery(jpql.toString(), EventoClassificado.class);

        query.setParameter("eventoIds", eventoIds);
        query.setParameter("impacto", true);
        query.setParameter("classificacao", NumberUtil.LONG_THREE);

        return query.getResultList();
    }

    @Override
    public List<EventoClassificado> findUtimosSemAprovacao() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select evento from EventoClassificado evento ");
        jpql.append("   inner join fetch evento.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join fetch aplicacao.tipo as tipo ");
        jpql.append("   inner join evento.tipoIndisponibilidade as tipoIndisponibilidade ");
        jpql.append("   inner join evento.origem as origem ");
        jpql.append("   inner join evento.primario as ofensor ");
        jpql.append("   inner join aplicacao.tipo as tipo ");
        jpql.append(" where evento.aprovado is null ");
        jpql.append("   and evento.impactoContactRate = :impacto ");
        jpql.append("   and evento.classificacao = :classificacao ");
        jpql.append("   order by evento.inicio desc ");

        TypedQuery<EventoClassificado> query = getEntityManager().createQuery(jpql.toString(), EventoClassificado.class);

        query.setParameter("impacto", true);
        query.setParameter("classificacao", NumberUtil.LONG_THREE);
        query.setMaxResults(NumberUtil.INTEGER_FIVE);

        return query.getResultList();
    }

    @Override
    public List<EventoClassificado> findByPeriodo(Date dia, Empresa empresa, TipoIndisponibilidadeEvento tipo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select evento from EventoClassificado evento ");
        jpql.append("   inner join fetch evento.aplicacao as aplicacao ");
        jpql.append("   inner join fetch evento.grupo as grupo");
        jpql.append("   inner join evento.tipoIndisponibilidade as tipo ");
        jpql.append("   inner join aplicacao.empresa as empresa ");
        jpql.append(" where DATE(evento.inicio) = :dia ");
        jpql.append("   and evento.impactoContactRate = :impacto ");
        jpql.append("   and evento.classificacao = :classificacao ");
        jpql.append("   and empresa.id = :empresaId ");
        jpql.append("   and tipo.id = :tipoId ");
        jpql.append("   order by evento.inicio desc ");

        TypedQuery<EventoClassificado> query = getEntityManager().createQuery(jpql.toString(), EventoClassificado.class);

        query.setParameter("impacto", true);
        query.setParameter("classificacao", NumberUtil.LONG_THREE);
        query.setParameter("empresaId", empresa.getId());
        query.setParameter("tipoId", tipo.getId());
        query.setParameter("dia", dia);

        return query.getResultList();

    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
