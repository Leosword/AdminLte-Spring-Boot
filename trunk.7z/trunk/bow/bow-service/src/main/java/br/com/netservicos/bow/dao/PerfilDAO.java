package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Perfil;

public interface PerfilDAO extends Serializable {

    public List<Perfil> findAll();

    public void persistir(Perfil Perfil);

    public Optional<Perfil> findByNome(String nome);
}
