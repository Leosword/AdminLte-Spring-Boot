package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.AplicacaoBookDAO;
import br.com.netservicos.bow.dao.AplicacaoDAO;
import br.com.netservicos.bow.dao.EmpresaDAO;
import br.com.netservicos.bow.dao.TipoAplicacaoDAO;
import br.com.netservicos.bow.dao.UsuarioDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.model.enums.TipoNivelServico;
import br.com.netservicos.bow.service.authetication.Principal;

@Service
public class AplicacaoBookService implements Serializable {

    private static final long serialVersionUID = -5523826474669796351L;

    private static final Logger LOGGER = LoggerFactory.getLogger(AplicacaoBookService.class);

    @Autowired
    private EmpresaDAO empresaDAO;

    @Autowired
    private AplicacaoBookDAO aplicacaoBookDAO;

    @Autowired
    private TipoAplicacaoDAO tipoAplicacaoDAO;

    @Autowired
    private AplicacaoDAO aplicacaoDAO;

    @Autowired
    private UsuarioDAO usuarioDAO;

    public List<AplicacaoBook> findFecthAll() {

        LOGGER.debug("Pesquisando todas as informações das aplicações");

        return aplicacaoBookDAO.findFecthAll();
    }

    @Transactional
    public void salvar(Integer tipoId, Long[] aplicacoesIds, Boolean slaGeral) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ((authentication instanceof AnonymousAuthenticationToken)) {

            throw new BusinessException("Não foi possível localizar usuário autenticado.");
        }

        Principal principal = (Principal) authentication.getPrincipal();

        Optional<Usuario> usuario = usuarioDAO.findByEmail(principal.getEmail());

        if (!usuario.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com email: {}", principal.getEmail());

            throw new BusinessException("Não foi possível localizar usuário");
        }

        TipoNivelServico tipoNivelServico = TipoNivelServico.getTipoNivelServico(tipoId);

        if (tipoNivelServico == null) {

            LOGGER.error("Não foi possível localizar o tipo com o Id: {}", tipoId);

            throw new BusinessException("Não foi possível localizar o tipo de SLA");
        }

        List<Aplicacao> aplicacoes = aplicacaoDAO.findByIds(Arrays.asList(aplicacoesIds));

        List<AplicacaoBook> aplicacoesBook = aplicacoes.stream()
                .map(aplicacao -> new AplicacaoBook(aplicacao, usuario.get(), tipoNivelServico, slaGeral)).collect(Collectors.toList());

        aplicacoesBook.forEach(aplicacaoBook -> {

            aplicacaoBookDAO.salvar(aplicacaoBook);
        });

    }

    @Transactional
    public void deletar(Long[] ids) {

        List<Long> aplicacoesBookIds = Arrays.asList(ids);

        LOGGER.debug("Removendo as aplicações book com Ids: {}", aplicacoesBookIds);

        aplicacaoBookDAO.deletar(aplicacoesBookIds);
    }

    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo, String nomeEmpresa, Boolean slaGeral) {

        Optional<Empresa> empresa = empresaDAO.findByNome(nomeEmpresa);

        if (!empresa.isPresent()) {

            LOGGER.error("Não foi possível localizar empresa com o nome: {}", nomeEmpresa);

            return Collections.emptyList();
        }

        LOGGER.debug("Pesquisando as aplicações que compõe book para o tipo: {}", tipo);

        return aplicacaoBookDAO.findFetchAllByTipo(tipo, empresa.get(), slaGeral);
    }

    public List<AplicacaoBook> findFetchAllByTipoComSla(TipoNivelServico tipo, String identificador, String nomeTipoAplicacao) {

        IdentificadorEmpresa identificadorEmpresa = IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(identificador));

        Optional<Empresa> empresa = empresaDAO.findByIdentificador(identificadorEmpresa);

        if (!empresa.isPresent()) {

            LOGGER.error("Não foi possível localizar empresa com o identificador: {}", identificador);

            return Collections.emptyList();
        }

        Optional<TipoAplicacao> tipoAplicacaoOptional = tipoAplicacaoDAO.findByAtivo(nomeTipoAplicacao);

        if (!tipoAplicacaoOptional.isPresent()) {

            LOGGER.error("Não foi possível localizar o tipo de Aplicação com o nome: {}", nomeTipoAplicacao);

            return Collections.emptyList();
        }

        LOGGER.debug("Pesquisando as aplicações que compõe book para o tipo: {}", tipo);

        return aplicacaoBookDAO.findFetchAllByTipoComSla(tipo, empresa.get(), tipoAplicacaoOptional.get());
    }

    public List<AplicacaoBook> findFetchAllByTipoComSla(TipoNivelServico tipo) {

        LOGGER.debug("Pesquisando as aplicações que compõe book para o tipo: {}", tipo);

        return aplicacaoBookDAO.findFetchAllByTipoComSla(tipo);
    }

    public List<AplicacaoBook> findFetchAllByTipos(List<TipoNivelServico> tiposNiveis, String identificador, List<String> tiposAplicacoes) {

        IdentificadorEmpresa identificadorEmpresa = IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(identificador));

        Optional<Empresa> empresa = empresaDAO.findByIdentificador(identificadorEmpresa);

        if (!empresa.isPresent()) {

            LOGGER.error("Não foi possível localizar empresa com o identificador: {}", identificador);

            return Collections.emptyList();
        }

        List<TipoAplicacao> tiposAplicacao = tipoAplicacaoDAO.findByNomes(tiposAplicacoes);

        LOGGER.debug("Pesquisando as aplicações que compõe book para a empresa: {}", empresa.get());

        return aplicacaoBookDAO.findFetchAllByTipos(tiposNiveis, empresa.get(), tiposAplicacao);
    }

    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo, String identificador, String nomeTipoAplicacao) {

        IdentificadorEmpresa identificadorEmpresa = IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(identificador));

        Optional<Empresa> empresa = empresaDAO.findByIdentificador(identificadorEmpresa);

        if (!empresa.isPresent()) {

            LOGGER.error("Não foi possível localizar empresa com o identificador: {}", identificador);

            return Collections.emptyList();
        }

        Optional<TipoAplicacao> tipoAplicacaoOptional = tipoAplicacaoDAO.findByAtivo(nomeTipoAplicacao);

        if (!tipoAplicacaoOptional.isPresent()) {

            LOGGER.error("Não foi possível localizar o tipo de Aplicação com o nome: {}", nomeTipoAplicacao);

            return Collections.emptyList();
        }

        LOGGER.debug("Pesquisando as aplicações que compõe book para o tipo: {}", tipo);

        return aplicacaoBookDAO.findFetchAllByTipo(tipo, empresa.get(), tipoAplicacaoOptional.get());
    }

    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo) {

        LOGGER.debug("Pesquisando as aplicações que compõe book para o tipo: {}", tipo);

        return aplicacaoBookDAO.findFetchAllByTipo(tipo);
    }

}
