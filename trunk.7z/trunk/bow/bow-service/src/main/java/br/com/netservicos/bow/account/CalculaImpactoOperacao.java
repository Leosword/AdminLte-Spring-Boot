package br.com.netservicos.bow.account;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.model.ImapctoIndisponibilidadeParameter;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.service.BaseAplicacaoOperacaoService;

@Component(value = "impactoUmaOperacao")
public class CalculaImpactoOperacao implements CalculaImpacto {

    private static final long serialVersionUID = 3882998118689949976L;

    private static final String IMPACTO_TODAS_NENHUMA = "TODAS OU NENHUMA";

    @Autowired
    private BaseAplicacaoOperacaoService service;

    @Autowired
    @Qualifier("calculaImpactoIndisponibilidade")
    private CalculaImpactoIndisponibilidade calculaImpactoIndisponibilidade;

    @Override
    public BigDecimal calcula(ImapctoIndisponibilidadeParameter dados) {

        List<ImpactoIndicadorEvento> impactos = dados.getImpactos().stream().filter(impacto -> houveImpacto(impacto)).collect(Collectors.toList());

        if (Iterables.isEmpty(impactos)) {

            return BigDecimal.ZERO;
        }

        Long total = service.totalByBase(dados.getBase(), dados.getAplicacao());

        return calculaImpactoIndisponibilidade.calcula(dados, impactos, total);
    }

    private boolean houveImpacto(ImpactoIndicadorEvento impacto) {

        boolean impactoOperacao = Objects.nonNull(impacto.getBase()) && Objects.nonNull(impacto.getOperacao());

        return impactoOperacao && !IMPACTO_TODAS_NENHUMA.equals(impacto.getOperacao().getNome());
    }

}
