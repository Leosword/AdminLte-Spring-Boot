package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.dao.AplicacaoCidadeDAO;
import br.com.netservicos.bow.dao.BaseAplicacaoDAO;
import br.com.netservicos.bow.dao.CidadeDAO;
import br.com.netservicos.bow.dao.UsuarioDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoCidade;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.model.Cidade;
import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.service.authetication.Principal;

@Service
public class AplicacaoCidadeService implements Serializable {

    private static final long serialVersionUID = 6751217869215546145L;

    private static final Logger LOGGER = LoggerFactory.getLogger(AplicacaoCidadeService.class);

    @Autowired
    private AplicacaoCidadeDAO dao;

    @Autowired
    private CidadeDAO cidadeDAO;

    @Autowired
    private BaseAplicacaoDAO baseAplicacaoDAO;

    @Autowired
    private UsuarioDAO usuarioDAO;

    public List<AplicacaoCidade> findAll() {

        LOGGER.debug("Pesquisando todos os registros da aplicação que tem vinculo com cidade");

        return dao.findAll();
    }

    public Long totalByBase(Base base, Aplicacao aplicacao) {

        LOGGER.debug("Pesquisando o total de cidades para Base: {} e Aplicação: {}", base, aplicacao);

        return dao.findTotalByAplicacao(base, aplicacao);
    }

    public List<AplicacaoCidade> findFecthAll() {

        LOGGER.debug("Pesquisando todas as as aplicações com cidade e base.");

        return dao.findFecthAll();
    }

    @Transactional
    public void salvar(Long baseAplicacaoId, Long[] cidadeIds) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ((authentication instanceof AnonymousAuthenticationToken)) {

            throw new BusinessException("Não foi possível localizar usuário autenticado.");
        }

        Principal principal = (Principal) authentication.getPrincipal();

        Optional<Usuario> usuario = usuarioDAO.findByEmail(principal.getEmail());

        if (!usuario.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com email: {}", principal.getEmail());

            throw new BusinessException("Não foi possível localizar usuário");
        }

        List<Cidade> cidades = cidadeDAO.findByIds(Arrays.asList(cidadeIds));

        if (Iterables.isEmpty(cidades)) {

            throw new BusinessException("Não foi possível localizar as cidades.");
        }

        Optional<BaseAplicacao> baseAplicacao = baseAplicacaoDAO.findById(baseAplicacaoId);

        if (!baseAplicacao.isPresent()) {

            throw new BusinessException("Não foi possível localizar a Aplicação");
        }

        List<AplicacaoCidade> aplicacaoCidades = new ArrayList<>();

        cidades.forEach(cidade -> {

            Optional<AplicacaoCidade> aplicacaoOperacaoOptional = dao.findByBaseCidade(baseAplicacao.get(), cidade);

            if (!aplicacaoOperacaoOptional.isPresent()) {

                AplicacaoCidade aplicacaoCidade = new AplicacaoCidade(baseAplicacao.get(), cidade, usuario.get());

                aplicacaoCidades.add(aplicacaoCidade);
            }
        });

        dao.salvar(aplicacaoCidades);
    }

    @Transactional
    public void deletar(Long[] ids) {

        if (Objects.isNull(ids)) {

            throw new BusinessException("Não foi possível localizar as informações corretas para excluir o(s) registro(s).");
        }

        LOGGER.debug("Removendo os registros com Ids: {}", new Object[] { ids });

        for (Long id : ids) {

            dao.deletar(id);
        }
    }

}
