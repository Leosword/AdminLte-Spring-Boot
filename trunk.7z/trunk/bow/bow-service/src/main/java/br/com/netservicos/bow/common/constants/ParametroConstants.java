package br.com.netservicos.bow.common.constants;

public final class ParametroConstants {

    public static final String MINUTOS_DIA = "parametro.servico.total.minutos.dia";

    public static final String BUSINESS_HOURS = "parametro.servico.total.business.hours";

    public static final String VALOR_SLA = "parametro.servico.sla";

    private ParametroConstants() {
        // Construtor padrão
    }

}
