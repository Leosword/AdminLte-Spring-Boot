package br.com.netservicos.bow.account;

import java.io.Serializable;
import java.math.BigDecimal;

import br.com.netservicos.bow.model.ImapctoIndisponibilidadeParameter;

public interface CalculaImpacto extends Serializable {

    public BigDecimal calcula(ImapctoIndisponibilidadeParameter dados);
}
