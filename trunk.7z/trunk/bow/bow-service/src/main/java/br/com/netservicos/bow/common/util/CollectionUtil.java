package br.com.netservicos.bow.common.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.util.CollectionUtils;

import com.google.common.collect.Sets;

public final class CollectionUtil extends CollectionUtils {

    /**
     * <p>
     * Metodo que verifica os elementos diferentes entre duas listas do mesmo
     * tipo.
     * </p>
     * 
     * @param valuesTo
     * @param valuesOf
     * @return new ArrayList<T>()
     */
    public static final <T> List<T> difference(List<T> valuesTo, List<T> valuesOf) {

        Set<T> toSet = Sets.newHashSet(valuesTo);

        Set<T> fromSet = Sets.newHashSet(valuesOf);

        Set<T> difference = Sets.difference(toSet, fromSet);

        return new ArrayList<T>(difference);
    }

    /**
     * <p>
     * Metodo que verifica os elementos iguais entre duas listas do mesmo tipo.
     * </p>
     * 
     * @param valuesTo
     * @param valuesOf
     * @return new ArrayList<T>()
     */
    public static final <T> List<T> intersection(List<T> valuesTo, List<T> valuesOf) {

        Set<T> toSet = Sets.newHashSet(valuesTo);

        Set<T> fromSet = Sets.newHashSet(valuesOf);

        Set<T> intersection = Sets.intersection(toSet, fromSet);

        return new ArrayList<T>(intersection);
    }
}
