package br.com.netservicos.bow.account;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import br.com.netservicos.bow.model.ImapctoIndisponibilidadeParameter;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;

@Component(value = "impactoTodasCidades")
public class CalculaImpactoTodasCidades implements CalculaImpacto {

    private static final long serialVersionUID = 7134536249061531727L;

    private static final String IMPACTO_TODAS_NENHUMA = "TODAS OU NENHUMA";

    @Autowired
    @Qualifier("calculaImpactoIndisponibilidade")
    private CalculaImpactoIndisponibilidade calculaImpactoIndisponibilidade;

    @Override
    public BigDecimal calcula(ImapctoIndisponibilidadeParameter dados) {

        List<ImpactoIndicadorEvento> impactos = dados.getImpactos().stream().filter(impacto -> houveImpacto(impacto))
                .collect(Collectors.toList());

        return calculaImpactoIndisponibilidade.calculaTodas(dados, impactos);
    }

    private boolean houveImpacto(ImpactoIndicadorEvento impacto) {

        boolean existe = impacto.getBase() != null && impacto.getCidade() != null;

        return existe && IMPACTO_TODAS_NENHUMA.equals(impacto.getCidade().getNome());
    }

}
