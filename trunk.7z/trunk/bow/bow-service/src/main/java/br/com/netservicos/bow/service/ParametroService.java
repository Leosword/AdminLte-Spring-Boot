package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.dao.ParametroDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Parametro;

@Service
public class ParametroService implements Serializable {

    private static final long serialVersionUID = -7965953429158094569L;

    private static final Logger LOGGER = LoggerFactory.getLogger(ParametroService.class);

    @Autowired
    private ParametroDAO parametroDAO;

    public Parametro findByNome(String nome) {

        LOGGER.debug("Pesquisando parametro com nome: {}", nome);

        Optional<Parametro> parametro = parametroDAO.findByNome(nome);

        if (!parametro.isPresent()) {

            LOGGER.error("Não foi possível localizar o parametro: {}", nome);

            throw new BusinessException("Não foi possível localizar o parametro: {}", nome);
        }

        return parametro.get();
    }
}
