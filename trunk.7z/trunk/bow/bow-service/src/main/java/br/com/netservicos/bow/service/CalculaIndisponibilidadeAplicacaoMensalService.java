package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.common.util.DateUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;

@Service
public class CalculaIndisponibilidadeAplicacaoMensalService implements Serializable {

    private static final long serialVersionUID = -1182498371030340363L;

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    private static final Logger LOGGER = LoggerFactory.getLogger(CalculaIndisponibilidadeAplicacaoMensalService.class);

    public BigDecimal calculaPercentual(BigDecimal totalMinutos, BigDecimal totalMinutosMes) {

        BigDecimal resultado = BigDecimal.ZERO;

        try {

            resultado = totalMinutos.divide(totalMinutosMes, MathContext.DECIMAL32).multiply(NumberUtil.BIG_DECIMAL_CEM, MathContext.DECIMAL32)
                    .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        } catch (ArithmeticException ae) {

            LOGGER.error(
                    "Não foi possível realizar operação. Erro ao realizar cálculo com valores [totalMinutos]: {}, [totalMinutosMes: {}]. Erro: {}",
                    totalMinutos, totalMinutosMes, ae);
        }

        return resultado;
    }

    public BigDecimal calculaPercentual(List<IndisponibilidadeAplicacaoMensal> indisponibilidades, Integer total, LocalDate periodo) {

        BigDecimal percentual = indisponibilidades.stream()
                .filter(indisponibilidade -> DateUtil.getLocalDate(indisponibilidade.getCriacao()).equals(periodo))
                .map(indisponibilidade -> indisponibilidade.getPercentualBase()).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal resultado = percentual.divide(new BigDecimal(total), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO,
                RoundingMode.HALF_EVEN);

        return resultado;
    }

    public BigDecimal calculaMinutos(List<IndisponibilidadeAplicacaoMensal> indisponibilidades, Integer total, LocalDate periodo) {

        BigDecimal totalMinutos = indisponibilidades.stream()
                .filter(indisponibilidade -> DateUtil.getLocalDate(indisponibilidade.getCriacao()).equals(periodo))
                .map(indisponibilidade -> indisponibilidade.getTotalMinutos()).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal minutosDisponiveis = converter.convert(totalMinutos);

        BigDecimal minutos = minutosDisponiveis.divide(new BigDecimal(total), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO,
                RoundingMode.HALF_EVEN);

        return converter.convert(minutos);
    }

    public BigDecimal calculaPercentualPosPatch(List<IndisponibilidadeAplicacaoMensal> indisponibilidades, Integer total, LocalDate periodo) {

        BigDecimal percentualBasePosPatch = indisponibilidades.stream()
                .filter(indisponibilidade -> DateUtil.getLocalDate(indisponibilidade.getCriacao()).equals(periodo)
                        && Objects.nonNull(indisponibilidade.getPercentualBasePosPatch()))
                .map(indisponibilidade -> indisponibilidade.getPercentualBasePosPatch()).reduce(BigDecimal.ZERO, BigDecimal::add);

        return percentualBasePosPatch.divide(new BigDecimal(total), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

    }

    public BigDecimal calculaMinutosPosPatch(List<IndisponibilidadeAplicacaoMensal> indisponibilidades, Integer total, LocalDate periodo) {

        BigDecimal minutosPosPatch = indisponibilidades.stream()
                .filter(indisponibilidade -> DateUtil.getLocalDate(indisponibilidade.getCriacao()).equals(periodo)
                        && Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch()))
                .map(indisponibilidade -> indisponibilidade.getTotalMinutosPosPatch()).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal minutos = minutosPosPatch.divide(new BigDecimal(total), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO,
                RoundingMode.HALF_EVEN);

        return converter.convert(minutos);
    }

    public String calculaMediaMinutos(List<IndisponibilidadeAplicacaoMensal> indisponibilidades) {

        try {

            int totalMes = LocalDate.now().getMonthValue();

            BigDecimal minutos = indisponibilidades.stream().filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getTotalMinutos()))
                    .map(indisponibilidade -> indisponibilidade.getTotalMinutos()).reduce(BigDecimal.ZERO, BigDecimal::add)
                    .divide(new BigDecimal(totalMes), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

            BigDecimal minutosTotal = converter.convert(minutos);

            return minutosTotal.toString();

        } catch (ArithmeticException ae) {

            LOGGER.error("Error ao realizar a media simples por mês das aplicações. Erro: {}", ae);

            return "";
        }
    }

    public String calculaMediaPercentual(List<IndisponibilidadeAplicacaoMensal> indisponibilidades) {

        try {

            int totalMes = LocalDate.now().getMonthValue();

            return indisponibilidades.stream().filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getPercentualBase()))
                    .map(indisponibilidade -> indisponibilidade.getPercentualBase()).reduce(BigDecimal.ZERO, BigDecimal::add)
                    .divide(new BigDecimal(totalMes), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN).toString();

        } catch (ArithmeticException ae) {

            LOGGER.error("Error ao realizar a media simples por mês das aplicações. Erro: {}", ae);

            return "";
        }
    }

    public String calculaMediaMinutosPosPatch(List<IndisponibilidadeAplicacaoMensal> indisponibilidades) {

        try {

            int totalMes = LocalDate.now().getMonthValue();

            BigDecimal minutos = indisponibilidades.stream().filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch()))
                    .map(indisponibilidade -> indisponibilidade.getTotalMinutosPosPatch()).reduce(BigDecimal.ZERO, BigDecimal::add)
                    .divide(new BigDecimal(totalMes), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

            BigDecimal minutosTotal = converter.convert(minutos);

            return minutosTotal.toString();

        } catch (ArithmeticException ae) {

            LOGGER.error("Error ao realizar a media simples por mês das aplicações. Erro: {}", ae);

            return "";
        }
    }

    public String calculaMediaPercentualPosPatch(List<IndisponibilidadeAplicacaoMensal> indisponibilidades) {

        try {

            int totalMes = LocalDate.now().getMonthValue();

            return indisponibilidades.stream().filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getPercentualBasePosPatch()))
                    .map(indisponibilidade -> indisponibilidade.getPercentualBasePosPatch()).reduce(BigDecimal.ZERO, BigDecimal::add)
                    .divide(new BigDecimal(totalMes), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN).toString();

        } catch (ArithmeticException ae) {

            LOGGER.error("Error ao realizar a media simples por mês das aplicações. Erro: {}", ae);

            return "";
        }
    }

    public BigDecimal calculaMinutosBusinessHours(String businessHours, String sla, Integer diasMes) {

        return new BigDecimal(diasMes).multiply(new BigDecimal(businessHours)).multiply(NumberUtil.TOTAL_MINUTOS_DAY).multiply(new BigDecimal(sla))
                .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);
    }

    public BigDecimal calculaPercentualBusinessHours(String businessHours, String sla, Integer diasMes) {

        BigDecimal totalMinutos = new BigDecimal(diasMes).multiply(new BigDecimal(businessHours)).multiply(NumberUtil.TOTAL_MINUTOS_DAY);

        BigDecimal limite = totalMinutos.multiply(new BigDecimal(sla)).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        return limite.divide(totalMinutos, MathContext.DECIMAL32).multiply(NumberUtil.BIG_DECIMAL_CEM).setScale(NumberUtil.INTEGER_TWO,
                RoundingMode.HALF_EVEN);
    }

}