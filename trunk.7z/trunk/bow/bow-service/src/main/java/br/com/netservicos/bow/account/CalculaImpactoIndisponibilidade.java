package br.com.netservicos.bow.account;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.common.util.DateUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.ImapctoIndisponibilidadeParameter;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.model.ImpactoIndicadorEventoBook;

@Component("calculaImpactoIndisponibilidade")
public class CalculaImpactoIndisponibilidade implements Serializable {

    private static final long serialVersionUID = -5524463081296993479L;

    private static final Logger LOGGER = LoggerFactory.getLogger(CalculaImpactoIndisponibilidade.class);

    public BigDecimal calcula(ImapctoIndisponibilidadeParameter dados, List<ImpactoIndicadorEvento> impactos, Long total) {

        if (NumberUtil.LONG_ZERO.equals(total)) {

            LOGGER.error("Não foi possível localizar o total para aplicação: {}", dados.getAplicacao());

            throw new BusinessException("Não foi possível localizar o total de impactos.");
        }

        List<BigDecimal> values = new ArrayList<>();

        Stream<ImpactoIndicadorEvento> impactosValidos = impactos.stream().filter(
                impacto -> impacto.getDuracao() != null && new BigDecimal(impacto.getDuracao()).compareTo(BigDecimal.ZERO) > NumberUtil.INTEGER_ZERO);

        impactosValidos.forEach(impacto -> {

            try {

                BigDecimal media = BigDecimal.ONE.divide(new BigDecimal(total), NumberUtil.INTEGER_FOUR, RoundingMode.HALF_EVEN);

                int totalMinutos = impacto.getImpactosBook().stream()
                        .filter(impactoBook -> DateUtil.isSameDate(impactoBook.getInicio(), dados.getDia()))
                        .mapToInt(ImpactoIndicadorEventoBook::getDuracao).sum();

                BigDecimal duracao = new BigDecimal(totalMinutos);

                BigDecimal resultado = duracao.divide(dados.getTotalMinutosDia(), MathContext.DECIMAL32).multiply(media, MathContext.DECIMAL32)
                        .multiply(NumberUtil.BIG_DECIMAL_CEM).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

                values.add(resultado);

            } catch (ArithmeticException ae) {

                LOGGER.error("Erro ao realizar operação de cálculo para Impacto em uma cidade: {}", ae);
            }

        });

        BigDecimal minutos = values.stream().reduce(BigDecimal.ZERO, BigDecimal::add);

        return minutos;
    }

    public BigDecimal calculaTodas(ImapctoIndisponibilidadeParameter dados, List<ImpactoIndicadorEvento> impactos) {

        if (Iterables.isEmpty(impactos)) {

            return BigDecimal.ZERO;
        }

        List<BigDecimal> values = new ArrayList<>();

        impactos.forEach(impacto -> {

            try {

                int total = impacto.getImpactosBook().stream().filter(impactoBook -> DateUtil.isSameDate(impactoBook.getInicio(), dados.getDia()))
                        .mapToInt(ImpactoIndicadorEventoBook::getDuracao).sum();

                BigDecimal duracao = new BigDecimal(total);

                BigDecimal resultado = duracao.divide(dados.getTotalMinutosDia(), MathContext.DECIMAL32)
                        .multiply(NumberUtil.BIG_DECIMAL_CEM, MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, BigDecimal.ROUND_DOWN);

                values.add(resultado);

            } catch (ArithmeticException ae) {

                LOGGER.error("Erro ao realizar operação de cálculo para Impacto é TODAS cidade: {}", ae);
            }

        });

        BigDecimal percentual = values.stream().reduce(BigDecimal.ZERO, BigDecimal::add);

        return percentual;
    }

}
