package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Usuario;

@Repository
public class UsuarioDAOImpl implements UsuarioDAO {

    private static final long serialVersionUID = -8077681451546646375L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<Usuario> findAll() {

        TypedQuery<Usuario> query = getEntityManager().createNamedQuery("Usuario.findAll", Usuario.class);

        return query.getResultList();
    }

    public List<Usuario> findFetchAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select new Usuario(usuario.id, usuario.nome, usuario.sobrenome, usuario.login, usuario.telefone, usuario.email, perfil.nome)");
        jpql.append("  from Usuario as usuario ");
        jpql.append(" inner join usuario.perfil as perfil");
        jpql.append(" where usuario.situacao = :situacao");

        TypedQuery<Usuario> query = getEntityManager().createQuery(jpql.toString(), Usuario.class);

        query.setParameter("situacao", true);

        return query.getResultList();
    }

    @Override
    public void persistir(Usuario usuario) {

        if (usuario.getId() == null) {

            getEntityManager().persist(usuario);

        } else {

            getEntityManager().merge(usuario);
        }
    }

    @Override
    public Optional<Usuario> findByEmail(String email) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select usuario from Usuario usuario ");
        jpql.append(" inner join fetch usuario.perfil perfil ");
        jpql.append(" where usuario.email = :email");

        TypedQuery<Usuario> query = getEntityManager().createQuery(jpql.toString(), Usuario.class);

        query.setParameter("email", email);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Usuario> findByLogin(String login) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select usuario from Usuario usuario ");
        jpql.append(" inner join fetch usuario.perfil perfil ");
        jpql.append(" where usuario.login = :login");

        TypedQuery<Usuario> query = getEntityManager().createQuery(jpql.toString(), Usuario.class);

        query.setParameter("login", login);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Integer deletar(Long id) {

        StringBuilder jpqlBuilder = new StringBuilder();

        jpqlBuilder.append("update Usuario set ");
        jpqlBuilder.append("    situacao = :status ");
        jpqlBuilder.append("where ");
        jpqlBuilder.append("    id = :id  ");

        Query query = getEntityManager().createQuery(jpqlBuilder.toString());

        query.setParameter("status", false);
        query.setParameter("id", id);

        return query.executeUpdate();
    }

    @Override
    public Optional<Usuario> findByIdFetchAll(Long id) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select usuario from Usuario usuario ");
        jpql.append(" inner join fetch usuario.perfil perfil ");
        jpql.append(" where usuario.id = :id");

        TypedQuery<Usuario> query = getEntityManager().createQuery(jpql.toString(), Usuario.class);

        query.setParameter("id", id);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<Usuario> findNomeUsuarioByPerfil(String nomePerfil) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select new Usuario(usuario.nome)");
        jpql.append("  from Usuario as usuario ");
        jpql.append(" inner join usuario.perfil as perfil");
        jpql.append(" where perfil.nome = :nomePerfil");

        TypedQuery<Usuario> query = getEntityManager().createQuery(jpql.toString(), Usuario.class);

        query.setParameter("nomePerfil", nomePerfil);

        return query.getResultList();
    }

    @Override
    public Optional<Usuario> findById(Long id) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select usuario from Usuario usuario ");
        jpql.append(" where usuario.id = :id");

        TypedQuery<Usuario> query = getEntityManager().createQuery(jpql.toString(), Usuario.class);

        query.setParameter("id", id);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
