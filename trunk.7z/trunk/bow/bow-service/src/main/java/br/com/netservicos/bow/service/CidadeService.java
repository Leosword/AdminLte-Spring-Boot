package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.dao.CidadeDAO;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.Cidade;

@Service
public class CidadeService implements Serializable {

    private static final long serialVersionUID = 2693817734215551115L;

    private static final Logger LOGGER = LoggerFactory.getLogger(CidadeService.class);

    @Autowired
    private CidadeDAO cidadeDAO;

    public List<Cidade> findByPaggebleSelect(PaggableSelect paggable) {

        LOGGER.debug("Pesquisando as cidades com a pagina: {}", paggable);

        return cidadeDAO.findByPaggebleSelect(paggable);
    }

    public Optional<Cidade> findById(Long cidadeId) {

        LOGGER.debug("Pesquisando a cidade com o Id: {}", cidadeId);

        return cidadeDAO.findById(cidadeId);
    }

    public List<Cidade> findByBase(Long baseId) {

        LOGGER.debug("Pesquisando as cidades que pertencem a base: {}", baseId);

        return cidadeDAO.findByBase(baseId);
    }

    public List<Cidade> findByFetchAllBase(Long baseId) {

        LOGGER.debug("Pesquisando as cidades que pertencem a base: {}", baseId);

        return cidadeDAO.findByFetchAllBase(baseId);
    }

    public void salvarCidadeBase(List<Long> idCidades, Base base) {

        List<Cidade> cidades = cidadeDAO.findByIds(idCidades);

        cidades.forEach(cidade -> {

            cidade.setBase(base);

            cidadeDAO.merge(cidade);
        });

    }

    public void atualizarCidadeBase(List<Long> idCidades, Base base) {

        List<Cidade> cidades = base.getCidades();

        if (!Iterables.isEmpty(cidades)) {

            cidades.forEach(cidade -> {

                cidade.setBase(null);

                cidadeDAO.merge(cidade);
            });

        }

        if (!Iterables.isEmpty(idCidades)) {

            salvarCidadeBase(idCidades, base);
        }

    }

}
