package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class BaseDAOImpl implements BaseDAO {

    private static final long serialVersionUID = -6411484531987670397L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<Base> findAllAtivas() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select base from Base base ");
        jpql.append(" where base.status = true ");
        jpql.append(" and base.nome != :todas ");

        TypedQuery<Base> query = getEntityManager().createQuery(jpql.toString(), Base.class);
        query.setParameter("todas", "TODAS OU NENHUMA");

        return query.getResultList();
    }

    public List<Base> findAll() {

        TypedQuery<Base> query = getEntityManager().createNamedQuery("Base.findAll", Base.class);

        return query.getResultList();
    }

    @Override
    public void salvar(Base base) {

        if (base.getId() == null) {

            getEntityManager().persist(base);

        } else {

            getEntityManager().merge(base);
        }
    }

    @Override
    public Integer deletar(Long baseId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" update Base set ");
        jpql.append("   status = :status ");
        jpql.append(" where id = :baseId ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("status", false);
        query.setParameter("baseId", baseId);

        return query.executeUpdate();

    }

    @Override
    public Optional<Base> findById(Long baseId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select base from Base base ");
        jpql.append(" where base.id = :baseId");

        TypedQuery<Base> query = entityManager.createQuery(jpql.toString(), Base.class);

        query.setParameter("baseId", baseId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Base> findByFetchAll(Long baseId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select base from Base base ");
        jpql.append(" left join fetch base.cidades as cidade ");
        jpql.append(" left join fetch cidade.estado as estado ");
        jpql.append(" where base.id = :baseId");

        TypedQuery<Base> query = entityManager.createQuery(jpql.toString(), Base.class);

        query.setParameter("baseId", baseId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Base> findByFetchCidade(Long id) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select base from Base base ");
        jpql.append(" left join fetch base.cidades as cidade ");
        jpql.append(" where base.id = :baseId");

        TypedQuery<Base> query = entityManager.createQuery(jpql.toString(), Base.class);

        query.setParameter("baseId", id);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Base> findByNome(String nome) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select base from Base base ");
        jpql.append(" where base.nome = :nome");

        TypedQuery<Base> query = entityManager.createQuery(jpql.toString(), Base.class);

        query.setParameter("nome", nome);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<Base> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select base from Base base ");
        jpql.append("       where base.nome like :nome ");

        TypedQuery<Base> query = getEntityManager().createQuery(jpql.toString(), Base.class);

        query.setParameter("nome", '%' + paggable.getTerm() + '%');

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public List<Base> findByIds(List<Long> baseIds) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select base from Base base ");
        jpql.append("   where base.id in (:baseIds) ");

        TypedQuery<Base> query = getEntityManager().createQuery(jpql.toString(), Base.class);

        query.setParameter("baseIds", baseIds);

        return query.getResultList();

    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
