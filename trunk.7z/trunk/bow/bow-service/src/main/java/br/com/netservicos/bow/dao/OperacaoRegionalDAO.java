package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Operacao;
import br.com.netservicos.bow.model.OperacaoRegional;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.RegionalAplicacao;

public interface OperacaoRegionalDAO extends Serializable {

    public List<OperacaoRegional> findAll();

    public List<OperacaoRegional> findFecthAll();

    public Integer deletar(Long id);

    public void salvar(List<OperacaoRegional> aplicacaoOperacoes);

    public Long findTotalByAplicacao(Regional regional, Aplicacao aplicacao);

    public Optional<OperacaoRegional> findByRegionalAplicacao(RegionalAplicacao regionalAplicacao, Operacao operacao);

}