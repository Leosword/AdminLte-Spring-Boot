package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.dao.BaseAplicacaoOperacaoDAO;
import br.com.netservicos.bow.dao.BaseAplicacaoDAO;
import br.com.netservicos.bow.dao.OperacaoDAO;
import br.com.netservicos.bow.dao.UsuarioDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.BaseAplicacaoOperacao;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.model.Operacao;
import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.service.authetication.Principal;

@Service
public class BaseAplicacaoOperacaoService implements Serializable {

    private static final long serialVersionUID = 968188677356649735L;

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseAplicacaoOperacaoService.class);

    @Autowired
    private BaseAplicacaoOperacaoDAO dao;

    @Autowired
    private OperacaoDAO operacaoDAO;

    @Autowired
    private BaseAplicacaoDAO baseAplicacaoDAO;

    @Autowired
    private UsuarioDAO usuarioDAO;

    public List<BaseAplicacaoOperacao> findAll() {

        LOGGER.debug("Pesquisando todos os registros da aplicação que tem vinculo com operação");

        return dao.findAll();
    }

    public Long totalByBase(Base base, Aplicacao aplicacao) {

        LOGGER.debug("Pesquisando o total de operações para Base: {} e Aplicação: {}", base, aplicacao);

        return dao.findTotalByAplicacao(base, aplicacao);
    }

    public List<BaseAplicacaoOperacao> findFecthAll() {

        LOGGER.debug("Pesquisando todas as as aplicações com operação e base.");

        return dao.findFecthAll();
    }

    @Transactional
    public void salvar(Long baseAplicacaoId, Long[] operacoesIds) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ((authentication instanceof AnonymousAuthenticationToken)) {

            throw new BusinessException("Não foi possível localizar usuário autenticado.");
        }

        Principal principal = (Principal) authentication.getPrincipal();

        Optional<Usuario> usuario = usuarioDAO.findByEmail(principal.getEmail());

        if (!usuario.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com email: {}", principal.getEmail());

            throw new BusinessException("Não foi possível localizar usuário");
        }

        List<Operacao> operacoes = operacaoDAO.findByIds(Arrays.asList(operacoesIds));

        if (Iterables.isEmpty(operacoes)) {

            LOGGER.error("Não foi possível localizar as operações com os Ids: {}", new Object[] { operacoesIds });

            throw new BusinessException("Não foi possível localizar as operações.");
        }

        Optional<BaseAplicacao> baseAplicacaoOptional = baseAplicacaoDAO.findById(baseAplicacaoId);

        if (!baseAplicacaoOptional.isPresent()) {

            throw new BusinessException("Não foi possível localizar a Aplicação");
        }

        List<BaseAplicacaoOperacao> aplicacaoOperacaos = new ArrayList<>();

        BaseAplicacao baseAplicacao = baseAplicacaoOptional.get();

        operacoes.forEach(operacao -> {

            Optional<BaseAplicacaoOperacao> aplicacaoOperacaoOptional = dao.findByBaseAplicacao(baseAplicacao, operacao);

            if (!aplicacaoOperacaoOptional.isPresent()) {

                BaseAplicacaoOperacao aplicacaoOperacao = new BaseAplicacaoOperacao(baseAplicacao, operacao, usuario.get());

                aplicacaoOperacaos.add(aplicacaoOperacao);
            }

        });

        dao.salvar(aplicacaoOperacaos);
    }

    public Long totalByAplicacao(Base base, Aplicacao aplicacao) {

        LOGGER.debug("Pesquisando o total de operacoes para Base: {} e Aplicação: {}", base, aplicacao);

        return dao.findTotalByAplicacao(base, aplicacao);
    }

    @Transactional
    public void deletar(Long[] ids) {

        if (Objects.isNull(ids)) {

            throw new BusinessException("Não foi possível localizar as informações corretas para excluir o(s) registro(s).");
        }

        LOGGER.debug("Removendo os registros com Ids: {}", new Object[] { ids });

        for (Long id : ids) {

            dao.deletar(id);
        }
    }

}
