package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.BaseAplicacaoOperacao;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.model.Operacao;

public interface BaseAplicacaoOperacaoDAO extends Serializable {

    public List<BaseAplicacaoOperacao> findAll();

    public List<BaseAplicacaoOperacao> findFecthAll();

    public Integer deletar(Long id);

    public void salvar(List<BaseAplicacaoOperacao> aplicacaoOperacoes);

    public Long findTotalByAplicacao(Base base, Aplicacao aplicacao);

    public Optional<BaseAplicacaoOperacao> findByBaseAplicacao(BaseAplicacao baseAplicacao, Operacao operacao);

}