package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.Optional;

import br.com.netservicos.bow.model.Parametro;

public interface ParametroDAO extends Serializable {

    public Optional<Parametro> findByNome(String nome);

}
