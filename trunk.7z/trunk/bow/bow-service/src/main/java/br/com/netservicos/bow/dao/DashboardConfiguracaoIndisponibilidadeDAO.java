package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.DashboardConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.enums.TipoConfiguracaoIndisponibilidade;

public interface DashboardConfiguracaoIndisponibilidadeDAO extends Serializable {

    public List<DashboardConfiguracaoIndisponibilidade> findFecthAll();

    public void salvar(DashboardConfiguracaoIndisponibilidade configuracao);

    public Integer deletar(List<Long> configuracaoIds);

    public Optional<DashboardConfiguracaoIndisponibilidade> findByEmpresa(Empresa empresa, TipoConfiguracaoIndisponibilidade tipo, Date data);

    public List<DashboardConfiguracaoIndisponibilidade> findByEmpresa(Empresa empresa, Date data);

}
