package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.AplicacaoDAO;
import br.com.netservicos.bow.dao.ServicoAplicacaoDAO;
import br.com.netservicos.bow.dao.ServicoDAO;
import br.com.netservicos.bow.dao.UsuarioDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Servico;
import br.com.netservicos.bow.model.ServicoAplicacao;
import br.com.netservicos.bow.model.Usuario;

@Service
public class ServicoService implements Serializable {

    private static final long serialVersionUID = -9193842430530189609L;

    private static final Logger LOGGER = LoggerFactory.getLogger(ServicoService.class);

    @Autowired
    private ServicoDAO servicoDAO;

    @Autowired
    private AplicacaoDAO aplicacaoDAO;

    @Autowired
    private ServicoAplicacaoDAO servicoAplicacaoDAO;

    @Autowired
    private UsuarioDAO usuarioDAO;

    public List<Servico> findAllAtivas() {

        LOGGER.debug("Pesquisando todas as servicos ativas");

        return servicoDAO.findAllAtivas();
    }

    @Transactional
    public void salvar(Servico servico, Long[] aplicacoesIds, String email) {

        LOGGER.debug("Pesquisando o serviço com nome: {}", servico.getNome());

        Optional<Servico> nomeOptional = servicoDAO.findByNome(servico.getNome());

        if (nomeOptional.isPresent()) {

            LOGGER.error("Serviço com o nome: {} já encontra cadastrada", servico.getNome());

            throw new BusinessException("Não foi possível continuar com o cadastro. Nome do serviço já possui cadastro");
        }

        LOGGER.debug("Pesquisando o usuário com email: {}", email);

        Optional<Usuario> usuario = usuarioDAO.findByEmail(email);

        if (!usuario.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com email: {}", email);

            throw new BusinessException("Não foi possível localizar usuário.");
        }

        LOGGER.debug("Persistindo o serviço: {}", servico);

        servicoDAO.salvar(servico);

        List<ServicoAplicacao> servicosAplicacoes = new ArrayList<>();

        LOGGER.debug("Pesquisando as aplicações com Ids: {}", new Object[] { aplicacoesIds });

        List<Aplicacao> aplicacoes = aplicacaoDAO.findByIds(Arrays.asList(aplicacoesIds));

        aplicacoes.forEach(aplicacao -> {

            servicosAplicacoes.add(new ServicoAplicacao(servico, aplicacao, usuario.get()));
        });

        LOGGER.debug("Persistindo as aplicações e o serviço: {}", servicosAplicacoes);

        servicoAplicacaoDAO.salvar(servicosAplicacoes);
    }

    @Transactional
    public void atualizar(Servico servico, Long[] aplicacoesIds, String email) {

        Optional<Usuario> usuario = usuarioDAO.findByEmail(email);

        if (!usuario.isPresent()) {

            throw new BusinessException("Não foi possível localizar usuário com Email: {}");
        }

        servicoDAO.salvar(servico);

        servicoAplicacaoDAO.deleteFromServico(servico.getId());

        List<ServicoAplicacao> servicosAplicacoes = new ArrayList<>();

        List<Aplicacao> aplicacoes = aplicacaoDAO.findByIds(Arrays.asList(aplicacoesIds));

        aplicacoes.forEach(aplicacao -> {

            ServicoAplicacao servicoAplicacao = new ServicoAplicacao(servico, aplicacao, usuario.get());

            servicosAplicacoes.add(servicoAplicacao);
        });

        servicoAplicacaoDAO.salvar(servicosAplicacoes);
    }

    public Optional<Servico> findById(Long id) {

        LOGGER.debug("Pesquisando a servico com o Id: {}", id);

        return servicoDAO.findById(id);
    }

    @Transactional
    public void deletar(Long[] ids) {

        if (Objects.isNull(ids)) {

            throw new BusinessException("Não foi possível localizar as informações corretas para excluir o(s) registro(s).");
        }

        LOGGER.debug("Removendo os registros com Ids: {}", new Object[] { ids });

        for (Long id : ids) {

            servicoDAO.deletar(id);
        }

    }

}
