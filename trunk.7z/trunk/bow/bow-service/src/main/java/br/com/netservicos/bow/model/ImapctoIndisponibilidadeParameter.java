package br.com.netservicos.bow.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

import com.google.common.base.MoreObjects;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;

public class ImapctoIndisponibilidadeParameter implements Serializable {

    private static final long serialVersionUID = -7077498173107692124L;

    private Collection<ImpactoIndicadorEvento> impactos;

    private Integer duracao;

    private Aplicacao aplicacao;

    private Base base;

    private Regional regional;

    private BigDecimal totalMinutosDia;

    private Date dia;
    
    public ImapctoIndisponibilidadeParameter() {
        // Construtor padrão
    }

    public ImapctoIndisponibilidadeParameter(Collection<ImpactoIndicadorEvento> impactosBase, BigDecimal totalMinutosDia, Date dia) {
        this.impactos = impactosBase;
        this.totalMinutosDia = totalMinutosDia;
        this.dia = dia;
    }

    public ImapctoIndisponibilidadeParameter(Collection<ImpactoIndicadorEvento> impactosBase, Aplicacao aplicacao, Base base,
            BigDecimal totalMinutosDia, Date dia) {
        this.impactos = impactosBase;
        this.aplicacao = aplicacao;
        this.base = base;
        this.totalMinutosDia = totalMinutosDia;
        this.dia = dia;
    }

    public ImapctoIndisponibilidadeParameter(Collection<ImpactoIndicadorEvento> impactosBase, Aplicacao aplicacao, Regional regional,
            BigDecimal totalMinutosDia, Date dia) {
        this.impactos = impactosBase;
        this.aplicacao = aplicacao;
        this.regional = regional;
        this.totalMinutosDia = totalMinutosDia;
        this.dia = dia;
    }

    public Collection<ImpactoIndicadorEvento> getImpactos() {
        return impactos;
    }

    public void setImpactos(Collection<ImpactoIndicadorEvento> impactos) {
        this.impactos = impactos;
    }

    public Aplicacao getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(Aplicacao aplicacao) {
        this.aplicacao = aplicacao;
    }

    public Base getBase() {
        return base;
    }

    public void setBase(Base base) {
        this.base = base;
    }

    public Regional getRegional() {
        return regional;
    }

    public void setRegional(Regional regional) {
        this.regional = regional;
    }

    public BigDecimal getTotalMinutosDia() {
        return totalMinutosDia;
    }

    public void setTotalMinutosDia(BigDecimal totalMinutosDia) {
        this.totalMinutosDia = totalMinutosDia;
    }

    public Integer getDuracao() {
        return duracao;
    }

    public void setDuracao(Integer duracao) {
        this.duracao = duracao;
    }

    public Date getDia() {
        return dia;
    }

    public void setDia(Date dia) {
        this.dia = dia;
    }

    @Override
    public String toString() {

        return MoreObjects.toStringHelper(this).add("Aplicação: ", aplicacao).add("Base: ", base).add("Dia: ", dia).toString();
    }

}
