package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;

import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.model.ImpactoIndicadorEventoBook;

public interface ImpactoIndicadorEventoBookDAO extends Serializable {

    public List<ImpactoIndicadorEventoBook> findByImpactos(List<ImpactoIndicadorEvento> impactos);

}
