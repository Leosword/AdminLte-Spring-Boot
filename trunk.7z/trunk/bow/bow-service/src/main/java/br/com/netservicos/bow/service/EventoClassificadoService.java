package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.dao.EventoClassificadoDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

@Service
public class EventoClassificadoService implements Serializable {

    private static final long serialVersionUID = -2972750810495810161L;

    private static final Logger LOGGER = LoggerFactory.getLogger(EventoClassificadoService.class);

    @Autowired
    private IndisponibilidadeEventoBaseService indisponibilidadeBaseService;
    
    @Autowired
    private IndisponibilidadeEventoRegionalService indisponibilidadeEventoRegionalService;

    @Autowired
    private EventoClassificadoDAO eventoClassificadoDAO;

    public List<EventoClassificado> findByAtivos() {

        LOGGER.debug("Pesquisando todos os eventos classificados ativos.");

        return eventoClassificadoDAO.findByAtivos();
    }

    public List<EventoClassificado> findByFetchAllAtivos() {

        LOGGER.debug("Pesquisando todos os eventos classificados ativos.");

        return eventoClassificadoDAO.findByFetchAllAtivos();
    }

    public List<EventoClassificado> findUtimosSemAprovacao() {

        LOGGER.debug("Pesquisando todos os eventos classificados ativos.");

        return eventoClassificadoDAO.findUtimosSemAprovacao();
    }

    @Transactional
    public void aprovar(Long[] eventoIds) {

        LOGGER.debug("Pesquisando todos os eventos a serem classificados com os Ids: {}.", new Object[] { eventoIds });

        Set<EventoClassificado> eventosClassificados = eventoClassificadoDAO.findFetchAllByIds(Arrays.asList(eventoIds));

        if (CollectionUtil.isEmpty(eventosClassificados)) {

            LOGGER.error("Não foi possível localizar os eventos seleciondos: {}", new Object[] { eventoIds });

            throw new BusinessException("Não foi possível localizar os eventos selecionados.");
        }

        List<EventoClassificado> eventos = eventosClassificados.stream().collect(Collectors.toList());

        indisponibilidadeBaseService.consolidar(eventos);
        
        indisponibilidadeEventoRegionalService.consolidar(eventos);

        atualizar(eventos, true);
    }

    @Transactional
    public void reprovar(Long[] eventoIds) {

        List<EventoClassificado> eventos = eventoClassificadoDAO.findByIds(Arrays.asList(eventoIds));

        atualizar(eventos, false);
    }

    public void atualizar(List<EventoClassificado> eventos, boolean aprovado) {

        eventos.forEach(evento -> {

            evento.setAprovado(aprovado);

            eventoClassificadoDAO.atualizar(evento);
        });
    }

    public List<EventoClassificado> findByPeriodo(Date dia, Empresa empresa, TipoIndisponibilidadeEvento tipo) {

        LOGGER.debug("Pesquisando os eventos para o dia: {}, a empresa: {} e o tipo: {}", dia, empresa, tipo);

        return eventoClassificadoDAO.findByPeriodo(dia, empresa, tipo);
    }
}