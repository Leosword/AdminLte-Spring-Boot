package br.com.netservicos.bow.databind;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;

public class HibernateAwareObjectMapper extends ObjectMapper {

    private static final long serialVersionUID = 120381919115878313L;

    public HibernateAwareObjectMapper() {

        Hibernate4Module module = new Hibernate4Module();

        registerModule(module);
    }

}
