package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.DashboardConfiguracaoIndisponibilidadeDAO;
import br.com.netservicos.bow.dao.EmpresaDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.DashboardConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.enums.TipoConfiguracaoIndisponibilidade;

@Service
public class DashboardConfiguracaoIndisponibilidadeService implements Serializable {

    private static final long serialVersionUID = 3460583064511583725L;

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardConfiguracaoIndisponibilidadeService.class);

    @Autowired
    private DashboardConfiguracaoIndisponibilidadeDAO dao;

    @Autowired
    private EmpresaDAO empresaDAO;

    public List<DashboardConfiguracaoIndisponibilidade> findFecthAll() {

        LOGGER.debug("Pesquisando todas as informações das aplicações");

        return dao.findFecthAll();
    }

    @Transactional
    public void salvar(Integer tipoId, Long empresaId, DashboardConfiguracaoIndisponibilidade configuracao) {

        TipoConfiguracaoIndisponibilidade tipo = TipoConfiguracaoIndisponibilidade.getTipoConfiguracaoIndisponibilidade(tipoId);

        if (tipo == null) {

            LOGGER.error("Não foi possível localizar o tipo com o Id: {}", tipoId);

            throw new BusinessException("Não foi possível localizar o tipo de SLA");
        }

        Optional<Empresa> optional = empresaDAO.findById(empresaId);

        if (!optional.isPresent()) {

            LOGGER.error("Não foi possível localizar a empresa com o Id: {}", tipoId);

            throw new BusinessException("Não foi possível localizar a empresa");
        }

        Empresa empresa = optional.get();

        configuracao.setEmpresa(empresa);

        configuracao.setTipo(tipo);

        Optional<DashboardConfiguracaoIndisponibilidade> configuracaoIndisponibilidade = dao.findByEmpresa(empresa, tipo, configuracao.getData());

        if (configuracaoIndisponibilidade.isPresent()) {

            DashboardConfiguracaoIndisponibilidade dashboardConfiguracaoIndisponibilidade = configuracaoIndisponibilidade.get();

            dashboardConfiguracaoIndisponibilidade.setValor(configuracao.getValor());

            dao.salvar(dashboardConfiguracaoIndisponibilidade);

        } else {

            dao.salvar(configuracao);
        }
    }

    public List<DashboardConfiguracaoIndisponibilidade> findByEmpresa(Empresa empresa, Date dia) {

        LOGGER.debug("Pesquisando as configurações com a Empresa: {} para o dia: {}", empresa, dia);

        return dao.findByEmpresa(empresa, dia);
    }

    @Transactional
    public void deletar(Long[] ids) {

        List<Long> configuracaoIds = Arrays.asList(ids);

        LOGGER.debug("Removendo as aplicações book com Ids: {}", configuracaoIds);

        dao.deletar(configuracaoIds);
    }

}
