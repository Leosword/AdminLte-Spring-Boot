package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.model.enums.TipoNivelServico;

@Repository
public class AplicacaoBookDAOImpl implements AplicacaoBookDAO {

    private static final long serialVersionUID = -1342773596162238325L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<AplicacaoBook> findFecthAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoBook from AplicacaoBook aplicacaoBook ");
        jpql.append("   inner join fetch aplicacaoBook.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   where aplicacaoBook.desativacao is null ");

        TypedQuery<AplicacaoBook> query = getEntityManager().createQuery(jpql.toString(), AplicacaoBook.class);

        return query.getResultList();
    }

    @Override
    public void salvar(AplicacaoBook aplicacaoBook) {

        getEntityManager().persist(aplicacaoBook);
    }

    @Override
    public Integer deletar(List<Long> aplicacoesBookIds) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" update AplicacaoBook set ");
        jpql.append("   desativacao = :desativacao ");
        jpql.append(" where id in (:aplicacoesBookIds) ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("desativacao", new Date());
        query.setParameter("aplicacoesBookIds", aplicacoesBookIds);

        return query.executeUpdate();
    }

    @Override
    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo, Empresa empresa, Boolean slaGeral) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoBook from AplicacaoBook aplicacaoBook ");
        jpql.append("   inner join fetch aplicacaoBook.aplicacao as aplicacao ");
        jpql.append("   inner join aplicacao.empresa as empresa ");
        jpql.append("   where aplicacaoBook.tipo = :tipo ");
        jpql.append("       and empresa.id = :empresaId ");
        jpql.append("       and aplicacaoBook.slaGeral = :slaGeral ");
        jpql.append("       and aplicacaoBook.desativacao is null ");
        jpql.append("       order by aplicacao.descricao asc ");

        TypedQuery<AplicacaoBook> query = getEntityManager().createQuery(jpql.toString(), AplicacaoBook.class);
        query.setParameter("empresaId", empresa.getId());
        query.setParameter("tipo", tipo);
        query.setParameter("slaGeral", slaGeral);

        return query.getResultList();
    }

    @Override
    public List<AplicacaoBook> findFetchAllByTipoComSla(TipoNivelServico tipo, Empresa empresa, TipoAplicacao tipoAplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoBook from AplicacaoBook aplicacaoBook ");
        jpql.append("   inner join fetch aplicacaoBook.aplicacao as aplicacao ");
        jpql.append("   inner join aplicacao.tipo as tipoAplicacao ");
        jpql.append("   inner join aplicacao.empresa as empresa ");
        jpql.append("   where aplicacaoBook.tipo = :tipo ");
        jpql.append("       and empresa.id = :empresaId ");
        jpql.append("       and aplicacaoBook.slaGeral = :slaGeral ");
        jpql.append("       and tipoAplicacao.id = :tipoAplicacaoId ");
        jpql.append("       and aplicacaoBook.desativacao is null ");
        jpql.append("       order by aplicacao.descricao asc ");

        TypedQuery<AplicacaoBook> query = getEntityManager().createQuery(jpql.toString(), AplicacaoBook.class);
        query.setParameter("empresaId", empresa.getId());
        query.setParameter("tipo", tipo);
        query.setParameter("tipoAplicacaoId", tipoAplicacao.getId());
        query.setParameter("slaGeral", true);

        return query.getResultList();
    }

    @Override
    public List<AplicacaoBook> findFetchAllByTipoComSla(TipoNivelServico tipo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoBook from AplicacaoBook aplicacaoBook ");
        jpql.append("   inner join fetch aplicacaoBook.aplicacao as aplicacao ");
        jpql.append("   inner join aplicacao.tipo as tipoAplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   where aplicacaoBook.tipo = :tipo ");
        jpql.append("       and aplicacaoBook.slaGeral = :slaGeral ");
        jpql.append("       and aplicacaoBook.desativacao is null ");
        jpql.append("       order by aplicacao.descricao asc ");

        TypedQuery<AplicacaoBook> query = getEntityManager().createQuery(jpql.toString(), AplicacaoBook.class);
        query.setParameter("tipo", tipo);
        query.setParameter("slaGeral", true);

        return query.getResultList();
    }

    @Override
    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo, Empresa empresa, TipoAplicacao tipoAplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoBook from AplicacaoBook aplicacaoBook ");
        jpql.append("   inner join fetch aplicacaoBook.aplicacao as aplicacao ");
        jpql.append("   inner join aplicacao.tipo as tipoAplicacao ");
        jpql.append("   inner join aplicacao.empresa as empresa ");
        jpql.append("   where aplicacaoBook.tipo = :tipo ");
        jpql.append("       and empresa.id = :empresaId ");
        jpql.append("       and tipoAplicacao.id = :tipoAplicacaoId ");
        jpql.append("       and aplicacaoBook.desativacao is null ");
        jpql.append("       order by aplicacao.descricao asc ");

        TypedQuery<AplicacaoBook> query = getEntityManager().createQuery(jpql.toString(), AplicacaoBook.class);
        query.setParameter("empresaId", empresa.getId());
        query.setParameter("tipo", tipo);
        query.setParameter("tipoAplicacaoId", tipoAplicacao.getId());

        return query.getResultList();
    }
    
    @Override
    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo) {
        
        StringBuilder jpql = new StringBuilder();
        
        jpql.append(" select aplicacaoBook from AplicacaoBook aplicacaoBook ");
        jpql.append("   inner join fetch aplicacaoBook.aplicacao as aplicacao ");
        jpql.append("   inner join aplicacao.tipo as tipoAplicacao ");
        jpql.append("   inner join aplicacao.empresa as empresa ");
        jpql.append("   where aplicacaoBook.tipo = :tipo ");
        jpql.append("       and aplicacaoBook.desativacao is null ");
        jpql.append("       order by aplicacao.descricao asc ");
        
        TypedQuery<AplicacaoBook> query = getEntityManager().createQuery(jpql.toString(), AplicacaoBook.class);
        query.setParameter("tipo", tipo);
        
        return query.getResultList();
    }

    @Override
    public List<AplicacaoBook> findFetchAllByTipos(List<TipoNivelServico> tiposNiveis, Empresa empresa, List<TipoAplicacao> tiposAplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoBook from AplicacaoBook aplicacaoBook ");
        jpql.append("   inner join fetch aplicacaoBook.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.tipo as tipoAplicacao ");
        jpql.append("   inner join aplicacao.empresa as empresa ");
        jpql.append("   where aplicacaoBook.tipo in (:tiposNiveis) ");
        jpql.append("       and empresa.id = :empresaId ");
        jpql.append("       and aplicacaoBook.slaGeral = :slaGeral ");
        jpql.append("       and tipoAplicacao in (:tiposAplicacao) ");
        jpql.append("       and aplicacaoBook.desativacao is null ");
        jpql.append("       order by aplicacao.descricao asc ");

        TypedQuery<AplicacaoBook> query = getEntityManager().createQuery(jpql.toString(), AplicacaoBook.class);
        query.setParameter("empresaId", empresa.getId());
        query.setParameter("tiposNiveis", tiposNiveis);
        query.setParameter("tiposAplicacao", tiposAplicacao);
        query.setParameter("slaGeral", true);

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}