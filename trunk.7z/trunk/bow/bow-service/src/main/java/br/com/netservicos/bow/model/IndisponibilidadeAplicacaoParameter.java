package br.com.netservicos.bow.model;

import java.io.Serializable;
import java.util.Date;

public class IndisponibilidadeAplicacaoParameter implements Serializable {

    private static final long serialVersionUID = 7767077130121528092L;

    private String minutosDia;

    private Aplicacao aplicacao;

    private Date inicio;

    private TipoIndisponibilidadeEvento tipo;

    public IndisponibilidadeAplicacaoParameter() {
        // Construtor padrão
    }

    public IndisponibilidadeAplicacaoParameter(String minutosDia, Aplicacao aplicacao, Date inicio, TipoIndisponibilidadeEvento tipo) {
        this.minutosDia = minutosDia;
        this.aplicacao = aplicacao;
        this.inicio = inicio;
        this.tipo = tipo;
    }

    public String getMinutosDia() {
        return minutosDia;
    }

    public void setMinutosDia(String minutosDia) {
        this.minutosDia = minutosDia;
    }

    public Aplicacao getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(Aplicacao aplicacao) {
        this.aplicacao = aplicacao;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public TipoIndisponibilidadeEvento getTipo() {
        return tipo;
    }

    public void setTipo(TipoIndisponibilidadeEvento tipo) {
        this.tipo = tipo;
    }

}
