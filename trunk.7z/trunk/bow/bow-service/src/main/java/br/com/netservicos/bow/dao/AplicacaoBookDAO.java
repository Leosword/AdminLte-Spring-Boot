package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;

import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.model.enums.TipoNivelServico;

public interface AplicacaoBookDAO extends Serializable {

    public List<AplicacaoBook> findFecthAll();

    public void salvar(AplicacaoBook aplicacaoBook);

    public Integer deletar(List<Long> aplicacoesBookIds);

    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo, Empresa empresa, Boolean slaGeral);
    
    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo, Empresa empresa, TipoAplicacao tipoAplicacao);
    
    public List<AplicacaoBook> findFetchAllByTipo(TipoNivelServico tipo);
    
    public List<AplicacaoBook> findFetchAllByTipoComSla(TipoNivelServico tipo, Empresa empresa, TipoAplicacao tipoAplicacao);

    public List<AplicacaoBook> findFetchAllByTipos(List<TipoNivelServico> tiposNiveis, Empresa empresa, List<TipoAplicacao> tiposAplicacao);

    public List<AplicacaoBook> findFetchAllByTipoComSla(TipoNivelServico tipo);
    
}
