package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Multimap;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.DateUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.dao.IndisponibilidadeAplicacaoDAO;
import br.com.netservicos.bow.dao.IndisponibilidadeAplicacaoMensalDAO;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacao;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.service.collector.MultimapCollector;

@Service
public class IndisponibilidadeAplicacaoMensalService implements Serializable {

    private static final long serialVersionUID = -4287969340409089603L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeAplicacaoMensalService.class);

    @Autowired
    private IndisponibilidadeAplicacaoDAO indisponibilidadeAplicacaoDAO;

    @Autowired
    private IndisponibilidadeAplicacaoMensalDAO indisponibilidadeAplicacaoMensalDAO;

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    @Autowired
    private ParametroService parametroService;

    public void consolida(List<IndisponibilidadeAplicacao> eventos) {

        Parametro parametro = parametroService.findByNome(ParametroConstants.BUSINESS_HOURS);

        List<IndisponibilidadeAplicacaoMensal> indisponibilidades = new ArrayList<>();

        LOGGER.debug("Iniciando o processo de consolidação Mensal.");

        Multimap<Aplicacao, IndisponibilidadeAplicacao> aplicacoes = eventos.stream()
                .collect(MultimapCollector.toMultimap(IndisponibilidadeAplicacao::getAplicacao));

        aplicacoes.asMap().keySet().iterator().forEachRemaining(aplicacao -> {

            Collection<IndisponibilidadeAplicacao> eventosAplicacao = aplicacoes.get(aplicacao);

            Multimap<Integer, IndisponibilidadeAplicacao> eventosPorAno = eventosAplicacao.stream()
                    .collect(MultimapCollector.toMultimap((IndisponibilidadeAplicacao v) -> DateUtil.getYear(v.getInicio())));

            eventosPorAno.asMap().keySet().iterator().forEachRemaining(ano -> {

                Collection<IndisponibilidadeAplicacao> eventosAno = eventosPorAno.get(ano);

                Multimap<Integer, IndisponibilidadeAplicacao> eventosPorMes = eventosAno.stream()
                        .collect(MultimapCollector.toMultimap((IndisponibilidadeAplicacao v) -> DateUtil.getMonth(v.getInicio())));

                eventosPorMes.asMap().keySet().iterator().forEachRemaining(mes -> {

                    LOGGER.debug("Iniciando o processo de consolidação Mensal para aplicação: {}, ano: {} e mês: {}", aplicacao, ano, mes);

                    List<IndisponibilidadeAplicacao> aplicacoesIndisponiveis = indisponibilidadeAplicacaoDAO.findByPeriodo(ano, mes, aplicacao);

                    BigDecimal totalMinutos = somarMinutos(aplicacoesIndisponiveis);

                    BigDecimal totalMinutosPosPatch = somarMinutosPosPatch(aplicacoesIndisponiveis);

                    BigDecimal totalMinutosMes = getMinutesOfMonth(ano, mes, parametro.getValor());

                    BigDecimal minutosMensal = converter.convert(totalMinutos);

                    BigDecimal percentualBase = calculaIndisponibilidadeService.calculaPercentual(totalMinutos, totalMinutosMes);

                    BigDecimal minutosMensalPosPatch = converter.convert(totalMinutosPosPatch);

                    BigDecimal percentualBasePosPatch = calculaIndisponibilidadeService.calculaPercentual(totalMinutosPosPatch, totalMinutosMes);

                    atualizar(ano, mes, aplicacao);

                    Date criacao = DateUtil.firstDayOfMonth(ano, mes);

                    IndisponibilidadeAplicacaoMensal indisponibilidade = new IndisponibilidadeAplicacaoMensal(aplicacao, minutosMensal,
                            percentualBase, minutosMensalPosPatch, percentualBasePosPatch, criacao);

                    indisponibilidades.add(indisponibilidade);

                    LOGGER.debug("Finalizando o processo de consolidação Mensal para aplicação: {}, ano: {} e mês: {}", aplicacao, ano, mes);
                });

            });

        });

        LOGGER.debug("Finalizando o processo de consolidação Mensal. Persistindo o total de :{} indisponibilidades", indisponibilidades.size());

        salvar(indisponibilidades);
    }

    private BigDecimal somarMinutosPosPatch(List<IndisponibilidadeAplicacao> aplicacoesIndisponiveis) {

        return aplicacoesIndisponiveis.stream().filter(aplicacaoIndisponivel -> Objects.nonNull(aplicacaoIndisponivel.getTotalMinutosPosPatch()))
                .map(aplicacaoIndisponivel -> aplicacaoIndisponivel.getTotalMinutosPosPatch()).reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);
    }

    private BigDecimal somarMinutos(List<IndisponibilidadeAplicacao> aplicacoesIndisponiveis) {

        return aplicacoesIndisponiveis.stream().filter(aplicacaoIndisponivel -> Objects.nonNull(aplicacaoIndisponivel.getTotalMinutos()))
                .map(aplicacaoIndisponivel -> aplicacaoIndisponivel.getTotalMinutos()).reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);
    }

    @Transactional
    private void salvar(List<IndisponibilidadeAplicacaoMensal> indisponibilidades) {

        indisponibilidades.forEach(indisponibilidade -> {

            indisponibilidadeAplicacaoMensalDAO.salvar(indisponibilidade);
        });
    }

    @Transactional
    public void atualizar(Integer ano, Integer mes, Aplicacao aplicacao) {

        Optional<IndisponibilidadeAplicacaoMensal> indisponibilidade = indisponibilidadeAplicacaoMensalDAO.findByPeriodo(ano, mes, aplicacao);

        if (indisponibilidade.isPresent()) {

            IndisponibilidadeAplicacaoMensal indisponibilidadeAplicacaoMensal = indisponibilidade.get();

            LOGGER.debug("Desativando a indisponibilidade Mensal: {}", indisponibilidadeAplicacaoMensal);

            indisponibilidadeAplicacaoMensal.setDesativacao(new Date());

            indisponibilidadeAplicacaoMensalDAO.atualizar(indisponibilidadeAplicacaoMensal);
        }
    }

    public BigDecimal getMinutesOfMonth(Integer year, Integer month, String totalMinutosBH) {

        LocalDate date = LocalDate.of(year, month, NumberUtil.INTEGER_ONE);

        int totalDiasMes = date.getMonth().maxLength();

        BigDecimal minutes = new BigDecimal(totalDiasMes).multiply(new BigDecimal(totalMinutosBH)).multiply(NumberUtil.TOTAL_MINUTOS_DAY);

        return minutes;
    }

    public List<IndisponibilidadeAplicacaoMensal> findByAno(Integer ano, List<Aplicacao> aplicacoes) {

        LOGGER.debug("Pesquisando todas as aplicações do ano atual: {}", ano);

        return indisponibilidadeAplicacaoMensalDAO.findByAno(ano, aplicacoes);
    }

    public List<IndisponibilidadeAplicacaoMensal> findByPeriodoAno(Integer inicio, Integer fim, List<Aplicacao> aplicacoes) {

        LOGGER.debug("Pesquisando todas as aplicações no período anual. Início: {}, Fim: {}", inicio, fim);

        if (CollectionUtil.isEmpty(aplicacoes)) {

            LOGGER.warn("Não foi possível localizar aplicações");

            return Collections.emptyList();
        }

        return indisponibilidadeAplicacaoMensalDAO.findByPeriodoAno(inicio, fim, aplicacoes);
    }

    public List<IndisponibilidadeAplicacaoMensal> findByPeriodo(Integer ano, Integer mes, List<Aplicacao> aplicacoes) {

        LOGGER.debug("Pesquisando todas as indisponibilidades no período ano: {}, mês: {}", ano, mes);

        if (CollectionUtil.isEmpty(aplicacoes)) {

            LOGGER.warn("Não foi possível localizar aplicações");

            return Collections.emptyList();
        }

        return indisponibilidadeAplicacaoMensalDAO.findByPeriodo(ano, mes, aplicacoes);
    }

    public Optional<IndisponibilidadeAplicacaoMensal> filterByPeriodo(List<IndisponibilidadeAplicacaoMensal> indisponibilidades, LocalDate data) {

        return indisponibilidades.stream().filter(indisponibilidade -> DateUtil.getLocalDate(indisponibilidade.getCriacao()).equals(data))
                .findFirst();
    }

    public List<IndisponibilidadeAplicacaoMensal> findByPeriodoAplicacao(Integer ano, Integer mes, Aplicacao aplicacao) {

        LOGGER.debug("Pesquisando todas as indisponibilidades no período ano: {}, mês: {}, aplicacao: {}", ano, mes, aplicacao);

        return indisponibilidadeAplicacaoMensalDAO.findByPeriodoAplicacao(ano, mes, aplicacao);
    }

}
