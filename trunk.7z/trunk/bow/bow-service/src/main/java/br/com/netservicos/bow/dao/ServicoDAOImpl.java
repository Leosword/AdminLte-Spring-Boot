package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Servico;

@Repository
public class ServicoDAOImpl implements ServicoDAO {

    private static final long serialVersionUID = -5237785350408648200L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<Servico> findAllAtivas() {

        TypedQuery<Servico> query = getEntityManager().createNamedQuery("Servico.findAllAtivas", Servico.class);

        return query.getResultList();
    }

    @Override
    public void salvar(Servico servico) {

        if (servico.getId() == null) {

            getEntityManager().persist(servico);

        } else {

            getEntityManager().merge(servico);
        }
    }

    @Override
    public Integer deletar(Long servicoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" update Servico set ");
        jpql.append("   status = :status ");
        jpql.append(" where id = :servicoId ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("status", false);
        query.setParameter("servicoId", servicoId);

        return query.executeUpdate();
    }

    @Override
    public Optional<Servico> findByNome(String nome) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select servico from Servico servico ");
        jpql.append(" where servico.nome = :nome");

        TypedQuery<Servico> query = entityManager.createQuery(jpql.toString(), Servico.class);

        query.setParameter("nome", nome);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Servico> findById(Long servicoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select servico from Servico servico ");
        jpql.append(" where servico.id = :servicoId");

        TypedQuery<Servico> query = entityManager.createQuery(jpql.toString(), Servico.class);

        query.setParameter("servicoId", servicoId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
