package br.com.netservicos.bow.account;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.model.ImapctoIndisponibilidadeParameter;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.service.OperacaoRegionalService;

@Component(value = "impactoUmaRegional")
public class CalculaImpactoRegional implements CalculaImpacto {

    private static final long serialVersionUID = 1998718679706624479L;

    private static final String BRASIL = "BRASIL";

    @Autowired
    private OperacaoRegionalService service;

    @Autowired
    @Qualifier("calculaImpactoIndisponibilidade")
    private CalculaImpactoIndisponibilidade calculaImpactoIndisponibilidade;

    @Override
    public BigDecimal calcula(ImapctoIndisponibilidadeParameter dados) {

        List<ImpactoIndicadorEvento> impactos = dados.getImpactos().stream().filter(impacto -> houveImpacto(impacto)).collect(Collectors.toList());

        if (Iterables.isEmpty(impactos)) {

            return BigDecimal.ZERO;
        }

        Long total = service.totalByAplicacao(dados.getRegional(), dados.getAplicacao());

        return calculaImpactoIndisponibilidade.calcula(dados, impactos, total);
    }

    private boolean houveImpacto(ImpactoIndicadorEvento impacto) {

        return Objects.nonNull(impacto.getRegional()) && !BRASIL.equals(impacto.getRegional().getNome());
    }
}
