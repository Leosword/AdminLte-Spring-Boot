package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.AplicacaoDAO;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.TipoAplicacao;

@Service
public class AplicacaoService implements Serializable {

    private static final long serialVersionUID = 2831546084807101447L;

    private static final Logger LOGGER = LoggerFactory.getLogger(AplicacaoService.class);

    @Autowired
    private AplicacaoDAO dao;

    public List<Aplicacao> findAll() {

        LOGGER.debug("Pesquisando todos os registros da aplicação");

        return dao.findAll();
    }

    public List<Aplicacao> findFetchAll() {

        LOGGER.debug("Pesquisando todos os registros da aplicação");

        return dao.findFetchAll();
    }

    public List<Aplicacao> findByEmpresa(Empresa empresa, TipoAplicacao tipo) {

        LOGGER.debug("Pesquisando as aplicaçoes para Empresa: {}, com Tipo de Aplicação: {}", empresa, tipo);

        return dao.findByEmpresa(empresa, tipo);
    }

    public List<Aplicacao> findByEmpresa(PaggableSelect select) {

        LOGGER.debug("Pesquisando as aplicaçoes para Empresa: {}: {}", select);

        return dao.findByEmpresa(select);
    }

    public List<Aplicacao> findByTipo(TipoAplicacao tipo) {

        LOGGER.debug("Pesquisando as aplicaçoes com Tipo de Aplicação: {}", tipo);

        return dao.findByTipo(tipo);
    }

    public Long countByTipo(TipoAplicacao tipoAplicacao) {

        LOGGER.debug("Contando total de aplicações com o tipo: {}", tipoAplicacao);

        return dao.countByTipo(tipoAplicacao);
    }

    public List<Aplicacao> findByPaggebleSelect(PaggableSelect paggable) {

        LOGGER.debug("Pesquisando as aplicaçoes com a página: {}", paggable);

        return dao.findByPaggebleSelect(paggable);
    }

    public Optional<Aplicacao> findById(Long id) {

        LOGGER.debug("Pesquisando a aplicação com o Id: {}", id);

        return dao.findById(id);
    }

    @Transactional
    public void atualizar(Aplicacao aplicacao) {

        LOGGER.debug("Persistindo a aplicação: {}", aplicacao);

        dao.persistir(aplicacao);
    }
}
