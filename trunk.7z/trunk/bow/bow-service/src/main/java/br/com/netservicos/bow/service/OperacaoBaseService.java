package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.BaseDAO;
import br.com.netservicos.bow.dao.OperacaoBaseDAO;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.Operacao;
import br.com.netservicos.bow.model.OperacaoBase;
import br.com.netservicos.bow.model.Usuario;

@Service
public class OperacaoBaseService implements Serializable {

    private static final long serialVersionUID = 6329878951145063456L;

    private static final Logger LOGGER = LoggerFactory.getLogger(OperacaoBaseService.class);

    @Autowired
    private BaseDAO baseDAO;

    @Autowired
    private OperacaoBaseDAO operacaoBaseDAO;

    public List<OperacaoBase> findByAplicacoes(Long operacaoId) {

        LOGGER.debug("Pesquisando as operações e bases com o operacaoId: {}", operacaoId);

        return operacaoBaseDAO.findByOperacaoId(operacaoId);
    }

    @Transactional
    public void atualizar(Operacao operacao, Long[] baseIds, Optional<Usuario> usuario) {

        LOGGER.debug("Removendo as aplicações e bases com operacaoId: {}", operacao.getId());

        operacaoBaseDAO.deleteFromOperacao(operacao.getId());

        List<OperacaoBase> operacoesBases = new ArrayList<>();

        LOGGER.debug("Pesquisando as bases com os Ids: {}", new Object[] { baseIds });

        List<Base> bases = baseDAO.findByIds(Arrays.asList(baseIds));

        bases.forEach(base -> {

            OperacaoBase operacaoBase = new OperacaoBase(operacao, base, usuario.get());

            operacoesBases.add(operacaoBase);
        });

        LOGGER.debug("Persistindo a operação e as bases: {}", operacoesBases);

        operacaoBaseDAO.salvar(operacoesBases);
    }

    public List<OperacaoBase> findByBase(Base base) {

        LOGGER.debug("Pesquisando todas as operações para base: {}", base);

        return operacaoBaseDAO.findByBase(base);
    }

}
