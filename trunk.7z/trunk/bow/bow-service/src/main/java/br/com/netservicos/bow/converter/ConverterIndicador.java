package br.com.netservicos.bow.converter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.springframework.stereotype.Component;

import br.com.netservicos.bow.common.util.NumberUtil;

/**
 * <p>
 * Classe responsável por realizar a conversão de Minutos que ultrapassem <b> 60
 * segundos </b>.
 * </p>
 * 
 * @author eric.santos
 *
 */
@Component(value = "converterIndicador")
public class ConverterIndicador implements ConverterDecimal {

    private static final BigInteger MINUTES = new BigInteger("60");

    private static final String SEPARATOR = ".";

    @Override
    public BigDecimal convert(BigDecimal value) {

        BigInteger inteiro = value.abs().toBigInteger();

        BigInteger decimal = ((value.subtract(new BigDecimal(inteiro))).multiply(new BigDecimal(10).pow(NumberUtil.INTEGER_TWO))).toBigInteger();

        if (decimal.compareTo(MINUTES) > 0) {

            BigInteger result = inteiro.add(BigInteger.ONE);

            BigInteger fractional = decimal.subtract(MINUTES);

            StringBuilder sb = new StringBuilder().append(result).append(SEPARATOR).append(fractional);

            return new BigDecimal(sb.toString()).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);
        }

        return value;
    }
}
