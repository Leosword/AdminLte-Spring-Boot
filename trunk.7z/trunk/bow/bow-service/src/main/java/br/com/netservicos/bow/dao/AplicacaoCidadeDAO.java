package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoCidade;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.model.Cidade;

public interface AplicacaoCidadeDAO extends Serializable {

    public List<AplicacaoCidade> findAll();

    public List<AplicacaoCidade> findFecthAll();

    public Integer deletar(Long id);

    public void salvar(List<AplicacaoCidade> aplicacaoCidades);

    public Long findTotalByAplicacao(Base base, Aplicacao aplicacao);

    public Optional<AplicacaoCidade> findByBaseCidade(BaseAplicacao baseAplicacao, Cidade cidade);

}
