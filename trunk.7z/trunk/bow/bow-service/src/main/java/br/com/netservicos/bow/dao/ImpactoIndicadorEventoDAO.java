package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;

import br.com.netservicos.bow.model.ImpactoIndicadorEvento;

public interface ImpactoIndicadorEventoDAO extends Serializable {

    List<ImpactoIndicadorEvento> findByEvento(Long eventoId);

}
