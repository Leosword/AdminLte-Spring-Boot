package br.com.netservicos.bow.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class MinutosIndisponibilidade implements Serializable {

    private static final long serialVersionUID = 8269362697401410224L;

    private BigDecimal minutos;

    private BigDecimal percentual;

    public MinutosIndisponibilidade() {
        // Construtor padrão
    }

    public MinutosIndisponibilidade(BigDecimal minutos, BigDecimal percentual) {
        this.minutos = minutos;
        this.percentual = percentual;
    }

    public BigDecimal getMinutos() {
        return minutos;
    }

    public void setMinutos(BigDecimal minutos) {
        this.minutos = minutos;
    }

    public BigDecimal getPercentual() {
        return percentual;
    }

    public void setPercentual(BigDecimal percentual) {
        this.percentual = percentual;
    }

}
