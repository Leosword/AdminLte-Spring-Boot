package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.TipoAplicacao;

@Repository
public class TipoAplicacaoDAOImpl implements TipoAplicacaoDAO {

    private static final long serialVersionUID = 6888020331083222743L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public Optional<TipoAplicacao> findByAtivo(String nome) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select tipo from TipoAplicacao tipo ");
        jpql.append("       where tipo.descricao = :nome ");
        jpql.append("       and tipo.status = :status ");

        TypedQuery<TipoAplicacao> query = getEntityManager().createQuery(jpql.toString(), TipoAplicacao.class);

        query.setParameter("nome", nome);
        query.setParameter("status", true);

        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<TipoAplicacao> findByNomes(List<String> nomes) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select tipo from TipoAplicacao tipo ");
        jpql.append("       where tipo.descricao in (:nomes) ");
        jpql.append("       and tipo.status = :status ");

        TypedQuery<TipoAplicacao> query = getEntityManager().createQuery(jpql.toString(), TipoAplicacao.class);

        query.setParameter("nomes", nomes);
        query.setParameter("status", true);

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}