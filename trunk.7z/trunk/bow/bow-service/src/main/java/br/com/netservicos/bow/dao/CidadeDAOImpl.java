package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Cidade;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class CidadeDAOImpl implements CidadeDAO {

    private static final long serialVersionUID = 2768463528252832637L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<Cidade> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select cidade from Cidade cidade ");
        jpql.append("   inner join cidade.estado as estado ");
        jpql.append("       where cidade.nome like :nome ");
        jpql.append("       and estado.id in (:estadoIds) ");

        TypedQuery<Cidade> query = getEntityManager().createQuery(jpql.toString(), Cidade.class);

        query.setParameter("nome", '%' + paggable.getTerm() + '%');
        query.setParameter("estadoIds", paggable.getConvertValues());

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public Optional<Cidade> findById(Long cidadeId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select cidade from Cidade cidade ");
        jpql.append("       where cidade.id = :cidadeId ");

        TypedQuery<Cidade> query = getEntityManager().createQuery(jpql.toString(), Cidade.class);

        query.setParameter("cidadeId", cidadeId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<Cidade> findByBase(Long baseId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select cidade from Cidade cidade ");
        jpql.append(" inner join cidade.base as base ");
        jpql.append(" where base.id = :baseId");

        TypedQuery<Cidade> query = entityManager.createQuery(jpql.toString(), Cidade.class);

        query.setParameter("baseId", baseId);

        return query.getResultList();
    }

    @Override
    public List<Cidade> findByFetchAllBase(Long baseId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select cidade from Cidade cidade ");
        jpql.append(" inner join cidade.base as base ");
        jpql.append(" inner join fetch cidade.estado as estado ");
        jpql.append(" where base.id = :baseId");

        TypedQuery<Cidade> query = entityManager.createQuery(jpql.toString(), Cidade.class);

        query.setParameter("baseId", baseId);

        return query.getResultList();
    }

    @Override
    public List<Cidade> findByIds(List<Long> idCidades) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select cidade from Cidade cidade ");
        jpql.append("   where cidade.id in (:idCidades)");

        TypedQuery<Cidade> query = entityManager.createQuery(jpql.toString(), Cidade.class);

        query.setParameter("idCidades", idCidades);

        return query.getResultList();
    }

    @Override
    public void merge(Cidade cidade) {

        getEntityManager().merge(cidade);

    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
