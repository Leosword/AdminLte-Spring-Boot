package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.dao.ImpactoIndicadorEventoBookDAO;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.model.ImpactoIndicadorEventoBook;

@Service
public class ImpactoIndicadorEventoBookService implements Serializable {

    private static final long serialVersionUID = -390749425806873773L;

    @Autowired
    private ImpactoIndicadorEventoBookDAO impactoIndicadorEventoBookDAO;

    private static final Logger LOGGER = LoggerFactory.getLogger(ImpactoIndicadorEventoBookService.class);

    public List<ImpactoIndicadorEventoBook> findByImpactos(List<ImpactoIndicadorEvento> impactos) {

        LOGGER.debug("Pesquisando os impactos para o book para com o total de Impactos: {}", impactos.size());

        return impactoIndicadorEventoBookDAO.findByImpactos(impactos);
    }

}
