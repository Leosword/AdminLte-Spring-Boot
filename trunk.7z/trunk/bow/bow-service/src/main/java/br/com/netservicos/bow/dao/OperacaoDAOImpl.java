package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Operacao;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class OperacaoDAOImpl implements OperacaoDAO {

    private static final long serialVersionUID = 4097956405787760204L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<Operacao> findAllAtivas() {

        TypedQuery<Operacao> query = getEntityManager().createNamedQuery("Operacao.findAllAtivas", Operacao.class);

        return query.getResultList();
    }

    @Override
    public void salvar(Operacao operacao) {

        if (operacao.getId() == null) {

            getEntityManager().persist(operacao);

        } else {

            getEntityManager().merge(operacao);
        }
    }

    @Override
    public Integer deletar(Long operacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" update Operacao set ");
        jpql.append("   status = :status ");
        jpql.append(" where id = :operacaoId ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("status", false);
        query.setParameter("operacaoId", operacaoId);

        return query.executeUpdate();
    }

    @Override
    public List<Operacao> findFetchAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select operacao from Operacao operacao ");
        jpql.append("   inner join fetch operacao.cidade as cidade");
        jpql.append("   and operacao.statusOperacao = :status ");

        TypedQuery<Operacao> query = entityManager.createQuery(jpql.toString(), Operacao.class);
        query.setParameter("status", true);

        return query.getResultList();
    }

    @Override
    public Optional<Operacao> findByIdFetchAll(Long id) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select operacao from Operacao operacao ");
        jpql.append("   left join fetch operacao.cidade as cidade");
        jpql.append("   left join fetch cidade.estado as estado");
        jpql.append(" where operacao.id = :operacaoId ");

        TypedQuery<Operacao> query = entityManager.createQuery(jpql.toString(), Operacao.class);

        query.setParameter("operacaoId", id);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Operacao> findById(Long operacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select operacao from Operacao operacao ");
        jpql.append(" where operacao.id = :operacaoId");

        TypedQuery<Operacao> query = entityManager.createQuery(jpql.toString(), Operacao.class);

        query.setParameter("operacaoId", operacaoId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public List<Operacao> findByIds(List<Long> operacoesId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select operacao from Operacao operacao ");
        jpql.append("   where operacao.id in (:operacoesId) ");

        TypedQuery<Operacao> query = getEntityManager().createQuery(jpql.toString(), Operacao.class);

        query.setParameter("operacoesId", operacoesId);

        return query.getResultList();
    }

    @Override
    public List<Operacao> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select operacao from Operacao operacao ");
        jpql.append("       where operacao.nome like :nome ");
        jpql.append("       and operacao.statusOperacao = :status ");

        TypedQuery<Operacao> query = getEntityManager().createQuery(jpql.toString(), Operacao.class);

        query.setParameter("nome", '%' + paggable.getTerm() + '%');
        query.setParameter("status", true);

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public Optional<Operacao> findByNome(String nome) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select operacao from Operacao operacao ");
        jpql.append("   where operacao.nome = :nome");
        jpql.append("   and operacao.statusOperacao = :status ");

        TypedQuery<Operacao> query = entityManager.createQuery(jpql.toString(), Operacao.class);

        query.setParameter("nome", nome);
        query.setParameter("status", true);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
