package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.dao.EmpresaDAO;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;

@Service
public class EmpresaService implements Serializable {

    private static final long serialVersionUID = 2831546084807101447L;

    @Autowired
    private EmpresaDAO dao;

    private static final Logger LOGGER = LoggerFactory.getLogger(EmpresaService.class);

    public List<Empresa> findByPaggebleSelect(PaggableSelect paggable) {

        LOGGER.debug("Pesquisando a empresa com a página: {}", paggable);

        return dao.findByPaggebleSelect(paggable);
    }

    public Optional<Empresa> findById(Long empresaId) {

        LOGGER.debug("Pesquisando a empresa com Id: {}", empresaId);

        return dao.findById(empresaId);
    }
    
    public Optional<Empresa> findByIdentificador(IdentificadorEmpresa identificador) {
        
        LOGGER.debug("Pesquisando a empresa com o Identificador: {}", identificador);
        
        return dao.findByIdentificador(identificador);
    }

    public List<Empresa> findAll() {

        LOGGER.debug("Pesquisando todas as empresas.");

        return dao.findAll();
    }
}
