package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.Periodo;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

@Repository
public class IndisponibilidadeEventoDAOImpl implements IndisponibilidadeEventoDAO {

    private static final long serialVersionUID = 3428650822723032512L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<IndisponibilidadeEvento> findAll() {

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createNamedQuery("IndisponibilidadeEvento.findAll",
                IndisponibilidadeEvento.class);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeEvento> findFetchAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join fetch indisponibilidade.base base ");
        jpql.append("       inner join fetch indisponibilidade.tipoIndisponbilidade tipoIndisponbilidade ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        return query.getResultList();
    }

    @Override
    public void salvar(List<IndisponibilidadeEvento> consolidados) {

        consolidados.forEach(consolidado -> {

            getEntityManager().persist(consolidado);
        });

    }

    @Override
    public void atualizar(IndisponibilidadeEvento indisponibilidade) {

        getEntityManager().merge(indisponibilidade);
    }

    @Override
    public Optional<IndisponibilidadeEvento> findByBase(Base base, Aplicacao aplicacao, Date dia, TipoIndisponibilidadeEvento tipo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join indisponibilidade.base base ");
        jpql.append("       inner join indisponibilidade.tipoIndisponbilidade tipoIndisponbilidade ");
        jpql.append("   where aplicacao.id = :aplicacaoId ");
        jpql.append("       and base.id = :baseId ");
        jpql.append("       and tipoIndisponbilidade.id = :tipoId ");
        jpql.append("       and date(indisponibilidade.inicio) = :dia ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("baseId", base.getId());
        query.setParameter("aplicacaoId", aplicacao.getId());
        query.setParameter("dia", dia);
        query.setParameter("tipoId", tipo.getId());

        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<IndisponibilidadeEvento> findByEvento(EventoClassificado evento, Date dia) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join indisponibilidade.evento as evento ");
        jpql.append("       where evento.eventoId = :eventoId ");
        jpql.append("       and date(indisponibilidade.inicio) = :dia ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("eventoId", evento.getEventoId());
        query.setParameter("dia", dia);
        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<IndisponibilidadeEvento> findByAplicacao(Date dia, Aplicacao aplicacao, TipoIndisponibilidadeEvento tipo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.evento evento ");
        jpql.append("       inner join fetch evento.origem origem ");
        jpql.append("       left join fetch indisponibilidade.base base ");
        jpql.append("       left join fetch indisponibilidade.regional regional ");
        jpql.append("       inner join indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join indisponibilidade.tipoIndisponbilidade tipoIndisponbilidade ");
        jpql.append("   where aplicacao.id = :aplicacaoId ");
        jpql.append("       and tipoIndisponbilidade.id = :tipoId ");
        jpql.append("       and date(indisponibilidade.inicio) = :dia ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("aplicacaoId", aplicacao.getId());
        query.setParameter("dia", dia);
        query.setParameter("tipoId", tipo.getId());

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeEvento> findByPeriodo(Date inicio, Date fim) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join fetch indisponibilidade.tipoIndisponbilidade tipoIndisponbilidade ");
        jpql.append("   where indisponibilidade.inicio between :inicio and :fim ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("inicio", inicio, TemporalType.DATE);
        query.setParameter("fim", fim, TemporalType.DATE);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeEvento> findByRegional(Regional regional, List<Aplicacao> aplicacoes, Integer mes, Integer ano) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.regional regional ");
        jpql.append("       inner join indisponibilidade.aplicacao aplicacao ");
        jpql.append("   where regional.id = :regionalId ");
        jpql.append("       and aplicacao in (:aplicacoes) ");
        jpql.append("       and YEAR(indisponibilidade.inicio) = :ano  ");
        jpql.append("       and MONTH(indisponibilidade.inicio) = :mes  ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("regionalId", regional.getId());
        query.setParameter("ano", ano);
        query.setParameter("mes", mes);
        query.setParameter("aplicacoes", aplicacoes);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeEvento> findByPeriodoAplicacao(Aplicacao aplicacao, TipoIndisponibilidadeEvento tipo, Periodo periodo) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join fetch indisponibilidade.evento evento ");
        jpql.append("       inner join fetch evento.tipoIndisponibilidade tipoIndisponibilidade ");
        jpql.append("       left join fetch indisponibilidade.regional regional ");
        jpql.append("       left join fetch indisponibilidade.base base ");
        jpql.append("   where aplicacao.id = :aplicacaoId ");
        jpql.append("       and tipoIndisponibilidade.id = :tipoId ");
        jpql.append("       and indisponibilidade.inicio between :inicio and :termino");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("aplicacaoId", aplicacao.getId());
        query.setParameter("tipoId", tipo.getId());
        query.setParameter("inicio", periodo.getInicio(), TemporalType.DATE);
        query.setParameter("termino", periodo.getTermino(), TemporalType.DATE);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeEvento> findByPeriodo(Integer ano, Integer mes, Empresa empresa) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join fetch aplicacao.empresa empresa ");
        jpql.append("       inner join fetch indisponibilidade.evento evento ");
        jpql.append("   where empresa.id = :empresaId ");
        jpql.append("       and YEAR(indisponibilidade.inicio) = :ano  ");
        jpql.append("       and MONTH(indisponibilidade.inicio) = :mes  ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("empresaId", empresa.getId());
        query.setParameter("ano", ano);
        query.setParameter("mes", mes);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeEvento> findByRegional(Regional regional, Aplicacao aplicacao, Integer mes, Integer ano) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.regional regional ");
        jpql.append("       inner join indisponibilidade.aplicacao aplicacao ");
        jpql.append("   where regional.id = :regionalId ");
        jpql.append("       and aplicacao.id = :aplicacaoId ");
        jpql.append("       and YEAR(indisponibilidade.inicio) = :ano  ");
        jpql.append("       and MONTH(indisponibilidade.inicio) = :mes  ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("regionalId", regional.getId());
        query.setParameter("ano", ano);
        query.setParameter("mes", mes);
        query.setParameter("aplicacaoId", aplicacao.getId());

        return query.getResultList();
    }

    @Override
    public Optional<IndisponibilidadeEvento> findByEvento(EventoClassificado evento) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeEvento indisponibilidade ");
        jpql.append("       inner join indisponibilidade.evento evento ");
        jpql.append("   where evento.eventoId = :eventoId ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeEvento.class);

        query.setParameter("eventoId", evento.getEventoId());

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Integer remover(EventoClassificado evento) {

        StringBuilder jpqlBuilder = new StringBuilder();

        jpqlBuilder.append("update IndisponibilidadeEvento indisponibilidade set ");
        jpqlBuilder.append("    desativacao = :desativacao ");
        jpqlBuilder.append(" where ");
        jpqlBuilder.append("    indisponibilidade.evento.eventoId = :eventoId  ");

        Query query = getEntityManager().createQuery(jpqlBuilder.toString());

        query.setParameter("eventoId", evento.getEventoId());
        query.setParameter("desativacao", new Date());

        return query.executeUpdate();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
