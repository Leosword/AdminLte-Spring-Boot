package br.com.netservicos.bow.common.util;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;

public final class ResourceUtil {

    private static final ResourceBundle RECURSO = ResourceBundle.getBundle("messages", Locale.getDefault());

    private ResourceUtil() {
        // Contrutor padrão
    }

    /**
     * Adiciona uma mensagem de aviso ao FacesContext
     * 
     * @param mensagem
     *            Texto da mensagem
     */
    public static String getMensagem(String mensagem, Object... parametros) {

        if (Objects.isNull(parametros)) {
            return RECURSO.getString(mensagem);
        }

        return MessageFormat.format(RECURSO.getString(mensagem), parametros);

    }

}
