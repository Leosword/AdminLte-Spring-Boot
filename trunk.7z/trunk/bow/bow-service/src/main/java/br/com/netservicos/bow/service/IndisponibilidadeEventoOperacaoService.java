package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.account.CalculaImpacto;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;

@Service
public class IndisponibilidadeEventoOperacaoService implements Serializable {

    private static final long serialVersionUID = -2915141918653254475L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeEventoOperacaoService.class);

    @Autowired
    @Qualifier("impactoUmaOperacao")
    private CalculaImpacto calculaImpactoUmaOperacao;

    @Autowired
    @Qualifier("impactoTodasOperacoes")
    private CalculaImpacto calculaImpactoTodasOperacoes;

    @Autowired
    private IndisponibilidadeEventoService indisponibilidadeEventoService;

    public void consolidar(List<EventoClassificado> eventos) {

        LOGGER.debug("Filtando todos os eventos classificados que por operação");

        List<EventoClassificado> eventosPorOperacao = eventos.stream()
                .filter(evento -> !CollectionUtil.isEmpty(evento.getImpactosIndicador())
                        && evento.getImpactosIndicador().stream().filter(impacto -> existeImpacto(impacto)).count() > NumberUtil.INTEGER_ZERO)
                .collect(Collectors.toList());

        if (Iterables.isEmpty(eventosPorOperacao)) {

            LOGGER.debug("Não foi possível localizar os eventos que possuam operações indisponvieis");

            return;
        }

        indisponibilidadeEventoService.consolidar(calculaImpactoUmaOperacao, calculaImpactoTodasOperacoes, eventosPorOperacao);
    }

    private boolean existeImpacto(ImpactoIndicadorEvento impacto) {

        return impacto.getBase() != null && impacto.getOperacao() != null && impacto.getOperacao().getId() > NumberUtil.INTEGER_ZERO;
    }

}
