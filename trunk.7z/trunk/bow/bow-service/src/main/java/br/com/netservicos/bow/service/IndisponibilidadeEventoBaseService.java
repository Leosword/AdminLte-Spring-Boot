package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;

@Service
public class IndisponibilidadeEventoBaseService implements Serializable {

    private static final long serialVersionUID = 3257083773114945618L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeEventoBaseService.class);

    @Autowired
    private IndisponibilidadeEventoOperacaoService indisponbilidadeEventoOperacaoService;

    @Autowired
    private IndisponibilidadeEventoCidadeService indisponibilidadeEventoCidadeService;

    public void consolidar(List<EventoClassificado> eventos) {

        List<EventoClassificado> eventosBase = eventos.stream().filter(evento -> collectEventos(evento)).collect(Collectors.toList());

        if (CollectionUtil.isEmpty(eventosBase)) {

            LOGGER.warn("Não foi possível localizar eventos para a Unidade de Negócio (NET, CLARO TV ou Embratel) ");

            return;
        }

        indisponbilidadeEventoOperacaoService.consolidar(eventosBase);

        indisponibilidadeEventoCidadeService.consolidar(eventosBase);

    }

    private boolean collectEventos(EventoClassificado evento) {

        boolean net = IdentificadorEmpresa.NET.equals(evento.getAplicacao().getEmpresa().getIdentificador());

        boolean claroTV = IdentificadorEmpresa.CLARO_HDTV.equals(evento.getAplicacao().getEmpresa().getIdentificador());

        boolean embratel = IdentificadorEmpresa.EMBRATEL.equals(evento.getAplicacao().getEmpresa().getIdentificador());

        return net || claroTV || embratel;
    }

}
