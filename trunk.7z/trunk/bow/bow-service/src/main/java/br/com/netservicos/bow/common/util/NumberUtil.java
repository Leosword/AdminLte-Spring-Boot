package br.com.netservicos.bow.common.util;

import java.math.BigDecimal;

import org.springframework.util.NumberUtils;

/**
 * Utility Class to handle Numbers
 */
public final class NumberUtil extends NumberUtils {

    public static final BigDecimal BIG_DECIMAL_CEM = new BigDecimal("100");

    public static final Integer INTEGER_ZERO = 0;

    public static final int INTEGER_ONE = 1;

    public static final Integer INTEGER_TWO = 2;

    public static final BigDecimal TOTAL_MINUTOS_DAY = new BigDecimal("60");

    public static final Integer INTEGER_FOUR = 4;
    
    public static final Integer INTEGER_FIVE = 5;

    public static final Long LONG_ZERO = 0L;
    
    public static final Long LONG_THREE = 3L;

    public static final Integer MINUS_ONE = -1;

    private NumberUtil() {
    }

}
