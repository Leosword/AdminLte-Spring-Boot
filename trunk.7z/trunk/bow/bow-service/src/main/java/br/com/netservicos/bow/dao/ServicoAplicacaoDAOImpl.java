package br.com.netservicos.bow.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.Servico;
import br.com.netservicos.bow.model.ServicoAplicacao;

@Repository
public class ServicoAplicacaoDAOImpl implements ServicoAplicacaoDAO {

    private static final long serialVersionUID = -616846057173439792L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public void salvar(List<ServicoAplicacao> niveisAplicacoes) {

        niveisAplicacoes.forEach(servicoAplicacao -> {

            getEntityManager().persist(servicoAplicacao);
        });
    }

    @Override
    public Integer deleteFromServico(Long servicoId) {

        StringBuilder jpqlBuilder = new StringBuilder();

        jpqlBuilder.append("delete from ");
        jpqlBuilder.append("    ServicoAplicacao servicoAplicacao ");
        jpqlBuilder.append(" where ");
        jpqlBuilder.append("    servicoAplicacao.servico.id = :servicoId  ");

        Query query = getEntityManager().createQuery(jpqlBuilder.toString());

        query.setParameter("servicoId", servicoId);

        return query.executeUpdate();
    }

    @Override
    public List<ServicoAplicacao> findByServicoId(Long servicoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select servicoAplicacao from ServicoAplicacao servicoAplicacao ");
        jpql.append("   inner join fetch servicoAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join servicoAplicacao.servico as servico ");
        jpql.append(" where servico.id = :servicoId");

        TypedQuery<ServicoAplicacao> query = getEntityManager().createQuery(jpql.toString(), ServicoAplicacao.class);

        query.setParameter("servicoId", servicoId);

        return query.getResultList();
    }

    @Override
    public List<ServicoAplicacao> findByEmpresa(Empresa empresa, Servico servico) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select servicoAplicacao from ServicoAplicacao servicoAplicacao ");
        jpql.append("   inner join fetch servicoAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.tipo as tipo ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join servicoAplicacao.servico as servico ");
        jpql.append(" where servico.id = :servicoId ");
        jpql.append("   and empresa.id = :empresaId ");

        TypedQuery<ServicoAplicacao> query = getEntityManager().createQuery(jpql.toString(), ServicoAplicacao.class);

        query.setParameter("servicoId", servico.getId());
        query.setParameter("empresaId", empresa.getId());

        return query.getResultList();
    }

    @Override
    public List<ServicoAplicacao> findByEmpresa(Empresa empresa) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select servicoAplicacao from ServicoAplicacao servicoAplicacao ");
        jpql.append("   inner join fetch servicoAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.tipo as tipo ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join fetch servicoAplicacao.servico as servico ");
        jpql.append(" where empresa.id = :empresaId ");

        TypedQuery<ServicoAplicacao> query = getEntityManager().createQuery(jpql.toString(), ServicoAplicacao.class);

        query.setParameter("empresaId", empresa.getId());

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
