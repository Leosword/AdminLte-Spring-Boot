package br.com.netservicos.bow.dao;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.Parametro;

@Repository
public class ParametroDAOImpl implements ParametroDAO {

    private static final long serialVersionUID = 7292731728193321219L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public Optional<Parametro> findByNome(String nome) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select parametro from Parametro parametro ");
        jpql.append("       where parametro.nome = :nome ");

        TypedQuery<Parametro> query = getEntityManager().createQuery(jpql.toString(), Parametro.class);

        query.setParameter("nome", nome);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
