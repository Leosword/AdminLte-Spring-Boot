package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.service.PaggableSelect;

public interface AplicacaoDAO extends Serializable {

    public List<Aplicacao> findAll();

    public List<Aplicacao> findFetchAll();

    public List<Aplicacao> findByTipo(TipoAplicacao tipo);

    public List<Aplicacao> findByEmpresa(Empresa empresa, TipoAplicacao tipo);

    public Long countByTipo(TipoAplicacao tipo);

    public List<Aplicacao> findByPaggebleSelect(PaggableSelect paggable);

    public List<Aplicacao> findByIds(List<Long> aplicacoesId);

    public List<Aplicacao> findByEmpresa(PaggableSelect select);

    public Optional<Aplicacao> findById(Long aplicacaoId);

    public void persistir(Aplicacao aplicacao);

}
