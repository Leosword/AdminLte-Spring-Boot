package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.google.common.collect.Iterables;
import com.google.common.collect.Multimap;

import br.com.netservicos.bow.account.CalculaImpacto;
import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.ImapctoIndisponibilidadeParameter;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.model.ImpactoIndicadorEventoBook;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;
import br.com.netservicos.bow.service.collector.MultimapCollector;

@Service
public class IndisponibilidadeEventoRegionalService implements Serializable {

    private static final long serialVersionUID = -8980808722718466089L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeEventoRegionalService.class);

    @Autowired
    @Qualifier("impactoUmaRegional")
    private CalculaImpacto impactoUmaRegional;

    @Autowired
    @Qualifier("impactoTodasRegionais")
    private CalculaImpacto impactoTodasRegionais;

    @Autowired
    private IndisponibilidadeEventoService indisponibilidadeEventoService;

    @Autowired
    private IndisponibilidadeAplicacaoService indispobilidadeAplicacaoService;

    @Autowired
    private ParametroService parametroService;

    public void consolidar(List<EventoClassificado> eventos) {

        LOGGER.debug("Pesquisando todos os eventos classificados que por regional");

        List<EventoClassificado> eventosPorRegional = eventos.stream()
                .filter(evento -> !CollectionUtil.isEmpty(evento.getImpactosIndicador())
                        && evento.getImpactosIndicador().stream().filter(impacto -> existeImpacto(impacto)).count() > NumberUtil.INTEGER_ZERO)
                .collect(Collectors.toList());

        if (Iterables.isEmpty(eventosPorRegional)) {

            LOGGER.debug("Não foi possível localizar os eventos que possuam regionais indisponvieis");

            return;
        }

        calcula(impactoUmaRegional, impactoTodasRegionais, eventosPorRegional);
    }

    public void calcula(CalculaImpacto impactoUma, CalculaImpacto impactoTodas, List<EventoClassificado> eventos) {

        Parametro parametro = parametroService.findByNome(ParametroConstants.MINUTOS_DIA);

        BigDecimal totalMinutosDia = new BigDecimal(parametro.getValor());

        Multimap<Aplicacao, EventoClassificado> aplicacoes = eventos.stream().collect(MultimapCollector.toMultimap(EventoClassificado::getAplicacao));

        List<IndisponibilidadeEvento> indisponibilidades = new ArrayList<>();

        try {

            aplicacoes.asMap().keySet().iterator().forEachRemaining(aplicacao -> {

                Collection<EventoClassificado> eventosAplicacao = aplicacoes.get(aplicacao);

                Multimap<TipoIndisponibilidadeEvento, EventoClassificado> tipos = eventosAplicacao.stream()
                        .collect(MultimapCollector.toMultimap(EventoClassificado::getTipoIndisponibilidade));

                tipos.asMap().keySet().iterator().forEachRemaining(tipo -> {

                    Collection<EventoClassificado> eventosPorTipo = tipos.get(tipo);

                    eventosPorTipo.forEach(evento -> {

                        Set<ImpactoIndicadorEvento> impactos = evento.getImpactosIndicador();

                        Multimap<Regional, ImpactoIndicadorEvento> regionais = impactos.stream()
                                .collect(MultimapCollector.toMultimap(ImpactoIndicadorEvento::getRegional));

                        regionais.asMap().keySet().iterator().forEachRemaining(regional -> {

                            Collection<ImpactoIndicadorEvento> regionaisImpactadas = regionais.get(regional);

                            Set<ImpactoIndicadorEventoBook> impactosBook = indisponibilidadeEventoService.collectImpactosBook(regionaisImpactadas);

                            Multimap<Date, ImpactoIndicadorEventoBook> dias = impactosBook.stream()
                                    .collect(MultimapCollector.toMultimap(ImpactoIndicadorEventoBook::getInicio));

                            dias.asMap().keySet().iterator().forEachRemaining(dia -> {

                                LOGGER.debug("Iniciando o processo de consolidação dos eventos com aplicação: {} para dia: {}", aplicacao, dia);

                                Collection<ImpactoIndicadorEventoBook> diasImpactados = dias.get(dia);

                                Integer duracao = diasImpactados.stream().mapToInt(ImpactoIndicadorEventoBook::getDuracao).sum();

                                List<BigDecimal> values = new ArrayList<>();

                                BigDecimal valorUma = impactoUma.calcula(
                                        new ImapctoIndisponibilidadeParameter(regionaisImpactadas, aplicacao, regional, totalMinutosDia, dia));

                                BigDecimal valorTodas = impactoTodas
                                        .calcula(new ImapctoIndisponibilidadeParameter(regionaisImpactadas, totalMinutosDia, dia));

                                values.add(valorUma);

                                values.add(valorTodas);

                                BigDecimal percentualMinutos = values.stream().filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);

                                BigDecimal percentualRegional = indisponibilidadeEventoService.calculaIndisponibilidadePorPeso(percentualMinutos,
                                        regional.getPeso());

                                indisponibilidadeEventoService.atualizarPorEvento(evento, dia);

                                IndisponibilidadeEvento indisponibilidade = new IndisponibilidadeEvento(aplicacao, regional, evento, tipo, duracao,
                                        percentualMinutos, percentualRegional, dia);

                                LOGGER.debug("Finalizando o processo de consolidação dos eventos com indisponibilidade: {} para dia: {}",
                                        indisponibilidade, dia);

                                indisponibilidades.add(indisponibilidade);

                            });
                        });

                    });

                });

            });

            indisponibilidadeEventoService.salvar(indisponibilidades);

            indispobilidadeAplicacaoService.consolidar(indisponibilidades);

        } catch (Exception ex) {

            LOGGER.error("Houve um erro! Não foi possível cálcula a indisponbilidade por Evento. Exception: {}", ex);

            throw new BusinessException("Houve um erro! Não foi possível calcular a indisponbilidade por Evento.", ex.getMessage());
        }
    }

    private boolean existeImpacto(ImpactoIndicadorEvento impacto) {

        return impacto.getRegional() != null && impacto.getRegional().getId() > NumberUtil.INTEGER_ZERO;
    }

}
