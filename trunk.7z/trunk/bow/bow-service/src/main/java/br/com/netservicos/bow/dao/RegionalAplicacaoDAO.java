package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.RegionalAplicacao;
import br.com.netservicos.bow.service.PaggableSelect;

public interface RegionalAplicacaoDAO extends Serializable {

    public void salvar(List<RegionalAplicacao> regionaisAplicacoes);

    public List<RegionalAplicacao> findByRegionalId(Long regionalId);

    public Integer deleteFromRegional(Long regionalId);

    public List<RegionalAplicacao> findByPaggebleSelect(PaggableSelect paggable);

    public Optional<RegionalAplicacao> findFetchAllById(Long regionalAplicacaoId);

    public Optional<RegionalAplicacao> findById(Long regionalAplicacaoId);

    public Integer deleteFromBase(Long id);

}
