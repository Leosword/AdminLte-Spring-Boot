package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;

public interface IndisponibilidadeAplicacaoMensalDAO extends Serializable {

    public Optional<IndisponibilidadeAplicacaoMensal> findByPeriodo(Integer ano, Integer mes, Aplicacao aplicacao);

    public void atualizar(IndisponibilidadeAplicacaoMensal indisponibilidade);

    public void salvar(IndisponibilidadeAplicacaoMensal indisponibilidade);

    public List<IndisponibilidadeAplicacaoMensal> findByAno(Integer ano, List<Aplicacao> aplicacoes);

    public List<IndisponibilidadeAplicacaoMensal> findByPeriodoAno(Integer inicio, Integer fim, List<Aplicacao> aplicacoes);
    
    public List<IndisponibilidadeAplicacaoMensal> findByPeriodo(Integer ano, Integer mes, List<Aplicacao> aplicacoes);

    public List<IndisponibilidadeAplicacaoMensal> findByPeriodoAplicacao(Integer ano, Integer mes, Aplicacao aplicacao);

}
