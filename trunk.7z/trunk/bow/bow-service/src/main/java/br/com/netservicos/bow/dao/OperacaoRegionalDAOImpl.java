package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Operacao;
import br.com.netservicos.bow.model.OperacaoRegional;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.RegionalAplicacao;

@Repository
public class OperacaoRegionalDAOImpl implements OperacaoRegionalDAO {

    private static final long serialVersionUID = 2652671850192228742L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<OperacaoRegional> findAll() {

        TypedQuery<OperacaoRegional> query = getEntityManager().createNamedQuery("OperacaoRegional.findAll", OperacaoRegional.class);

        return query.getResultList();
    }

    @Override
    public List<OperacaoRegional> findFecthAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select operacaoRegional from OperacaoRegional operacaoRegional ");
        jpql.append("   inner join fetch operacaoRegional.regionalAplicacao as regionalAplicacao ");
        jpql.append("   inner join fetch operacaoRegional.operacao as operacao ");
        jpql.append("   inner join fetch regionalAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join fetch regionalAplicacao.regional as regional ");
        jpql.append("   where operacaoRegional.desativacao is null ");

        TypedQuery<OperacaoRegional> query = getEntityManager().createQuery(jpql.toString(), OperacaoRegional.class);

        return query.getResultList();
    }

    @Override
    public void salvar(List<OperacaoRegional> operacoesRegionais) {

        operacoesRegionais.forEach(operacaoRegional -> {

            getEntityManager().persist(operacaoRegional);
        });
    }

    @Override
    public Integer deletar(Long operacaoRegionalId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" update OperacaoRegional set ");
        jpql.append("   desativacao = :desativacao ");
        jpql.append(" where id = :operacaoRegionalId ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("desativacao", new Date());
        query.setParameter("operacaoRegionalId", operacaoRegionalId);

        return query.executeUpdate();
    }

    @Override
    public Long findTotalByAplicacao(Regional regional, Aplicacao aplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select count(*) from OperacaoRegional operacaoRegional ");
        jpql.append("   inner join operacaoRegional.regionalAplicacao as regionalAplicacao ");
        jpql.append("   inner join regionalAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join regionalAplicacao.regional as regional ");
        jpql.append("   inner join operacaoRegional.operacao as operacao ");
        jpql.append(" where operacaoRegional.desativacao is null ");
        jpql.append("   and regional.id = :regionalId ");
        jpql.append("   and aplicacao.id = :aplicacaoId ");
        jpql.append("   and regionalAplicacao.desativacao is null ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("regionalId", regional.getId());
        query.setParameter("aplicacaoId", aplicacao.getId());

        return DAOUtil.getSingleResult(query);
    }

    @Override
    public Optional<OperacaoRegional> findByRegionalAplicacao(RegionalAplicacao regionalAplicacao, Operacao operacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select regionalAplicacaoOperacao from OperacaoRegional regionalAplicacaoOperacao ");
        jpql.append("   inner join regionalAplicacaoOperacao.regionalAplicacao as regionalAplicacao ");
        jpql.append("   inner join regionalAplicacaoOperacao.operacao as operacao ");
        jpql.append(" where regionalAplicacao.id = :regionalAplicacaoId ");
        jpql.append("   and operacao.id = :operacaoId ");
        jpql.append("   and regionalAplicacao.desativacao is null ");
        jpql.append("   and regionalAplicacaoOperacao.desativacao is null ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("regionalAplicacaoId", regionalAplicacao.getId());
        query.setParameter("operacaoId", operacao.getId());

        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}