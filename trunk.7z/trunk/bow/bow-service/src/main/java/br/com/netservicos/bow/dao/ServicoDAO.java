package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Servico;

public interface ServicoDAO extends Serializable {

    public List<Servico> findAllAtivas();

    public void salvar(Servico servico);

    public Optional<Servico> findById(Long id);

    public Integer deletar(Long id);
    
    public Optional<Servico> findByNome(String nome);

}
