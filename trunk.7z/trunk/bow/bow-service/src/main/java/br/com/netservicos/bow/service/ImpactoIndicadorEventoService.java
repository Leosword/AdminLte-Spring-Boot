package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.dao.ImpactoIndicadorEventoDAO;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;

@Service
public class ImpactoIndicadorEventoService implements Serializable {

    private static final long serialVersionUID = 3249993495135436177L;

    @Autowired
    private ImpactoIndicadorEventoDAO impactoIndicadorEventoDAO;

    private static final Logger LOGGER = LoggerFactory.getLogger(ImpactoIndicadorEventoService.class);

    public List<ImpactoIndicadorEvento> findByEvento(Long eventoId) {

        LOGGER.debug("Pesquisando os impactos para o Evento com id: {}", eventoId);

        return impactoIndicadorEventoDAO.findByEvento(eventoId);
    }

}
