package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.DashboardConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.enums.TipoConfiguracaoIndisponibilidade;

@Repository
public class DashboardConfiguracaoIndisponibilidadeDAOImpl implements DashboardConfiguracaoIndisponibilidadeDAO {

    private static final long serialVersionUID = -4483072538625873772L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<DashboardConfiguracaoIndisponibilidade> findFecthAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select configuracao from DashboardConfiguracaoIndisponibilidade configuracao ");
        jpql.append("   inner join fetch configuracao.empresa as empresa ");
        jpql.append("   order by configuracao.data asc ");

        TypedQuery<DashboardConfiguracaoIndisponibilidade> query = getEntityManager().createQuery(jpql.toString(),
                DashboardConfiguracaoIndisponibilidade.class);

        return query.getResultList();
    }

    @Override
    public void salvar(DashboardConfiguracaoIndisponibilidade configuracao) {

        if (configuracao.getId() == null) {

            getEntityManager().persist(configuracao);

        } else {

            getEntityManager().merge(configuracao);
        }
    }

    @Override
    public Integer deletar(List<Long> configuracaoIds) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" delete from DashboardConfiguracaoIndisponibilidade  ");
        jpql.append(" where id in (:configuracaoIds) ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("configuracaoIds", configuracaoIds);

        return query.executeUpdate();
    }

    @Override
    public Optional<DashboardConfiguracaoIndisponibilidade> findByEmpresa(Empresa empresa, TipoConfiguracaoIndisponibilidade tipo, Date data) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select configuracao from DashboardConfiguracaoIndisponibilidade configuracao ");
        jpql.append("   inner join configuracao.empresa as empresa ");
        jpql.append("   where empresa.id = :empresaId ");
        jpql.append("   and configuracao.tipo = :tipo ");
        jpql.append("   and configuracao.data = :data ");

        TypedQuery<DashboardConfiguracaoIndisponibilidade> query = getEntityManager().createQuery(jpql.toString(),
                DashboardConfiguracaoIndisponibilidade.class);

        query.setParameter("empresaId", empresa.getId());
        query.setParameter("tipo", tipo);
        query.setParameter("data", data, TemporalType.DATE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<DashboardConfiguracaoIndisponibilidade> findByEmpresa(Empresa empresa, Date data) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select configuracao from DashboardConfiguracaoIndisponibilidade configuracao ");
        jpql.append("   inner join configuracao.empresa as empresa ");
        jpql.append("   where empresa.id = :empresaId ");
        jpql.append("   and configuracao.data = :data ");

        TypedQuery<DashboardConfiguracaoIndisponibilidade> query = getEntityManager().createQuery(jpql.toString(),
                DashboardConfiguracaoIndisponibilidade.class);

        query.setParameter("empresaId", empresa.getId());
        query.setParameter("data", data, TemporalType.DATE);

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}