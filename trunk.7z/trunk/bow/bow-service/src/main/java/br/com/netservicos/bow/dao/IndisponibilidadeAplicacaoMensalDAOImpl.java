package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;

@Repository
public class IndisponibilidadeAplicacaoMensalDAOImpl implements IndisponibilidadeAplicacaoMensalDAO {

    private static final long serialVersionUID = 3098432506125076023L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public void salvar(IndisponibilidadeAplicacaoMensal indisponibilidade) {

        getEntityManager().persist(indisponibilidade);
    }

    @Override
    public void atualizar(IndisponibilidadeAplicacaoMensal indisponibilidade) {

        getEntityManager().merge(indisponibilidade);
    }

    @Override
    public Optional<IndisponibilidadeAplicacaoMensal> findByPeriodo(Integer ano, Integer mes, Aplicacao aplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacaoMensal indisponibilidade ");
        jpql.append("       inner join indisponibilidade.aplicacao aplicacao ");
        jpql.append("   where YEAR(indisponibilidade.criacao) = :ano ");
        jpql.append("       and MONTH(indisponibilidade.criacao) = :mes  ");
        jpql.append("       and aplicacao.id = :aplicacaoId ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeAplicacaoMensal> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacaoMensal.class);

        query.setParameter("aplicacaoId", aplicacao.getId());
        query.setParameter("ano", ano);
        query.setParameter("mes", mes);

        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public List<IndisponibilidadeAplicacaoMensal> findByAno(Integer ano, List<Aplicacao> aplicacoes) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacaoMensal indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("       inner join fetch aplicacao.empresa empresa ");
        jpql.append("   where YEAR(indisponibilidade.criacao) = :ano ");
        jpql.append("       and aplicacao in (:aplicacoes) ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeAplicacaoMensal> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacaoMensal.class);

        query.setParameter("aplicacoes", aplicacoes);
        query.setParameter("ano", ano);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeAplicacaoMensal> findByPeriodoAno(Integer inicio, Integer fim, List<Aplicacao> aplicacoes) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacaoMensal indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("   where YEAR(indisponibilidade.criacao) between :inicio and :fim");
        jpql.append("       and aplicacao in (:aplicacoes) ");
        jpql.append("       and indisponibilidade.desativacao is null ");
        jpql.append("       order by YEAR(indisponibilidade.criacao) asc ");

        TypedQuery<IndisponibilidadeAplicacaoMensal> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacaoMensal.class);

        query.setParameter("aplicacoes", aplicacoes);
        query.setParameter("inicio", inicio);
        query.setParameter("fim", fim);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeAplicacaoMensal> findByPeriodo(Integer ano, Integer mes, List<Aplicacao> aplicacoes) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacaoMensal indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("   where YEAR(indisponibilidade.criacao) = :ano ");
        jpql.append("       and MONTH(indisponibilidade.criacao) = :mes  ");
        jpql.append("       and aplicacao in (:aplicacoes) ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeAplicacaoMensal> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacaoMensal.class);

        query.setParameter("aplicacoes", aplicacoes);
        query.setParameter("ano", ano);
        query.setParameter("mes", mes);

        return query.getResultList();
    }

    @Override
    public List<IndisponibilidadeAplicacaoMensal> findByPeriodoAplicacao(Integer ano, Integer mes, Aplicacao aplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select indisponibilidade from IndisponibilidadeAplicacaoMensal indisponibilidade ");
        jpql.append("       inner join fetch indisponibilidade.aplicacao aplicacao ");
        jpql.append("   where YEAR(indisponibilidade.criacao) = :ano ");
        jpql.append("       and MONTH(indisponibilidade.criacao) = :mes  ");
        jpql.append("       and aplicacao.id = :aplicacaoId ");
        jpql.append("       and indisponibilidade.desativacao is null ");

        TypedQuery<IndisponibilidadeAplicacaoMensal> query = getEntityManager().createQuery(jpql.toString(), IndisponibilidadeAplicacaoMensal.class);

        query.setParameter("aplicacaoId", aplicacao.getId());
        query.setParameter("ano", ano);
        query.setParameter("mes", mes);

        return query.getResultList();
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
