package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Usuario;

public interface UsuarioDAO extends Serializable {

    public List<Usuario> findAll();

    public List<Usuario> findFetchAll();

    public void persistir(Usuario usuario);

    public Optional<Usuario> findByEmail(String email);

    public Optional<Usuario> findByLogin(String login);

    public Integer deletar(Long id);
    
    public Optional<Usuario> findByIdFetchAll(Long id);
    
    public Optional<Usuario> findById(Long id);

    public List<Usuario> findNomeUsuarioByPerfil(String nomePerfil);

}
