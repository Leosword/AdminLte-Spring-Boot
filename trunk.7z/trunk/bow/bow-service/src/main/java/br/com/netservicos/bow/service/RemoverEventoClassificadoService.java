package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.EventoClassificadoDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.model.ImpactoIndicadorEventoBook;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.Periodo;

@Service
public class RemoverEventoClassificadoService implements Serializable {

    private static final long serialVersionUID = -2480066709497859521L;

    private static final Logger LOGGER = LoggerFactory.getLogger(RemoverEventoClassificadoService.class);

    @Autowired
    private IndisponibilidadeEventoService indisponibilidadeEventoService;

    @Autowired
    private IndisponibilidadeAplicacaoService indisponibilidadeAplicacaoService;

    @Autowired
    private EventoClassificadoDAO eventoClassificadoDAO;

    @Transactional
    public void remover(Long eventoId) {

        LOGGER.debug("Pesquisando o evento com Id: {}", eventoId);

        EventoClassificado evento = eventoClassificadoDAO.findFetchAllById(eventoId);

        if (Objects.isNull(evento)) {

            LOGGER.error("Não possível localizar o evento com Id: {}", evento);

            throw new BusinessException("Não foi possível localizar o evento.");
        }

        Optional<IndisponibilidadeEvento> indisponibilidade = indisponibilidadeEventoService.findByEvento(evento);

        if (!indisponibilidade.isPresent()) {

            LOGGER.error("Não foi possível localizar indisponibilidade para o evento: {}", evento);

            throw new BusinessException("Não foi possível localizar indisponibilidade com o evento.");
        }

        IndisponibilidadeEvento indisponibilidadeEvento = indisponibilidade.get();

        indisponibilidadeEvento.setDesativacao(new Date());

        indisponibilidadeEventoService.atualizar(indisponibilidadeEvento);

        Periodo periodo = getPeriodo(evento);

        List<IndisponibilidadeEvento> indisponibilidades = indisponibilidadeEventoService.findByPeriodoAplicacao(evento.getAplicacao(),
                evento.getTipoIndisponibilidade(), periodo);

        indisponibilidadeAplicacaoService.consolidar(indisponibilidades);
    }

    private Periodo getPeriodo(EventoClassificado evento) {

        Set<ImpactoIndicadorEvento> impactosIndicador = evento.getImpactosIndicador();

        Set<Set<ImpactoIndicadorEventoBook>> impactosBook = impactosIndicador.stream().map(impacto -> impacto.getImpactosBook())
                .collect(Collectors.toSet());

        Set<ImpactoIndicadorEventoBook> impactos = impactosBook.stream().flatMap(Set::stream).collect(Collectors.toSet());

        Optional<Date> inicio = impactos.stream().sorted(inicioImpacto()).map(impacto -> impacto.getInicio()).findFirst();

        Optional<Date> termino = impactos.stream().sorted(terminoImpacto()).map(impacto -> impacto.getTermino()).findFirst();

        return new Periodo(inicio.get(), termino.get());
    }

    public Comparator<ImpactoIndicadorEventoBook> inicioImpacto() {

        return (inicio, fim) -> inicio.getInicio().compareTo(fim.getInicio());
    }

    public Comparator<ImpactoIndicadorEventoBook> terminoImpacto() {

        Comparator<ImpactoIndicadorEventoBook> compare = (inicio, fim) -> inicio.getTermino().compareTo(fim.getTermino());

        return compare.reversed();
    }

}