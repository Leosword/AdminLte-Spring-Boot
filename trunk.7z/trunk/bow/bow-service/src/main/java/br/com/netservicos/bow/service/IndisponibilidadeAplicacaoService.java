package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Iterables;
import com.google.common.collect.Multimap;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.dao.EmpresaDAO;
import br.com.netservicos.bow.dao.IndisponibilidadeAplicacaoDAO;
import br.com.netservicos.bow.dao.IndisponibilidadeEventoDAO;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacao;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoParameter;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.service.collector.MultimapCollector;

@Service
public class IndisponibilidadeAplicacaoService implements Serializable {

    private static final long serialVersionUID = 3085458629622489652L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeAplicacaoService.class);

    @Autowired
    private IndisponibilidadeAplicacaoDAO indisponibilidadeAplicacaoDAO;

    @Autowired
    private IndisponibilidadeEventoDAO indisponibilidadeEventoDAO;

    @Autowired
    private EmpresaDAO empresaDAO;

    @Autowired
    private CalculaIndisponibilidadeEventoService calculaIndisponibilidadeEventoService;

    @Autowired
    private IndisponibilidadeAplicacaoMensalService indisponibilidadeAplicacaoMensalService;

    @Autowired
    private ParametroService parametroService;

    public void consolidar(List<IndisponibilidadeEvento> indisponibilidades) {

        LOGGER.debug("Iniciando o processo de consolidação de Indisponibilidade por aplicação");

        Parametro parametro = parametroService.findByNome(ParametroConstants.MINUTOS_DIA);

        List<IndisponibilidadeAplicacao> aplicacoesIndisponiveis = new ArrayList<>();

        Multimap<Date, IndisponibilidadeEvento> dias = indisponibilidades.stream()
                .collect(MultimapCollector.toMultimap(IndisponibilidadeEvento::getInicio));

        dias.asMap().keySet().iterator().forEachRemaining(dia -> {

            Collection<IndisponibilidadeEvento> diasIndisponiveis = dias.get(dia);

            Multimap<Aplicacao, IndisponibilidadeEvento> aplicacoes = diasIndisponiveis.stream()
                    .collect(MultimapCollector.toMultimap(IndisponibilidadeEvento::getAplicacao));

            aplicacoes.asMap().keySet().iterator().forEachRemaining(aplicacao -> {

                Collection<IndisponibilidadeEvento> aplicacoesImpactas = aplicacoes.get(aplicacao);

                Multimap<TipoIndisponibilidadeEvento, IndisponibilidadeEvento> tipos = aplicacoesImpactas.stream()
                        .collect(MultimapCollector.toMultimap(IndisponibilidadeEvento::getTipoIndisponbilidade));

                tipos.asMap().keySet().iterator().forEachRemaining(tipo -> {

                    try {

                        LOGGER.debug("Pesquisando Indisponibilidade da aplicacação: {}, para o dia: {}, com o tipo: {}", aplicacao, dia, tipo);

                        List<IndisponibilidadeEvento> indisponibilidadesEvento = indisponibilidadeEventoDAO.findByAplicacao(dia, aplicacao, tipo);

                        atualizarIndisponibilidade(aplicacao, dia, tipo);

                        IndisponibilidadeAplicacaoParameter parameter = new IndisponibilidadeAplicacaoParameter(parametro.getValor(), aplicacao, dia,
                                tipo);

                        adicionaIndisponibilidadePorBase(parameter, aplicacoesIndisponiveis, indisponibilidadesEvento);

                        adicionaIndisponibilidadePorRegional(parameter, aplicacoesIndisponiveis, indisponibilidadesEvento);

                    } catch (Exception ae) {

                        LOGGER.error(
                                "Erro ao realizar a operação de cálculo de IndisponbilidadeAplicação para aplicação: {}, dia: {} e tipo: {}. Ex.: {}",
                                aplicacao, dia, tipo, ae);

                        throw ae;
                    }

                });

                LOGGER.debug("Finalizando o consolidado de indisponibilidade aplicação para o dia: {}", dia);
            });

        });

        salvar(aplicacoesIndisponiveis);

        indisponibilidadeAplicacaoMensalService.consolida(aplicacoesIndisponiveis);
    }

    private void adicionaIndisponibilidadePorBase(IndisponibilidadeAplicacaoParameter parameter,
            List<IndisponibilidadeAplicacao> aplicacoesIndisponiveis, List<IndisponibilidadeEvento> indisponibilidadesEvento) {

        List<IndisponibilidadeEvento> indisponibilidades = indisponibilidadesEvento.stream()
                .filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getBase())).collect(Collectors.toList());

        if (CollectionUtil.isEmpty(indisponibilidades)) {

            LOGGER.debug("Não foi possível localizar indisponibilidades por base!");

            return;
        }

        MinutosIndisponibilidade indisponibilidade = calculaIndisponibilidadeEventoService.calculaMinutosBase(indisponibilidades,
                parameter.getMinutosDia());

        MinutosIndisponibilidade indisponibilidadePostPatch = calculaIndisponibilidadeEventoService.calculaMinutosPosPatchBase(indisponibilidades,
                parameter.getMinutosDia());

        IndisponibilidadeAplicacao indisponibilidadeAplicacao = new IndisponibilidadeAplicacao(parameter.getAplicacao(), parameter.getTipo(),
                indisponibilidade.getMinutos(), indisponibilidade.getPercentual(), indisponibilidadePostPatch.getMinutos(),
                indisponibilidadePostPatch.getPercentual(), parameter.getInicio());

        aplicacoesIndisponiveis.add(indisponibilidadeAplicacao);
    }

    private void adicionaIndisponibilidadePorRegional(IndisponibilidadeAplicacaoParameter parameter,
            List<IndisponibilidadeAplicacao> aplicacoesIndisponiveis, List<IndisponibilidadeEvento> indisponibilidadesEvento) {

        List<IndisponibilidadeEvento> indisponibilidades = indisponibilidadesEvento.stream()
                .filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getRegional())).collect(Collectors.toList());

        if (CollectionUtil.isEmpty(indisponibilidades)) {

            LOGGER.debug("Não foi possível localizar indisponibilidades por regional!");

            return;
        }

        MinutosIndisponibilidade indisponibilidade = calculaIndisponibilidadeEventoService.calculaMinutosRegional(indisponibilidades,
                parameter.getMinutosDia());

        MinutosIndisponibilidade indisponibilidadePostPatch = calculaIndisponibilidadeEventoService.calculaMinutosPosPatchRegional(indisponibilidades,
                parameter.getMinutosDia());

        IndisponibilidadeAplicacao indisponibilidadeAplicacao = new IndisponibilidadeAplicacao(parameter.getAplicacao(), parameter.getTipo(),
                indisponibilidade.getMinutos(), indisponibilidade.getPercentual(), indisponibilidadePostPatch.getMinutos(),
                indisponibilidadePostPatch.getPercentual(), parameter.getInicio());

        aplicacoesIndisponiveis.add(indisponibilidadeAplicacao);
    }

    public void atualizarIndisponibilidade(Aplicacao aplicacao, Date dia, TipoIndisponibilidadeEvento tipo) {

        Optional<IndisponibilidadeAplicacao> indisponibilidade = indisponibilidadeAplicacaoDAO.findByDia(aplicacao, dia, tipo);

        if (indisponibilidade.isPresent()) {

            IndisponibilidadeAplicacao indisponibilidadeAplicacao = indisponibilidade.get();

            indisponibilidadeAplicacao.setDesativacao(new Date());

            indisponibilidadeAplicacaoDAO.atualizar(indisponibilidadeAplicacao);
        }
    }

    @Transactional
    public void salvar(List<IndisponibilidadeAplicacao> aplicacoesIndisponiveis) {

        LOGGER.debug("Persistindo o total de: {} indiponibilidade de aplicação", aplicacoesIndisponiveis.size());

        aplicacoesIndisponiveis.forEach(indisponibilidade -> {

            indisponibilidadeAplicacaoDAO.salvar(indisponibilidade);
        });
    }

    public List<IndisponibilidadeAplicacao> findByPeriodo(Date inicio, Date fim, List<Aplicacao> aplicacoes) {

        LOGGER.debug("Pesquisando indisponbilidade de aplicação no periodo: {}, {}", inicio, fim);

        return indisponibilidadeAplicacaoDAO.findByPeriodo(inicio, fim, aplicacoes);
    }

    public List<IndisponibilidadeAplicacao> findByPeriodo(Date inicio, Date fim, String identificador) {

        Optional<Empresa> empresa = empresaDAO.findByIdentificador(IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(identificador)));

        if (!empresa.isPresent()) {

            LOGGER.error("Não foi possível localizar a empresa com o Identificador: {}", identificador);

            return Collections.emptyList();
        }

        LOGGER.debug("Pesquisando indisponbilidade de aplicação no periodo: {}, {}", inicio, fim);

        return indisponibilidadeAplicacaoDAO.findByPeriodo(inicio, fim, empresa.get());
    }

    public BigDecimal findByTipo(List<IndisponibilidadeAplicacao> indisponibilidades, String tipo) {

        List<IndisponibilidadeAplicacao> aplicacoesIndisponiveis = indisponibilidades.stream()
                .filter(evento -> tipo.equals(evento.getTipoIndisponbilidade().getDescricao())).collect(Collectors.toList());

        if (Iterables.isEmpty(aplicacoesIndisponiveis)) {

            return BigDecimal.ZERO;
        }

        return aplicacoesIndisponiveis.stream().filter(Objects::nonNull).map(aplicacao -> aplicacao.getTotalMinutos())
                .reduce(BigDecimal.ZERO, BigDecimal::add).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);
    }

}
