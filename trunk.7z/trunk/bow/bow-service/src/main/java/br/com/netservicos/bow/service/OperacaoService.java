package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.OperacaoDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Operacao;

@Service
public class OperacaoService implements Serializable {

    private static final long serialVersionUID = 8650283393081741236L;

    private static final Logger LOGGER = LoggerFactory.getLogger(OperacaoService.class);

    @Autowired
    private OperacaoDAO operacaoDAO;

    public List<Operacao> findAllAtivas() {

        LOGGER.debug("Pesquisando todas as operações ativas");

        return operacaoDAO.findAllAtivas();
    }

    public List<Operacao> findFetchAll() {

        LOGGER.debug("Pesquisando todas as operacões ");

        return operacaoDAO.findFetchAll();
    }

    public Optional<Operacao> findById(Long id) {

        LOGGER.debug("Pesquisando a operacao com o Id: {}", id);

        return operacaoDAO.findById(id);
    }

    public Optional<Operacao> findByIdFetchAll(Long id) {

        LOGGER.debug("Pesquisando a operacao com o Id: {}", id);

        return operacaoDAO.findByIdFetchAll(id);
    }

    @Transactional
    public void deletar(Long[] ids) {

        if (Objects.isNull(ids)) {

            throw new BusinessException("Não foi possível localizar as informações corretas para excluir o(s) registro(s).");
        }

        LOGGER.debug("Removendo os registros com Ids: {}", new Object[] { ids });

        for (Long id : ids) {

            operacaoDAO.deletar(id);
        }

    }

    public List<Operacao> findByPaggebleSelect(PaggableSelect paggable) {

        return operacaoDAO.findByPaggebleSelect(paggable);
    }

}
