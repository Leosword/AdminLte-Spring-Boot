package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.PerfilDAO;
import br.com.netservicos.bow.dao.UsuarioDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Perfil;
import br.com.netservicos.bow.model.Usuario;

@Service
public class UsuarioService implements Serializable {

    private static final long serialVersionUID = -666644187111664749L;

    private static final String SEPARATOR = "_";

    private static final String ALIAS_PERMISSION = "ROLE";

    private static final Logger LOGGER = LoggerFactory.getLogger(UsuarioService.class);

    @Autowired
    private UsuarioDAO usuarioDAO;

    @Autowired
    private PerfilDAO perfilDAO;

    public List<Usuario> findAll() {

        LOGGER.debug("Pesquisando todos os registros do usuário");

        return usuarioDAO.findAll();
    }

    public List<Usuario> findFetchAll() {

        LOGGER.debug("Pesquisando todos os registros do usuário");

        return usuarioDAO.findFetchAll();
    }

    public Optional<Usuario> findByIdFetchAll(Long id) {

        LOGGER.debug("Pesquisando o usuário com o Id: {}", id);

        return usuarioDAO.findByIdFetchAll(id);
    }

    public Optional<Usuario> findById(Long id) {

        LOGGER.debug("Pesquisando o usuário com o Id: {}", id);

        return usuarioDAO.findById(id);
    }

    @Transactional
    public void salvar(Usuario usuario, String nomePerfil) {

        if (!usuario.getSenha().equals(usuario.getConfirmarSenha())) {

            throw new BusinessException("Senha inválida!");
        }

        Optional<Perfil> perfil = perfilDAO.findByNome(nomePerfil);

        if (!perfil.isPresent()) {

            LOGGER.error("Não foi possível salvar o Usuário: {}: Perfil : {} não foi localizado.", usuario, nomePerfil);

            throw new BusinessException("Não foi possível localizar o perfil");
        }

        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        String senhaCriptografada = passwordEncoder.encode(usuario.getSenha());

        usuario.setSenha(senhaCriptografada);

        usuario.setConfirmarSenha(senhaCriptografada);

        usuario.setPerfil(perfil.get());

        LOGGER.debug("Persistindo o usuário: {}", usuario);

        usuarioDAO.persistir(usuario);
    }

    @Transactional
    public void salvar(Usuario usuario, String nomePerfil, boolean trocarsenha) {

        if (!usuario.getSenha().equals(usuario.getConfirmarSenha())) {

            throw new BusinessException("Senha inválida!");
        }

        Optional<Perfil> perfil = perfilDAO.findByNome(nomePerfil);

        if (!perfil.isPresent()) {

            LOGGER.error("Não foi possível salvar o Usuário: {}: Perfil : {} não foi localizado.", usuario, nomePerfil);

            throw new BusinessException("Não foi possível localizar o perfil");
        }

        if (trocarsenha) {

            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

            String senhaCriptografada = passwordEncoder.encode(usuario.getSenha());

            usuario.setSenha(senhaCriptografada);

            usuario.setConfirmarSenha(senhaCriptografada);
        }

        usuario.setPerfil(perfil.get());

        LOGGER.debug("Persistindo o usuário: {}", usuario);

        usuarioDAO.persistir(usuario);
    }

    public Optional<Usuario> findByEmail(String email) {

        LOGGER.info("Pesquisando o usuário por email: {}", email);

        return usuarioDAO.findByEmail(email);
    }

    @Transactional
    public void deletar(Long[] ids) {

        LOGGER.debug("Removendo os registros com Ids: {}", new Object[] { ids });

        for (Long id : ids) {

            usuarioDAO.deletar(id);
        }
    }

    public List<GrantedAuthority> carregarPerfil(Perfil perfil) {

        List<GrantedAuthority> grantsAuthority = new ArrayList<>();

        String nome = perfil.getNome();

        String permission = String.join(SEPARATOR, ALIAS_PERMISSION, nome);

        grantsAuthority.add(new SimpleGrantedAuthority(permission));

        return grantsAuthority;
    }

    public Optional<Usuario> findByLogin(String login) {

        LOGGER.debug("Pesquisando o usuário com o login: {}", login);

        return usuarioDAO.findByLogin(login);
    }

    public List<Usuario> findNomeUsuarioByPerfil(String nomePerfil) {
        
        LOGGER.debug("Pesquisando os usuários com Perfil: {}", nomePerfil);
        
        return usuarioDAO.findNomeUsuarioByPerfil(nomePerfil);
    }
}
