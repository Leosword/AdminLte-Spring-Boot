package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.netservicos.bow.dao.BaseAplicacaoDAO;
import br.com.netservicos.bow.model.BaseAplicacao;

@Service
public class BaseAplicacaoService implements Serializable {

    private static final long serialVersionUID = 8254465585403539099L;

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseAplicacaoService.class);

    @Autowired
    private BaseAplicacaoDAO baseAplicacaoDAO;

    public List<BaseAplicacao> findByAplicacoes(Long baseId) {

        LOGGER.debug("Pesquisando a base com o Id: {}", baseId);

        return baseAplicacaoDAO.findByBaseId(baseId);
    }

    public List<BaseAplicacao> findByPaggebleSelect(PaggableSelect paggable) {

        LOGGER.debug("Pesquisando as basesaplicações com página: {}", paggable);

        return baseAplicacaoDAO.findByPaggebleSelect(paggable);
    }

    public Optional<BaseAplicacao> findFetchAllById(Long baseAplicacaoId) {

        LOGGER.debug("Pesquisando a base aplicação com Id: {}", baseAplicacaoId);

        return baseAplicacaoDAO.findFetchAllById(baseAplicacaoId);
    }

}
