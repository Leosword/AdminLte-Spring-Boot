package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.dao.OperacaoDAO;
import br.com.netservicos.bow.dao.OperacaoRegionalDAO;
import br.com.netservicos.bow.dao.RegionalAplicacaoDAO;
import br.com.netservicos.bow.dao.UsuarioDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Operacao;
import br.com.netservicos.bow.model.OperacaoRegional;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.RegionalAplicacao;
import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.service.authetication.Principal;

@Service
public class OperacaoRegionalService implements Serializable {

    private static final long serialVersionUID = 3355605168044343422L;

    private static final Logger LOGGER = LoggerFactory.getLogger(OperacaoRegionalService.class);

    @Autowired
    private OperacaoRegionalDAO dao;

    @Autowired
    private OperacaoDAO operacaoDAO;

    @Autowired
    private RegionalAplicacaoDAO regionalAplicacaoDAO;

    @Autowired
    private UsuarioDAO usuarioDAO;

    public List<OperacaoRegional> findAll() {

        LOGGER.debug("Pesquisando todos os registros da aplicação que tem vinculo com operação");

        return dao.findAll();
    }

    public List<OperacaoRegional> findFecthAll() {

        LOGGER.debug("Pesquisando todas as as aplicações com operação e regional.");

        return dao.findFecthAll();
    }

    @Transactional
    public void salvar(Long regionalAplicacaoId, Long[] operacoesIds) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ((authentication instanceof AnonymousAuthenticationToken)) {

            throw new BusinessException("Não foi possível localizar usuário autenticado.");
        }

        Principal principal = (Principal) authentication.getPrincipal();

        Optional<Usuario> usuario = usuarioDAO.findByEmail(principal.getEmail());

        if (!usuario.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com email: {}", principal.getEmail());

            throw new BusinessException("Não foi possível localizar usuário");
        }

        List<Operacao> operacoes = operacaoDAO.findByIds(Arrays.asList(operacoesIds));

        if (Iterables.isEmpty(operacoes)) {

            LOGGER.error("Não foi possível localizar as operações com os Ids: {}", new Object[] { operacoesIds });

            throw new BusinessException("Não foi possível localizar as operações.");
        }

        Optional<RegionalAplicacao> regionalAplicacaoOptional = regionalAplicacaoDAO.findById(regionalAplicacaoId);

        if (!regionalAplicacaoOptional.isPresent()) {

            throw new BusinessException("Não foi possível localizar a Aplicação");
        }

        List<OperacaoRegional> operacoesRegionais = new ArrayList<>();

        RegionalAplicacao regionalAplicacao = regionalAplicacaoOptional.get();

        operacoes.forEach(operacao -> {

            Optional<OperacaoRegional> operacaoRegionalOptional = dao.findByRegionalAplicacao(regionalAplicacao, operacao);

            if (!operacaoRegionalOptional.isPresent()) {

                OperacaoRegional operacaoRegional = new OperacaoRegional(regionalAplicacao, operacao, usuario.get());

                operacoesRegionais.add(operacaoRegional);
            }

        });

        dao.salvar(operacoesRegionais);
    }

    public Long totalByAplicacao(Regional regional, Aplicacao aplicacao) {

        LOGGER.debug("Pesquisando o total de operacoes para Regional: {} e Aplicação: {}", regional, aplicacao);

        return dao.findTotalByAplicacao(regional, aplicacao);
    }

    @Transactional
    public void deletar(Long[] ids) {

        if (Objects.isNull(ids)) {

            throw new BusinessException("Não foi possível localizar as informações corretas para excluir o(s) registro(s).");
        }

        LOGGER.debug("Removendo os registros com Ids: {}", new Object[] { ids });

        for (Long id : ids) {

            dao.deletar(id);
        }
    }

}
