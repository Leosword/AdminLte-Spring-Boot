package br.com.netservicos.bow.service;

import java.io.Serializable;

public class PaggableTable implements Serializable {

    private static final long serialVersionUID = -6472490765106418105L;

    private Integer page;

    private String offset;

    private String limit;

    private String order;

    private Long id;

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public String getOffset() {
        return offset;
    }

    public void setOffset(String offset) {
        this.offset = offset;
    }

    public String getLimit() {
        return limit;
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
