package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class BaseAplicacaoDAOImpl implements BaseAplicacaoDAO {

    private static final long serialVersionUID = 1722747212274070556L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public void salvar(List<BaseAplicacao> basesAplicacoes) {

        basesAplicacoes.forEach(baseAplicacao -> {

            getEntityManager().persist(baseAplicacao);
        });
    }

    @Override
    public Integer deleteFromBase(Long baseId) {

        StringBuilder jpqlBuilder = new StringBuilder();

        jpqlBuilder.append("update BaseAplicacao baseAplicacao set ");
        jpqlBuilder.append("    desativacao = :desativacao ");
        jpqlBuilder.append(" where ");
        jpqlBuilder.append("    baseAplicacao.base.id = :baseId  ");

        Query query = getEntityManager().createQuery(jpqlBuilder.toString());

        query.setParameter("baseId", baseId);
        query.setParameter("desativacao", new Date());

        return query.executeUpdate();
    }

    @Override
    public List<BaseAplicacao> findByBaseId(Long baseId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select baseAplicacao from BaseAplicacao baseAplicacao ");
        jpql.append("   inner join fetch baseAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join baseAplicacao.base as base ");
        jpql.append(" where base.id = :baseId ");
        jpql.append(" and baseAplicacao.desativacao is null ");

        TypedQuery<BaseAplicacao> query = getEntityManager().createQuery(jpql.toString(), BaseAplicacao.class);

        query.setParameter("baseId", baseId);

        return query.getResultList();
    }

    @Override
    public List<BaseAplicacao> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select baseAplicacao from BaseAplicacao baseAplicacao ");
        jpql.append("       inner join fetch baseAplicacao.aplicacao as aplicacao ");
        jpql.append("       inner join fetch aplicacao.empresa as empresa ");
        jpql.append("       inner join fetch baseAplicacao.base as base ");
        jpql.append("   where aplicacao.descricao like :descricao ");
        jpql.append("       and baseAplicacao.desativacao is null ");

        TypedQuery<BaseAplicacao> query = getEntityManager().createQuery(jpql.toString(), BaseAplicacao.class);

        query.setParameter("descricao", '%' + paggable.getTerm() + '%');

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public Optional<BaseAplicacao> findFetchAllById(Long baseAplicacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select baseaplicacao from BaseAplicacao baseaplicacao ");
        jpql.append("       inner join fetch baseaplicacao.aplicacao ");
        jpql.append("       inner join fetch baseaplicacao.base ");
        jpql.append("       where baseaplicacao.id = :baseAplicacaoId ");

        TypedQuery<BaseAplicacao> query = getEntityManager().createQuery(jpql.toString(), BaseAplicacao.class);

        query.setParameter("baseAplicacaoId", baseAplicacaoId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<BaseAplicacao> findById(Long baseAplicacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select baseaplicacao from BaseAplicacao baseaplicacao ");
        jpql.append("       where baseaplicacao.id = :baseAplicacaoId ");

        TypedQuery<BaseAplicacao> query = getEntityManager().createQuery(jpql.toString(), BaseAplicacao.class);

        query.setParameter("baseAplicacaoId", baseAplicacaoId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
