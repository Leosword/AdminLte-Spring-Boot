package br.com.netservicos.bow.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.BaseAplicacaoOperacao;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.model.Operacao;

@Repository
public class BaseAplicacaoOperacaoDAOImpl implements BaseAplicacaoOperacaoDAO {

    private static final long serialVersionUID = -8392185008904146626L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public List<BaseAplicacaoOperacao> findAll() {

        TypedQuery<BaseAplicacaoOperacao> query = getEntityManager().createNamedQuery("BaseAplicacaoOperacao.findAll", BaseAplicacaoOperacao.class);

        return query.getResultList();
    }

    @Override
    public List<BaseAplicacaoOperacao> findFecthAll() {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select aplicacaoOperacao from BaseAplicacaoOperacao aplicacaoOperacao ");
        jpql.append("   inner join fetch aplicacaoOperacao.baseAplicacao as baseAplicacao ");
        jpql.append("   inner join fetch aplicacaoOperacao.operacao as operacao ");
        jpql.append("   inner join fetch baseAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join fetch aplicacao.empresa as empresa ");
        jpql.append("   inner join fetch baseAplicacao.base as base ");
        jpql.append("   where aplicacaoOperacao.desativacao is null ");

        TypedQuery<BaseAplicacaoOperacao> query = getEntityManager().createQuery(jpql.toString(), BaseAplicacaoOperacao.class);

        return query.getResultList();
    }

    @Override
    public void salvar(List<BaseAplicacaoOperacao> aplicacaoOperacaos) {

        aplicacaoOperacaos.forEach(aplicacaoOperacao -> {

            getEntityManager().persist(aplicacaoOperacao);
        });
    }

    @Override
    public Integer deletar(Long aplicacaoOperacaoId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" update BaseAplicacaoOperacao set ");
        jpql.append("   desativacao = :desativacao ");
        jpql.append(" where id = :aplicacaoOperacaoId ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("desativacao", new Date());
        query.setParameter("aplicacaoOperacaoId", aplicacaoOperacaoId);

        return query.executeUpdate();
    }

    @Override
    public Long findTotalByAplicacao(Base base, Aplicacao aplicacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select count(*) from BaseAplicacaoOperacao aplicacaoOperacao ");
        jpql.append("   inner join aplicacaoOperacao.baseAplicacao as baseAplicacao ");
        jpql.append("   inner join baseAplicacao.aplicacao as aplicacao ");
        jpql.append("   inner join baseAplicacao.base as base ");
        jpql.append("   inner join aplicacaoOperacao.operacao as operacao ");
        jpql.append(" where aplicacaoOperacao.desativacao is null ");
        jpql.append("   and base.id = :baseId ");
        jpql.append("   and aplicacao.id = :aplicacaoId ");
        jpql.append("   and baseAplicacao.desativacao is null ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("baseId", base.getId());
        query.setParameter("aplicacaoId", aplicacao.getId());

        return DAOUtil.getSingleResult(query);
    }

    @Override
    public Optional<BaseAplicacaoOperacao> findByBaseAplicacao(BaseAplicacao baseAplicacao, Operacao operacao) {

        StringBuilder jpql = new StringBuilder();

        jpql.append(" select baseAplicacaoOperacao from BaseAplicacaoOperacao baseAplicacaoOperacao ");
        jpql.append("   inner join baseAplicacaoOperacao.baseAplicacao as baseAplicacao ");
        jpql.append("   inner join baseAplicacaoOperacao.operacao as operacao ");
        jpql.append(" where baseAplicacao.id = :baseAplicacaoId ");
        jpql.append("   and operacao.id = :operacaoId ");
        jpql.append("   and baseAplicacao.desativacao is null ");
        jpql.append("   and baseAplicacaoOperacao.desativacao is null ");

        Query query = getEntityManager().createQuery(jpql.toString());

        query.setParameter("baseAplicacaoId", baseAplicacao.getId());
        query.setParameter("operacaoId", operacao.getId());

        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}