package br.com.netservicos.bow.model;

import java.io.Serializable;
import java.util.Date;

public class Periodo implements Serializable {

    private static final long serialVersionUID = -2362666822634453648L;

    private Date inicio;

    private Date termino;

    public Periodo() {
        // Construtor padrão
    }

    public Periodo(Date inicio, Date termino) {
        this.inicio = inicio;
        this.termino = termino;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getTermino() {
        return termino;
    }

    public void setTermino(Date termino) {
        this.termino = termino;
    }

}
