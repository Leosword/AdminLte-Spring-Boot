package br.com.netservicos.bow.converter;

import java.math.BigDecimal;

public interface ConverterDecimal {

    public BigDecimal convert(BigDecimal value);
}
