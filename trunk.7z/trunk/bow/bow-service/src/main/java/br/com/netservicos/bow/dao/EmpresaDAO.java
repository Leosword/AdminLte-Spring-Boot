package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.service.PaggableSelect;

public interface EmpresaDAO extends Serializable {

    public List<Empresa> findAll();

    public Optional<Empresa> findById(Long empresaId);

    public List<Empresa> findByPaggebleSelect(PaggableSelect paggable);

    public Optional<Empresa> findByNome(String nome);

    public Optional<Empresa> findByIdentificador(IdentificadorEmpresa identificador);

}
