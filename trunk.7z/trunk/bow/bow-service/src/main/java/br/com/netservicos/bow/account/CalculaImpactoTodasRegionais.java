package br.com.netservicos.bow.account;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.model.ImapctoIndisponibilidadeParameter;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;

@Component(value = "impactoTodasRegionais")
public class CalculaImpactoTodasRegionais implements CalculaImpacto {

    private static final long serialVersionUID = 4243975996110689164L;

    private static final String IMPACTO_TODAS = "BRASIL";

    @Autowired
    @Qualifier("calculaImpactoIndisponibilidade")
    private CalculaImpactoIndisponibilidade calculaImpactoIndisponibilidade;

    @Override
    public BigDecimal calcula(ImapctoIndisponibilidadeParameter dados) {

        List<ImpactoIndicadorEvento> impactos = dados.getImpactos().stream().filter(impacto -> houveImpacto(impacto))
                .collect(Collectors.toList());

        if (Iterables.isEmpty(impactos)) {

            return BigDecimal.ZERO;
        }

        return calculaImpactoIndisponibilidade.calculaTodas(dados, impactos);
    }

    private boolean houveImpacto(ImpactoIndicadorEvento impacto) {

        return Objects.nonNull(impacto.getRegional()) && IMPACTO_TODAS.equals(impacto.getRegional().getNome());
    }

}