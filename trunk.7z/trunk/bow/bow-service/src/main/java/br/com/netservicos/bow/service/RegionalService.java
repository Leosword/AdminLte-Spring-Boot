package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.netservicos.bow.dao.AplicacaoDAO;
import br.com.netservicos.bow.dao.RegionalAplicacaoDAO;
import br.com.netservicos.bow.dao.RegionalDAO;
import br.com.netservicos.bow.dao.UsuarioDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.RegionalAplicacao;
import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.service.authetication.Principal;

@Service
public class RegionalService implements Serializable {

    private static final long serialVersionUID = 6049760982967221490L;

    private static final Logger LOGGER = LoggerFactory.getLogger(RegionalService.class);

    @Autowired
    private RegionalDAO regionalDAO;

    @Autowired
    private AplicacaoDAO aplicacaoDAO;

    @Autowired
    private RegionalAplicacaoDAO dao;

    @Autowired
    private UsuarioDAO usuarioDAO;

    public List<Regional> findAllAtivas() {

        LOGGER.debug("Pesquisando todas as regionais ativas");

        return regionalDAO.findAllAtivas();
    }

    public List<Regional> findFetchAllAtivas() {

        LOGGER.debug("Pesquisando todas as regionais ativas");

        return regionalDAO.findFetchAllAtivas();
    }

    public List<Regional> findByPaggebleSelect(PaggableSelect paggable) {

        LOGGER.debug("Pesquisando com paginação: {}", paggable);

        return regionalDAO.findByPaggebleSelect(paggable);
    }

    public Optional<Regional> findById(Long id) {

        LOGGER.debug("Pesquisando a regional com o Id: {}", id);

        return regionalDAO.findById(id);
    }

    public Optional<Regional> findByIdFetchAll(Long regionalId) {

        LOGGER.debug("Pesquisando a regional com o Id: {}", regionalId);

        return regionalDAO.findByIdFetchAll(regionalId);
    }

    @Transactional
    public void salvar(Regional regional, Long[] aplicacaoIds) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ((authentication instanceof AnonymousAuthenticationToken)) {

            throw new BusinessException("Não foi possível localizar usuário autenticado.");
        }

        Principal principal = (Principal) authentication.getPrincipal();

        Optional<Usuario> usuario = usuarioDAO.findByEmail(principal.getEmail());

        if (!usuario.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com email: {}", principal.getEmail());

            throw new BusinessException("Não foi possível localizar usuário.");
        }

        regionalDAO.salvar(regional);

        dao.deleteFromBase(regional.getId());

        List<Aplicacao> aplicacoes = aplicacaoDAO.findByIds(Arrays.asList(aplicacaoIds));

        List<RegionalAplicacao> regionaisAplicacoes = aplicacoes.stream().map(aplicacao -> new RegionalAplicacao(regional, aplicacao, usuario.get()))
                .collect(Collectors.toList());

        dao.salvar(regionaisAplicacoes);
    }

    @Transactional
    public void deletar(Long[] ids) {

        if (Objects.isNull(ids)) {

            throw new BusinessException("Não foi possível localizar as informações corretas para excluir o(s) registro(s).");
        }

        LOGGER.debug("Removendo os registros com Ids: {}", new Object[] { ids });

        for (Long id : ids) {

            regionalDAO.deletar(id);
        }
    }

    public List<Regional> findByEmpresa(Empresa empresa) {

        LOGGER.debug("Pesquisando as regionais para a empresa: {}", empresa);

        return regionalDAO.findByEmpresa(empresa);
    }

}
