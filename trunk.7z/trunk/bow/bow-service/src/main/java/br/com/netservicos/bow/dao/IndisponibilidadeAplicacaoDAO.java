package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacao;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

public interface IndisponibilidadeAplicacaoDAO extends Serializable {

    public void salvar(IndisponibilidadeAplicacao indisponibilidade);

    public Optional<IndisponibilidadeAplicacao> findByDia(Aplicacao aplicacao, Date dia, TipoIndisponibilidadeEvento tipo);

    public void atualizar(IndisponibilidadeAplicacao indisponibilidadeAplicacao);

    public List<IndisponibilidadeAplicacao> findByPeriodo(Date inicio, Date fim, List<Aplicacao> aplicacoes);

    public List<IndisponibilidadeAplicacao> findByPeriodo(Date inicio, Date fim, Empresa empresa);

    public List<IndisponibilidadeAplicacao> findByPeriodo(Integer ano, Integer mes, Aplicacao aplicacao);
}
