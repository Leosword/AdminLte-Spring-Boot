package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Iterables;

import br.com.netservicos.bow.dao.AplicacaoDAO;
import br.com.netservicos.bow.dao.BaseAplicacaoDAO;
import br.com.netservicos.bow.dao.BaseDAO;
import br.com.netservicos.bow.dao.UsuarioDAO;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.model.Usuario;

@Service
public class BaseService implements Serializable {

    private static final long serialVersionUID = -6272506551974714773L;

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseService.class);

    @Autowired
    private BaseDAO baseDAO;

    @Autowired
    private AplicacaoDAO aplicacaoDAO;

    @Autowired
    private BaseAplicacaoDAO baseAplicacaoDAO;

    @Autowired
    private CidadeService cidadeService;

    @Autowired
    private UsuarioDAO usuarioDAO;

    public List<Base> findAllAtivas() {

        LOGGER.debug("Pesquisando todas as bases ativas");

        return baseDAO.findAllAtivas();
    }

    @Transactional
    public void salvar(Base base, Long[] aplicacoesIds, String email, Long[] cidadesId) {

        Optional<Base> nomeOptional = baseDAO.findByNome(base.getNome());

        if (nomeOptional.isPresent()) {

            LOGGER.error("Base com o nome: {} já encontra cadastrada", base.getNome());

            throw new BusinessException("Não foi possível continuar com o cadastro. Nome da base já possui cadastro");
        }

        LOGGER.debug("Pesquisando o usuário com email: {}", email);

        Optional<Usuario> usuario = usuarioDAO.findByEmail(email);

        if (!usuario.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com email: {}", email);

            throw new BusinessException("Não foi possível localizar usuário.");
        }

        LOGGER.debug("Persistindo a base: {}", base);

        baseDAO.salvar(base);

        List<Long> idCidades = Arrays.asList(cidadesId);

        if (!Iterables.isEmpty(idCidades)) {

            cidadeService.salvarCidadeBase(idCidades, base);
        }

        List<BaseAplicacao> basesAplicacoes = new ArrayList<>();

        LOGGER.debug("Pesquisando as aplicações com Ids: {}", new Object[] { aplicacoesIds });

        List<Aplicacao> aplicacoes = aplicacaoDAO.findByIds(Arrays.asList(aplicacoesIds));

        aplicacoes.forEach(aplicacao -> {

            BaseAplicacao baseAplicacao = new BaseAplicacao(base, aplicacao, usuario.get());

            basesAplicacoes.add(baseAplicacao);
        });

        LOGGER.debug("Persistindo as aplicações e a base: {}", basesAplicacoes);

        baseAplicacaoDAO.salvar(basesAplicacoes);
    }

    @Transactional
    public void atualizar(Base base, Long[] aplicacoesIds, String email, Long[] cidadesId) {

        LOGGER.debug("Pesquisando usuário com o email: {}", email);

        Optional<Usuario> usuario = usuarioDAO.findByEmail(email);

        if (!usuario.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com email: {}", email);

            throw new BusinessException("Não foi possível localizaro usuário.");
        }

        LOGGER.debug("Persistindo a base: {}", base);

        baseDAO.salvar(base);

        LOGGER.debug("Removendo as bases antigas: {}", base);

        baseAplicacaoDAO.deleteFromBase(base.getId());

        List<BaseAplicacao> basesAplicacoes = new ArrayList<>();

        LOGGER.debug("Pesquisando as aplicações com Ids: {}", new Object[] { aplicacoesIds });

        List<Aplicacao> aplicacoes = aplicacaoDAO.findByIds(Arrays.asList(aplicacoesIds));

        aplicacoes.forEach(aplicacao -> {

            BaseAplicacao baseAplicacao = new BaseAplicacao(base, aplicacao, usuario.get());

            basesAplicacoes.add(baseAplicacao);
        });

        LOGGER.debug("Persistindo as aplicações e a base: {}", basesAplicacoes);

        baseAplicacaoDAO.salvar(basesAplicacoes);
    }

    public Optional<Base> findById(Long id) {

        LOGGER.debug("Pesquisando a base com o Id: {}", id);

        return baseDAO.findById(id);
    }

    public Optional<Base> findByFetchAll(Long id) {

        LOGGER.debug("Pesquisando a base com o Id: {}", id);

        return baseDAO.findByFetchAll(id);
    }

    @Transactional
    public void deletar(Long[] ids) {

        if (Objects.isNull(ids)) {

            LOGGER.error("Não foi possível remover as bases com os Ids: {}", new Object[] { ids });

            throw new BusinessException("Não foi possível localizar as informações corretas para excluir o(s) registro(s).");
        }

        for (Long id : ids) {

            LOGGER.debug("Desativando a base com Id: {}", id);

            baseDAO.deletar(id);
        }
    }

    public List<Base> findByPaggebleSelect(PaggableSelect paggable) {

        return baseDAO.findByPaggebleSelect(paggable);
    }

}
