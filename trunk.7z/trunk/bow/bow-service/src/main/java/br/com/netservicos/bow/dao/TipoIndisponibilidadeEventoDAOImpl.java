package br.com.netservicos.bow.dao;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;

@Repository
public class TipoIndisponibilidadeEventoDAOImpl implements TipoIndisponibilidadeEventoDAO {

    private static final long serialVersionUID = 4492509344520311663L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    @Override
    public Optional<TipoIndisponibilidadeEvento> findByNome(String nome) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select tipo from TipoIndisponibilidadeEvento tipo ");
        jpql.append("       where tipo.descricao = :nome ");

        TypedQuery<TipoIndisponibilidadeEvento> query = getEntityManager().createQuery(jpql.toString(), TipoIndisponibilidadeEvento.class);

        query.setParameter("nome", nome);

        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
