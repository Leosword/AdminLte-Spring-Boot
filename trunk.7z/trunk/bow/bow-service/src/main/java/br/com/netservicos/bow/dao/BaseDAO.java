package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.service.PaggableSelect;

public interface BaseDAO extends Serializable {

    public List<Base> findAllAtivas();
    
    public List<Base> findAll();

    public void salvar(Base base);

    public Optional<Base> findById(Long id);
    
    public Optional<Base> findByFetchAll(Long id);
    
    public Optional<Base> findByFetchCidade(Long id);

    public Integer deletar(Long id);

    public Optional<Base> findByNome(String nome);

    public List<Base> findByPaggebleSelect(PaggableSelect paggable);

    public List<Base> findByIds(List<Long> asList);

}
