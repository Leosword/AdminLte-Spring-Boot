package br.com.netservicos.bow.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.service.PaggableSelect;

@Repository
public class EmpresaDAOImpl implements EmpresaDAO {

    private static final long serialVersionUID = -5882110561765536380L;

    @PersistenceContext(name = "bowDS", unitName = "bowDS")
    private EntityManager entityManager;

    public List<Empresa> findAll() {

        TypedQuery<Empresa> query = getEntityManager().createNamedQuery("Empresa.findAllAtivas", Empresa.class);

        return query.getResultList();
    }

    @Override
    public List<Empresa> findByPaggebleSelect(PaggableSelect paggable) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select empresa from Empresa empresa ");
        jpql.append("       where empresa.descricao like :descricao ");

        TypedQuery<Empresa> query = getEntityManager().createQuery(jpql.toString(), Empresa.class);

        query.setParameter("descricao", '%' + paggable.getTerm() + '%');

        query.setMaxResults(paggable.getPage());

        return query.getResultList();
    }

    @Override
    public Optional<Empresa> findById(Long empresaId) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select empresa from Empresa empresa ");
        jpql.append("       where empresa.id = :empresaId ");

        TypedQuery<Empresa> query = getEntityManager().createQuery(jpql.toString(), Empresa.class);

        query.setParameter("empresaId", empresaId);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Empresa> findByNome(String nome) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select empresa from Empresa empresa ");
        jpql.append("       where empresa.descricao = :nome ");

        TypedQuery<Empresa> query = getEntityManager().createQuery(jpql.toString(), Empresa.class);

        query.setParameter("nome", nome);
        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    @Override
    public Optional<Empresa> findByIdentificador(IdentificadorEmpresa identificador) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("   select empresa from Empresa empresa ");
        jpql.append("       where empresa.identificador = :identificador ");

        TypedQuery<Empresa> query = getEntityManager().createQuery(jpql.toString(), Empresa.class);

        query.setParameter("identificador", identificador);
        query.setMaxResults(NumberUtil.INTEGER_ONE);

        return Optional.ofNullable(DAOUtil.getSingleResult(query));
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

}
