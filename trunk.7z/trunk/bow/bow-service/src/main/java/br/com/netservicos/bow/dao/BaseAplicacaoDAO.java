package br.com.netservicos.bow.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.service.PaggableSelect;

public interface BaseAplicacaoDAO extends Serializable {

    public void salvar(List<BaseAplicacao> basesAplicacoes);

    public List<BaseAplicacao> findByBaseId(Long baseId);

    public Integer deleteFromBase(Long baseId);

    public List<BaseAplicacao> findByPaggebleSelect(PaggableSelect paggable);

    public Optional<BaseAplicacao> findFetchAllById(Long baseAplicacaoId);

    public Optional<BaseAplicacao> findById(Long baseAplicacaoId);

}
