package br.com.netservicos.bow.service;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.google.common.base.MoreObjects;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;

import br.com.netservicos.bow.common.util.NumberUtil;

public class PaggableSelect implements Serializable {

    private static final long serialVersionUID = -7675159537418797483L;

    private String id;

    private String term;

    private Integer page;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public List<Long> getConvertValues() {

        List<String> splitToList = Splitter.on(",").omitEmptyStrings().splitToList(getId());
        
        if (Iterables.isEmpty(splitToList)) {
            
            return Arrays.asList(NumberUtil.LONG_ZERO);
        }

        return splitToList.stream().map(Long::valueOf).collect(Collectors.toList());
    }

    @Override
    public String toString() {

        return MoreObjects.toStringHelper(this.getClass()).add("Termo: ", term).add("Página: ", page).toString();
    }

}
