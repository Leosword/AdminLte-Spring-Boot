package br.com.netservicos.bow.service.authetication;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.service.UsuarioService;

@Service(value = "userDetailsService")
public class UserDetailService implements UserDetailsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserDetailService.class);

    @Autowired
    private UsuarioService usuarioService;

    @Override
    public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException, DataAccessException {

        if (StringUtils.isEmpty(login)) {

            throw new UsernameNotFoundException("Não foi possível localizar o Usuário");
        }

        Optional<Usuario> optional = usuarioService.findByLogin(login);

        if (!optional.isPresent()) {

            LOGGER.error("Não foi possível localizar o login: {}", login);

            throw new UsernameNotFoundException("Não foi possível localizar o Usuário.");
        }

        Usuario usuario = optional.get();

        List<GrantedAuthority> authorities = usuarioService.carregarPerfil(usuario.getPerfil());

        Principal principal = new Principal(usuario.getId(), usuario.getNome(), usuario.getSobrenome(), usuario.getLogin(), usuario.getEmail(),
                usuario.getTelefone(), usuario.getPerfil().getNome(), usuario.getSenha(), usuario.getSituacao(), authorities);

        return principal;
    }

}
