-- insert into tb_perfil(id_perfil, nome) values (nextval('seq_id_perfil'), 'ADMIN');

-- insert into tb_perfil(id_perfil, nome) values (nextval('seq_id_perfil'), 'USER');

-- insert into tb_perfil(id_perfil, nome) values (nextval('seq_id_perfil'), 'MASTER');

-- insert into tb_usuario(id_usuario, nome, sobrenome, login, email, senha, situacao, situacaosenha, id_perfil, criacao) values (nextval('seq_id_usuario'), 'Eric', 'Jorge', 'teste', 'eric_jorge10@hotmail.com', '$2a$10$rTL8E6KcH7DOccFunCH6o.2TGoDj/bFlhneS9PvfX0.RyqJ9lrFE2', true, 1, 1, now());

-- insert into tb_usuario(id_usuario, nome, sobrenome, login, email, senha, situacao, situacaosenha, id_perfil, criacao) values (nextval('seq_id_usuario'), 'Eric', 'Santos', 'teste2', 'ejbmss@gmail.com', '$2a$10$rTL8E6KcH7DOccFunCH6o.2TGoDj/bFlhneS9PvfX0.RyqJ9lrFE2', true, 1, 2, now());



