package br.com.netservicos.bow.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Lob;

import com.google.common.base.MoreObjects;

@Embeddable
public class FCAEvento implements Serializable {

    private static final long serialVersionUID = 6696152765841894584L;

    @Lob
    @Column(name = "ds_fato_book", columnDefinition = "TEXT")
    private String fato;

    @Lob
    @Column(name = "ds_causa_book", columnDefinition = "TEXT")
    private String causa;

    @Lob
    @Column(name = "ds_acao_book", columnDefinition = "TEXT")
    private String acao;

    public String getFato() {
        return fato;
    }

    public void setFato(String fato) {
        this.fato = fato;
    }

    public String getCausa() {
        return causa;
    }

    public void setCausa(String causa) {
        this.causa = causa;
    }

    public String getAcao() {
        return acao;
    }

    public void setAcao(String acao) {
        this.acao = acao;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Fato: ", fato).add("Causa: ", causa).add("Ação: ", acao).toString();
    }

}
