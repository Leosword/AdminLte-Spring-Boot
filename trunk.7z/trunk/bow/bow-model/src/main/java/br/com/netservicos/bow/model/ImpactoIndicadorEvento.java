package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_classifica_eventos_impacto_indicadores", catalog = "coti_prd", schema = "coti_prd")
public class ImpactoIndicadorEvento implements BaseModel<Long> {

    private static final long serialVersionUID = -2243586734719879446L;

    @Id
    @Column(name = "id_classifica_eventos_impacto_indicadores", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_base", foreignKey = @ForeignKey(name = "fk_impactoindicador_base"))
    private Base base;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_evento", referencedColumnName = "id_evento", foreignKey = @ForeignKey(name = "fk_impactoindicador_evento"))
    private EventoClassificado evento;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cidade", foreignKey = @ForeignKey(name = "fk_impactoindicador_cidade"))
    private Cidade cidade;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_regional", foreignKey = @ForeignKey(name = "fk_impactoindicador_regional"))
    private Regional regional;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_operacao", foreignKey = @ForeignKey(name = "fk_impactoindicador_localidade"))
    private Operacao operacao;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "impactoIndicadorEvento")
    private Set<ImpactoIndicadorEventoBook> impactosBook;

    @Column(name = "dt_inicio_real")
    @Temporal(TemporalType.TIMESTAMP)
    private Date inicio;

    @Column(name = "dt_termino_real")
    @Temporal(TemporalType.TIMESTAMP)
    private Date termino;

    @Column(name = "ds_duracao_real_evento", length = 11)
    private Integer duracao;

    @Column(name = "dt_cadastro")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    public ImpactoIndicadorEvento() {
        // Construtor padrão
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Base getBase() {
        return base;
    }

    public void setBase(Base base) {
        this.base = base;
    }

    public EventoClassificado getEvento() {
        return evento;
    }

    public void setEvento(EventoClassificado evento) {
        this.evento = evento;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public Regional getRegional() {
        return regional;
    }

    public void setRegional(Regional regional) {
        this.regional = regional;
    }

    public Operacao getOperacao() {
        return operacao;
    }

    public void setOperacao(Operacao operacao) {
        this.operacao = operacao;
    }

    public Set<ImpactoIndicadorEventoBook> getImpactosBook() {
        return impactosBook;
    }

    public void setImpactosBook(Set<ImpactoIndicadorEventoBook> impactosBook) {
        this.impactosBook = impactosBook;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getTermino() {
        return termino;
    }

    public void setTermino(Date termino) {
        this.termino = termino;
    }

    public Integer getDuracao() {
        return duracao;
    }

    public void setDuracao(Integer duracao) {
        this.duracao = duracao;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        ImpactoIndicadorEvento other = (ImpactoIndicadorEvento) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Evento: ", evento).toString();
    }

}
