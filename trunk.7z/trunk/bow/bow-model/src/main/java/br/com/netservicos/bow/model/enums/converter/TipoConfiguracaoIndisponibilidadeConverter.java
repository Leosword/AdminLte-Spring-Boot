package br.com.netservicos.bow.model.enums.converter;

import javax.persistence.AttributeConverter;

import br.com.netservicos.bow.model.enums.TipoConfiguracaoIndisponibilidade;

public class TipoConfiguracaoIndisponibilidadeConverter implements AttributeConverter<TipoConfiguracaoIndisponibilidade, Integer> {

    @Override
    public Integer convertToDatabaseColumn(TipoConfiguracaoIndisponibilidade identificador) {
        return identificador.getValue();
    }

    @Override
    public TipoConfiguracaoIndisponibilidade convertToEntityAttribute(Integer identificador) {
        return TipoConfiguracaoIndisponibilidade.getTipoConfiguracaoIndisponibilidade(identificador);
    }

}