package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_localidade_base", catalog = "book", schema = "book", uniqueConstraints = @UniqueConstraint(name = "un_localidade_base", columnNames = {
        "id_localidade", "id_base" }))
public class OperacaoBase extends BaseEntity<Long> {

    private static final long serialVersionUID = -2280146005683258538L;

    @Id
    @Column(name = "id_operacao_apliccao", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_localidade", foreignKey = @ForeignKey(name = "fk_localidade_base"), nullable = false)
    private Operacao operacao;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_base", foreignKey = @ForeignKey(name = "fk_base_localidade"), nullable = false)
    private Base base;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", foreignKey = @ForeignKey(name = "fk_usuario_localidade_base"), nullable = false)
    private Usuario usuario;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    @Column(name = "dt_desativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date desativacao;

    public OperacaoBase() {
        // Construtor padrão
    }

    public OperacaoBase(Operacao operacao, Base base, Usuario usuario) {
        this.operacao = operacao;
        this.base = base;
        this.usuario = usuario;
        this.criacao = new Date();
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Operacao getOperacao() {
        return operacao;
    }

    public void setOperacao(Operacao operacao) {
        this.operacao = operacao;
    }

    public Base getBase() {
        return base;
    }

    public void setBase(Base base) {
        this.base = base;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public Date getDesativacao() {
        return desativacao;
    }

    public void setDesativacao(Date desativacao) {
        this.desativacao = desativacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        OperacaoBase other = (OperacaoBase) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Operação: ", operacao).add("Base: ", base).toString();
    }

}
