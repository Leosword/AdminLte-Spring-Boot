package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.hibernate.validator.constraints.NotBlank;

import com.google.common.base.MoreObjects;

import br.com.netservicos.bow.model.enums.SituacaoSenha;
import br.com.netservicos.bow.model.enums.converter.SituacaoSenhaConverter;

@Entity
@Table(name = "tb_usuario", catalog = "book", schema = "book", uniqueConstraints = {
        @UniqueConstraint(name = "un_usuario_email", columnNames = { "email" }),
        @UniqueConstraint(name = "un_usuario_login", columnNames = { "login" }) })
@NamedQuery(name = "Usuario.findAll", query = "select usuario from Usuario usuario")
public class Usuario extends BaseEntity<Long> {

    private static final long serialVersionUID = -2808579149301096928L;

    @Id
    @Column(name = "id_usuario", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "nome")
    private String nome;

    @NotBlank
    @Column(name = "sobrenome")
    private String sobrenome;

    @NotBlank
    @Column(name = "login")
    private String login;

    @NotBlank
    @Column(name = "telefone")
    private String telefone;

    @NotBlank
    @Column(name = "email")
    private String email;

    @NotBlank
    @Column(name = "senha")
    private String senha;

    @NotBlank
    @Column(name = "confirmasenha")
    private String confirmarSenha;

    @Convert(converter = SituacaoSenhaConverter.class)
    @Column(name = "situacaosenha")
    private SituacaoSenha situacaoSenha;

    @Column(name = "situacao")
    private Boolean situacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_perfil", foreignKey = @ForeignKey(name = "fk_perfil_usuario") , nullable = false)
    private Perfil perfil;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    @Transient
    private String nomePerfil;

    public Usuario() {
        this.criacao = new Date();
        this.situacaoSenha = SituacaoSenha.ATIVO;
        this.situacao = true;
    }

    public Usuario(Long id, String nome, String sobrenome, String login, String telefone, String email, String nomePerfil) {
        this.id = id;
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.login = login;
        this.telefone = telefone;
        this.email = email;
        this.nomePerfil = nomePerfil;
    }

    public Usuario(String nome) {
        this.nome = nome;
    }

    public Usuario(String nome, String sobrenome, String login, String telefone, String email, String senha, String confirmarSenha) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.login = login;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
        this.confirmarSenha = confirmarSenha;
        this.criacao = new Date();
        this.situacaoSenha = SituacaoSenha.ATIVO;
        this.situacao = true;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public SituacaoSenha getSituacaoSenha() {
        return situacaoSenha;
    }

    public void setSituacaoSenha(SituacaoSenha situacaoSenha) {
        this.situacaoSenha = situacaoSenha;
    }

    public Boolean getSituacao() {
        return situacao;
    }

    public void setSituacao(Boolean situacao) {
        this.situacao = situacao;
    }

    public Perfil getPerfil() {
        return perfil;
    }

    public void setPerfil(Perfil perfil) {
        this.perfil = perfil;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public String getNomePerfil() {
        return nomePerfil;
    }

    public void setNomePerfil(String nomePerfil) {
        this.nomePerfil = nomePerfil;
    }

    public String getConfirmarSenha() {
        return confirmarSenha;
    }

    public void setConfirmarSenha(String confirmarSenha) {
        this.confirmarSenha = confirmarSenha;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Usuario other = (Usuario) obj;

        return Objects.equals(this.id, other.id) && Objects.equals(this.email, other.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.email);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Nome: ", nome).add("Email: ", email).toString();
    }

}
