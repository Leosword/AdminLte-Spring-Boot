package br.com.netservicos.bow.model;

import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_servico", catalog = "book", schema = "book", uniqueConstraints = {
        @UniqueConstraint(name = "un_nm_servico", columnNames = { "nm_servico" }) })
@NamedQuery(name = "Servico.findAllAtivas", query = "select servico from Servico servico where servico.status = true")
public class Servico extends BaseEntity<Long> {

    private static final long serialVersionUID = 8673292650885540061L;

    @Id
    @Column(name = "id_servico", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "servico")
    @JsonIgnore
    private Set<ServicoAplicacao> servicosAplicacoes;

    @Column(name = "nm_servico")
    @NotBlank
    private String nome;

    @Column(name = "ds_servico")
    @NotBlank
    private String descricao;

    @Column(name = "fl_ativo")
    private Boolean status;

    public Servico() {
        // Construtor padrão
    }

    public Servico(String nome, String descricao) {
        this.nome = nome;
        this.descricao = descricao;
        this.status = true;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Set<ServicoAplicacao> getServicosAplicacoes() {
        return servicosAplicacoes;
    }

    public void setServicosAplicacoes(Set<ServicoAplicacao> servicosAplicacoes) {
        this.servicosAplicacoes = servicosAplicacoes;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Servico other = (Servico) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Nome: ", nome).add("Status: ", status).toString();
    }

}
