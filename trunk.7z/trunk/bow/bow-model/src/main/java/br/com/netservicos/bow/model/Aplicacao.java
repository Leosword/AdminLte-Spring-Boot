package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_aplicacoes", catalog = "coti_prd", schema = "coti_prd")
@NamedQuery(name = "Aplicacao.findAllAtivas", query = "select aplicacao from Aplicacao aplicacao where aplicacao.removido = false")
public class Aplicacao implements BaseModel<Long> {

    private static final long serialVersionUID = 2423253649076334769L;

    @Id
    @Column(name = "id_aplicacao", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ds_aplicacao")
    private String descricao;

    @Lob
    @Column(name = "ds_complemento")
    private String complemento;

    @Lob
    @Column(name = "ds_impacto")
    private String impacto;

    @Column(name = "dt_cadastro")
    @Temporal(TemporalType.TIMESTAMP)
    private Date cadastro;

    @Column(name = "fl_removido")
    private Boolean removido;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_empresa", foreignKey = @ForeignKey(name = "fk_empresa_aplicacao"), nullable = false)
    @JsonIgnore
    private Empresa empresa;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_tipo_aplicacao", foreignKey = @ForeignKey(name = "fk_tipo_aplicaao_aplicacao"), nullable = false)
    @JsonIgnore
    private TipoAplicacao tipo;

    public Aplicacao() {
        // Construtor padrão
    }

    public Aplicacao(TipoAplicacao tipo) {
        this.tipo = tipo;
    }

    public Aplicacao(Long id, String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    public Aplicacao(Long id, String descricao, Empresa empresa) {
        this.id = id;
        this.descricao = descricao;
        this.empresa = empresa;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getImpacto() {
        return impacto;
    }

    public void setImpacto(String impacto) {
        this.impacto = impacto;
    }

    public Date getCadastro() {
        return cadastro;
    }

    public void setCadastro(Date cadastro) {
        this.cadastro = cadastro;
    }

    public Boolean getRemovido() {
        return removido;
    }

    public void setRemovido(Boolean removido) {
        this.removido = removido;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public TipoAplicacao getTipo() {
        return tipo;
    }

    public void setTipo(TipoAplicacao tipo) {
        this.tipo = tipo;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Aplicacao other = (Aplicacao) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Descrição: ", descricao).add("Empresa: ", empresa).toString();
    }
}
