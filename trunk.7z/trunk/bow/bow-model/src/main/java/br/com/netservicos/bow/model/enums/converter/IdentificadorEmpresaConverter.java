package br.com.netservicos.bow.model.enums.converter;

import javax.persistence.AttributeConverter;

import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;

public class IdentificadorEmpresaConverter implements AttributeConverter<IdentificadorEmpresa, Integer> {

    @Override
    public Integer convertToDatabaseColumn(IdentificadorEmpresa identificador) {
        return identificador.getValue();
    }

    @Override
    public IdentificadorEmpresa convertToEntityAttribute(Integer identificador) {
        return IdentificadorEmpresa.getIdentificadorEmpresa(identificador);
    }

}