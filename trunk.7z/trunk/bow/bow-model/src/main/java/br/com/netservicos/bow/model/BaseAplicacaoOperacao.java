package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_base_aplicacao_operacao", catalog = "book", schema = "book")
@NamedQuery(name = "BaseAplicacaoOperacao.findAll", query = " from BaseAplicacaoOperacao baseAplicacaoOperacao ")
public class BaseAplicacaoOperacao extends BaseEntity<Long> {

    private static final long serialVersionUID = -6903386956078561962L;

    @Id
    @Column(name = "id_base_aplicacao_operacao", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_base_aplicacao", foreignKey = @ForeignKey(name = "fk_baseaplicacaooperacao_baseaplicacao"))
    private BaseAplicacao baseAplicacao;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_operacao", foreignKey = @ForeignKey(name = "fk_baseaplicacaooperacao_operacao"))
    private Operacao operacao;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", foreignKey = @ForeignKey(name = "fk_baseaplicacaooperacao_usuario"))
    private Usuario usuario;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    @Column(name = "dt_desativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date desativacao;

    public BaseAplicacaoOperacao() {
        // Construtor padrão
    }

    public BaseAplicacaoOperacao(BaseAplicacao baseAplicacao, Operacao operacao, Usuario usuario) {
        this.baseAplicacao = baseAplicacao;
        this.operacao = operacao;
        this.usuario = usuario;
        this.criacao = new Date();
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public BaseAplicacao getBaseAplicacao() {
        return baseAplicacao;
    }

    public void setBaseAplicacao(BaseAplicacao baseAplicacao) {
        this.baseAplicacao = baseAplicacao;
    }

    public Operacao getOperacao() {
        return operacao;
    }

    public void setOperacao(Operacao operacao) {
        this.operacao = operacao;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public Date getDesativacao() {
        return desativacao;
    }

    public void setDesativacao(Date desativacao) {
        this.desativacao = desativacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        BaseAplicacaoOperacao other = (BaseAplicacaoOperacao) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Base Aplicação: ", baseAplicacao).add("Operação: ", operacao)
                .toString();
    }
}
