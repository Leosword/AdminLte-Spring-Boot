package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_servico_aplicacao", catalog = "book", schema = "book", uniqueConstraints = @UniqueConstraint(name = "un_servico_aplicacao", columnNames = {
        "id_servico", "id_aplicacao" }) )
public class ServicoAplicacao extends BaseEntity<Long> {

    private static final long serialVersionUID = 5724582852434662557L;

    @Id
    @Column(name = "id_servico_apliccao", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_servico", foreignKey = @ForeignKey(name = "fk_servico_aplicacao") , nullable = false)
    private Servico servico;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_aplicacao", foreignKey = @ForeignKey(name = "fk_aplicacao_servico") , nullable = false)
    private Aplicacao aplicacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", foreignKey = @ForeignKey(name = "fk_usuario_servico_aplicacao") , nullable = false)
    private Usuario usuario;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    @Column(name = "dt_desativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date desativacao;

    public ServicoAplicacao() {
        // Construtor padrão
    }

    public ServicoAplicacao(Servico servico, Aplicacao aplicacao, Usuario usuario) {
        this.servico = servico;
        this.aplicacao = aplicacao;
        this.usuario = usuario;
        this.criacao = new Date();
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Servico getServico() {
        return servico;
    }

    public void setServico(Servico servico) {
        this.servico = servico;
    }

    public Aplicacao getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(Aplicacao aplicacao) {
        this.aplicacao = aplicacao;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public Date getDesativacao() {
        return desativacao;
    }

    public void setDesativacao(Date desativacao) {
        this.desativacao = desativacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        ServicoAplicacao other = (ServicoAplicacao) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Serviço: ", servico).add("Aplicação: ", aplicacao).toString();
    }

}
