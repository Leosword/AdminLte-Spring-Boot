package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_aplicacao_cidade", catalog = "book", schema = "book")
@NamedQuery(name = "AplicacaoCidade.findAll", query = "select aplicacaoCidade from AplicacaoCidade aplicacaoCidade ")
public class AplicacaoCidade extends BaseEntity<Long> {

    private static final long serialVersionUID = -6903386956078561962L;

    @Id
    @Column(name = "id_aplicacao_cidade", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_base_aplicacao", foreignKey = @ForeignKey(name = "fk_aplicacaocidade_baseaplicacao"))
    private BaseAplicacao baseAplicacao;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cidade", foreignKey = @ForeignKey(name = "fk_aplicacaocidade_cidade"))
    private Cidade cidade;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", foreignKey = @ForeignKey(name = "fk_aplicacaocidade_usuario"))
    private Usuario usuario;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    @Column(name = "dt_desativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date desativacao;

    public AplicacaoCidade() {
        // Construtor padrão
    }

    public AplicacaoCidade(BaseAplicacao baseAplicacao, Cidade cidade, Usuario usuario) {
        this.baseAplicacao = baseAplicacao;
        this.cidade = cidade;
        this.usuario = usuario;
        this.criacao = new Date();
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public BaseAplicacao getBaseAplicacao() {
        return baseAplicacao;
    }

    public void setBaseAplicacao(BaseAplicacao baseAplicacao) {
        this.baseAplicacao = baseAplicacao;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public Date getDesativacao() {
        return desativacao;
    }

    public void setDesativacao(Date desativacao) {
        this.desativacao = desativacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        AplicacaoCidade other = (AplicacaoCidade) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Base Aplicação: ", baseAplicacao).add("Cidade: ", cidade).toString();
    }
}
