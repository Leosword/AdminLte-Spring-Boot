/**
 * 
 */
/**
 * @author eric.santos
 *
 */
package br.com.netservicos.bow.model;