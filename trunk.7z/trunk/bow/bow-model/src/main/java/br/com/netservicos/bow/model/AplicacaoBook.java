package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

import br.com.netservicos.bow.model.enums.TipoNivelServico;
import br.com.netservicos.bow.model.enums.converter.TipoNivelServicoConverter;

@Entity
@Table(name = "tb_aplicacao_book", catalog = "book", schema = "book")
@NamedQuery(name = "AplicacaoBook.findAll", query = "select aplicacao from AplicacaoBook aplicacao")
public class AplicacaoBook extends BaseEntity<Long> {

    private static final long serialVersionUID = 3157170121156284417L;

    @Id
    @Column(name = "id_aplicacao_book", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_aplicacao", foreignKey = @ForeignKey(name = "fk_aplicacao_aplicacaobook"), nullable = false)
    private Aplicacao aplicacao;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", foreignKey = @ForeignKey(name = "fk_usuario_aplicacaobook"), nullable = false)
    private Usuario usuario;

    @Convert(converter = TipoNivelServicoConverter.class)
    @Column(name = "vl_tipo_servico", nullable = false)
    private TipoNivelServico tipo;

    @Column(name = "fl_sla_geral")
    private Boolean slaGeral;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    @Column(name = "dt_desativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date desativacao;

    public AplicacaoBook() {
        // Construtor padrão
    }

    public AplicacaoBook(Aplicacao aplicacao, Usuario usuario, TipoNivelServico tipo, Boolean slaGeral) {
        this.aplicacao = aplicacao;
        this.usuario = usuario;
        this.tipo = tipo;
        this.slaGeral = slaGeral;
        this.criacao = new Date();
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Aplicacao getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(Aplicacao aplicacao) {
        this.aplicacao = aplicacao;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public TipoNivelServico getTipo() {
        return tipo;
    }

    public void setTipo(TipoNivelServico tipo) {
        this.tipo = tipo;
    }

    public Boolean getSlaGeral() {
        return slaGeral;
    }

    public void setSlaGeral(Boolean slaGeral) {
        this.slaGeral = slaGeral;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public Date getDesativacao() {
        return desativacao;
    }

    public void setDesativacao(Date desativacao) {
        this.desativacao = desativacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        AplicacaoBook other = (AplicacaoBook) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {

        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Aplicação: ", aplicacao).add("Tipo: ", tipo).toString();
    }

}
