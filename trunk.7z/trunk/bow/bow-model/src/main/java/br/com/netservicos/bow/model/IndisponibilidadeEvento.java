package br.com.netservicos.bow.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_indisponibilidade_evento", catalog = "book", schema = "book")
@NamedQuery(name = "IndisponibilidadeEvento.findAll", query = "select indisponibilidade from IndisponibilidadeEvento indisponibilidade where indisponibilidade.desativacao is null")
public class IndisponibilidadeEvento extends BaseEntity<Long> {

    private static final long serialVersionUID = -8446683881301221537L;

    @Id
    @Column(name = "id_indisponibilidade_evento", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_aplicacao", foreignKey = @ForeignKey(name = "fk_indisponibilidadeevento_aplicacao"))
    private Aplicacao aplicacao;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_base", foreignKey = @ForeignKey(name = "fk_indisponibilidadeevento_base"))
    private Base base;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_regional", foreignKey = @ForeignKey(name = "fk_indisponibilidadeevento_regional"))
    private Regional regional;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_evento", referencedColumnName = "id_evento", foreignKey = @ForeignKey(name = "fk_indisponibilidadeevento_evento"))
    private EventoClassificado evento;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_tipo_indisponibilidade", foreignKey = @ForeignKey(name = "fk_indisponibilidadeevento_tipoindisponibilidade"))
    private TipoIndisponibilidadeEvento tipoIndisponbilidade;

    @Column(name = "vl_percentual_minutos_aplicacao")
    private BigDecimal percentualMinutosAplicacao;

    @Column(name = "vl_minutos_aplicacao")
    private Integer minutosAplicacao;

    @Column(name = "vl_percentual_base", precision = 6, scale = 2)
    private BigDecimal percentualBase;

    @Column(name = "dt_indisponibilidade")
    @Temporal(TemporalType.DATE)
    private Date inicio;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    @Column(name = "dt_desativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date desativacao;

    public IndisponibilidadeEvento() {
        // Construtor padrão
    }

    public IndisponibilidadeEvento(Aplicacao aplicacao, Base base, EventoClassificado evento, TipoIndisponibilidadeEvento tipoIndisponbilidade,
            Integer minutosAplicacao, BigDecimal percentualMinutosAplicacao, BigDecimal percentualBase, Date inicio) {
        this.aplicacao = aplicacao;
        this.base = base;
        this.evento = evento;
        this.tipoIndisponbilidade = tipoIndisponbilidade;
        this.minutosAplicacao = minutosAplicacao;
        this.percentualMinutosAplicacao = percentualMinutosAplicacao;
        this.percentualBase = percentualBase;
        this.inicio = inicio;
        this.criacao = new Date();
    }

    public IndisponibilidadeEvento(Aplicacao aplicacao, Regional regional, EventoClassificado evento,
            TipoIndisponibilidadeEvento tipoIndisponbilidade, Integer minutosAplicacao, BigDecimal percentualMinutosAplicacao,
            BigDecimal percentualBase, Date inicio) {
        this.aplicacao = aplicacao;
        this.regional = regional;
        this.evento = evento;
        this.tipoIndisponbilidade = tipoIndisponbilidade;
        this.minutosAplicacao = minutosAplicacao;
        this.percentualMinutosAplicacao = percentualMinutosAplicacao;
        this.percentualBase = percentualBase;
        this.inicio = inicio;
        this.criacao = new Date();
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Aplicacao getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(Aplicacao aplicacao) {
        this.aplicacao = aplicacao;
    }

    public Base getBase() {
        return base;
    }

    public void setBase(Base base) {
        this.base = base;
    }

    public Regional getRegional() {
        return regional;
    }

    public void setRegional(Regional regional) {
        this.regional = regional;
    }

    public EventoClassificado getEvento() {
        return evento;
    }

    public void setEvento(EventoClassificado evento) {
        this.evento = evento;
    }

    public BigDecimal getPercentualMinutosAplicacao() {
        return percentualMinutosAplicacao;
    }

    public void setPercentualMinutosAplicacao(BigDecimal percentualMinutosAplicacao) {
        this.percentualMinutosAplicacao = percentualMinutosAplicacao;
    }

    public Integer getMinutosAplicacao() {
        return minutosAplicacao;
    }

    public void setMinutosAplicacao(Integer minutosAplicacao) {
        this.minutosAplicacao = minutosAplicacao;
    }

    public BigDecimal getPercentualBase() {
        return percentualBase;
    }

    public void setPercentualBase(BigDecimal percentualBase) {
        this.percentualBase = percentualBase;
    }

    public TipoIndisponibilidadeEvento getTipoIndisponbilidade() {
        return tipoIndisponbilidade;
    }

    public void setTipoIndisponbilidade(TipoIndisponibilidadeEvento tipoIndisponbilidade) {
        this.tipoIndisponbilidade = tipoIndisponbilidade;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public Date getDesativacao() {
        return desativacao;
    }

    public void setDesativacao(Date desativacao) {
        this.desativacao = desativacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        IndisponibilidadeEvento other = (IndisponibilidadeEvento) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {

        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Aplicação: ", aplicacao).add("Base: ", base)
                .add("Regional: ", regional).add("Percentual Aplicação: ", percentualMinutosAplicacao).add("Percentual Base: ", percentualBase)
                .toString();
    }

}
