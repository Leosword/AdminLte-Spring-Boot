package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_classifica_eventos_impacto_indicadores_fatiado", catalog = "coti_prd", schema = "coti_prd")
public class ImpactoIndicadorEventoBook implements BaseModel<Long> {

    private static final long serialVersionUID = -5461260172100230199L;

    @Id
    @Column(name = "id", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_classifica_eventos_impacto_indicadores", nullable = false, foreignKey = @ForeignKey(name = "fk_impactoindicadorbook_impactoindicador"))
    private ImpactoIndicadorEvento impactoIndicadorEvento;

    @Column(name = "dt_inicio_real")
    @Temporal(TemporalType.TIMESTAMP)
    private Date inicio;

    @Column(name = "dt_termino_real")
    @Temporal(TemporalType.TIMESTAMP)
    private Date termino;

    @Column(name = "ds_duracao_real_evento", length = 11)
    private Integer duracao;

    @Column(name = "dt_cadastro")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;
    
    public ImpactoIndicadorEventoBook() {
        // Construtor padrão
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getTermino() {
        return termino;
    }

    public void setTermino(Date termino) {
        this.termino = termino;
    }

    public Integer getDuracao() {
        return duracao;
    }

    public void setDuracao(Integer duracao) {
        this.duracao = duracao;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        ImpactoIndicadorEventoBook other = (ImpactoIndicadorEventoBook) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Impacto indicador: ", impactoIndicadorEvento).add("Início: ", inicio)
                .add("Termino: ", termino).toString();
    }

}
