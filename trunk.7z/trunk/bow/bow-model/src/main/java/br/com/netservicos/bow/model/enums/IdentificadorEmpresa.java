package br.com.netservicos.bow.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum IdentificadorEmpresa {

    NET(1, "bow_empresa_net"), CLARO_MOVEL(2, "bow_empresa_claro"), EMBRATEL(3, "bow_empresa_embratel"), CLARO_HDTV(4, "bow_empresa_clarohdtv");

    protected static final Map<Integer, IdentificadorEmpresa> values = new HashMap<>();

    private Integer value;

    private String description;

    static {

        for (IdentificadorEmpresa identificador : values()) {
            values.put(identificador.value, identificador);
        }
    }

    private IdentificadorEmpresa(Integer value, String description) {
        this.value = value;
        this.description = description;
    }

    public static final IdentificadorEmpresa getIdentificadorEmpresa(final Integer value) {
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
