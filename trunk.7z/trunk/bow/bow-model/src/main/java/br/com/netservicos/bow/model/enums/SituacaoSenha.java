package br.com.netservicos.bow.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum SituacaoSenha {

    ATIVO(1), BLOQUEADO(2), AGUARDANDO_ALTERACAO(3), EXPIRADO(4);

    protected static final Map<Integer, SituacaoSenha> values = new HashMap<>();
    
    private Integer value;
    
    static {
        
        for (SituacaoSenha situacao: values()) {
            values.put(situacao.value, situacao);
        }
    }
    
    private SituacaoSenha(Integer value) {
        this.value = value;
    }
    
    public static final SituacaoSenha getSituacaoSenha(final Integer value) {
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
    
}
