package br.com.netservicos.bow.model;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_regionais", catalog = "coti_prd", schema = "coti_prd")
@NamedQuery(name = "Regional.findAllAtivas", query = "from Regional regional where regional.status = true")
public class Regional implements BaseModel<Long> {

    private static final long serialVersionUID = -2773892738746296287L;

    @Id
    @Column(name = "id_regional", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "regionalAplicacao")
    @JsonIgnore
    private Set<OperacaoRegional> regionaisOperacoes;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_empresa", foreignKey = @ForeignKey(name = "fk_empresa_regional"))
    private Empresa empresa;

    @Column(name = "nm_regional")
    @NotBlank
    private String nome;

    @Column(name = "ds_regional")
    @NotBlank
    private String descricao;

    @Column(name = "vl_peso", precision = 6, scale = 2)
    private BigDecimal peso;

    @Column(name = "fl_ativo")
    private Boolean status;

    public Regional() {
        // Construtor padrão
    }

    public Regional(String nome, String descricao) {
        this.nome = nome;
        this.descricao = descricao;
        this.status = true;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public Set<OperacaoRegional> getRegionaisOperacoes() {
        return regionaisOperacoes;
    }

    public void setRegionaisOperacoes(Set<OperacaoRegional> regionaisOperacoes) {
        this.regionaisOperacoes = regionaisOperacoes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Regional other = (Regional) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Nome: ", nome).add("Status: ", status).toString();
    }

}
