package br.com.netservicos.bow.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.netservicos.bow.model.enums.TipoConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.model.enums.converter.TipoConfiguracaoIndisponibilidadeConverter;

@Entity
@Table(name = "tb_dashboard_configuracao_indisponibilidade", catalog = "book", schema = "book")
public class DashboardConfiguracaoIndisponibilidade extends BaseEntity<Long> {

    private static final long serialVersionUID = -7355990444237312023L;

    @Id
    @Column(name = "id_dashboard_configuracao_indisponibilidade", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_empresa", foreignKey = @ForeignKey(name = "fk_dashboardconfiguracaoindisponibilidade_empresa"))
    private Empresa empresa;

    @Column(name = "vl_indisponibilidade")
    private BigDecimal valor;

    @Convert(converter = TipoConfiguracaoIndisponibilidadeConverter.class)
    @Column(name = "vl_tipo")
    private TipoConfiguracaoIndisponibilidade tipo;

    @Column(name = "dt_indisponibilidade")
    @Temporal(TemporalType.DATE)
    private Date data;

    public DashboardConfiguracaoIndisponibilidade() {
        // Construtor padrão
    }

    public DashboardConfiguracaoIndisponibilidade(BigDecimal valor, Date data) {
        this.valor = valor;
        this.data = data;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public TipoConfiguracaoIndisponibilidade getTipo() {
        return tipo;
    }

    public void setTipo(TipoConfiguracaoIndisponibilidade tipo) {
        this.tipo = tipo;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

}
