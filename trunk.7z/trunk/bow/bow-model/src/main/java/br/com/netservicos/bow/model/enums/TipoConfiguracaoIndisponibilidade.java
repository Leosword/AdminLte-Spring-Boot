package br.com.netservicos.bow.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum TipoConfiguracaoIndisponibilidade {
    
    RECHAMADA(1, "bow_tipo_configuracao_rechamada"), QUANTIDADE_LIGACAO(2, "bow_tipo_configuracao_quantidade_ligacao"), VOLUME_DE_LIGACAO(3,
            "bow_tipo_configuracao_volume_ligacao"), VENDA_BRUTA(4, "bow_tipo_configuracao_venda_bruta"), ATIVACAO_BRUTA(5,
                    "bow_tipo_configuracao_ativacao_bruta"), VISITA_PRODUTIVA(6,
                            "bow_tipo_configuracao_visita_produtiva"), VISITA_IMPRODUTIVA(7, "bow_tipo_configuracao_visita_improdutiva");

    protected static final Map<Integer, TipoConfiguracaoIndisponibilidade> values = new HashMap<>();

    private Integer value;

    private String description;
    
    static {
        
        for(TipoConfiguracaoIndisponibilidade tipo : values()){
            values.put(tipo.value, tipo);
        }
    }

    private TipoConfiguracaoIndisponibilidade(Integer value, String description) {
        this.value = value;
        this.description = description;
    }
    
    public static final TipoConfiguracaoIndisponibilidade getTipoConfiguracaoIndisponibilidade(final Integer value){      
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
}
