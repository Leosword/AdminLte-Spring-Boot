package br.com.netservicos.bow.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.google.common.base.MoreObjects;

@Embeddable
public class Endereco implements Serializable {

    private static final long serialVersionUID = -393211100949026218L;

    @Column(name = "ds_endereco_complemento")
    private String complemento;

    @Column(name = "ds_endereco_logradouro")
    private String logradouro;

    @Column(name = "vl_endereco_numero")
    private String numero;

    @Column(name = "ds_endereco_bairro")
    private String bairro;

    @Column(name = "ds_endereco_cep")
    private String cep;

    public Endereco() {
        // Construtor padrão
    }

    public Endereco(String complemento, String logradouro, String numero, String bairro, String cep) {
        this.complemento = complemento;
        this.logradouro = logradouro;
        this.numero = numero;
        this.bairro = bairro;
        this.cep = cep;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Endereco other = (Endereco) obj;

        return Objects.equals(this.cep, other.cep);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.cep);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Cep: ", cep).add("Complemento: ", complemento).toString();
    }

}
