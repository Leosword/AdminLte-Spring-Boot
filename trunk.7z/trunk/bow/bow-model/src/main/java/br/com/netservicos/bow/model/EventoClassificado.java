package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ConstraintMode;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_classifica_eventos", catalog = "coti_prd", schema = "coti_prd")
@NamedQuery(name = "EventoClassificado.findAllAtivos", query = "select evento from EventoClassificado evento where evento.aprovado is null")
public class EventoClassificado implements BaseModel<Long> {

    private static final long serialVersionUID = -2621572388519052419L;

    @Id
    @Column(name = "id", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_empresa", foreignKey = @ForeignKey(name = "fk_empresa_eventoclassificado"))
    private Empresa empresa;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_aplicacao", foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Aplicacao aplicacao;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_grupo_solucionador", foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private GrupoSolucionador grupo;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_acao_evento", foreignKey = @ForeignKey(name = "fk_acao_eventoclassificado"))
    private AcaoEvento acao;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_origem_evento", foreignKey = @ForeignKey(name = "fk_origem_eventoclassificado"))
    private OrigemEvento origem;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_tipo_evento", foreignKey = @ForeignKey(name = "fk_tipo_eventoclassificado"))
    private TipoEvento tipoEvento;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_tipo_impacto", foreignKey = @ForeignKey(name = "fk_impacto_eventoclassificado"))
    private TipoImpacto impacto;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_diretoria", foreignKey = @ForeignKey(name = "fk_diretoria_eventoclassificado"))
    private Diretoria diretoria;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_ofensor_primario", foreignKey = @ForeignKey(name = "fk_ofensorprimario_eventoclassificado"))
    private OfensorAplicacao primario;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_ofensor_secundario", foreignKey = @ForeignKey(name = "fk_ofensorsecundario_eventoclassificado"))
    private OfensorAplicacao secundario;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_tipo_indisponibilidade", foreignKey = @ForeignKey(name = "fk_indisponibilidade_eventoclassificado"))
    private TipoIndisponibilidadeEvento tipoIndisponibilidade;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "evento")
    private Set<ImpactoIndicadorEvento> impactosIndicador;

    @Column(name = "id_evento")
    private Long eventoId;

    @Column(name = "id_evento_pai")
    private Long eventoPaiId;

    @Column(name = "id_status_classificacao")
    private Long classificacao;

    @Embedded
    private FCAEvento fcaEvento;

    @Column(name = "ds_chamado_aberto")
    private String chamado;

    @Column(name = "id_rca_relacionada")
    private Long rca;

    @Column(name = "ds_duracao_real_evento")
    private String minutos;

    @Column(name = "fl_impacta_cr")
    private Boolean impactoContactRate;

    @Column(name = "fl_aprovado")
    private Boolean aprovado;

    @Column(name = "dt_inicio_real")
    @Temporal(TemporalType.TIMESTAMP)
    private Date inicio;

    @Column(name = "dt_termino_real")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fim;

    @Column(name = "dt_ultima_atualizacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date atualizacao;

    public EventoClassificado() {
        // Construtor padrão
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public Aplicacao getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(Aplicacao aplicacao) {
        this.aplicacao = aplicacao;
    }

    public GrupoSolucionador getGrupo() {
        return grupo;
    }

    public void setGrupo(GrupoSolucionador grupo) {
        this.grupo = grupo;
    }

    public FCAEvento getFcaEvento() {
        return fcaEvento;
    }

    public void setFcaEvento(FCAEvento fcaEvento) {
        this.fcaEvento = fcaEvento;
    }

    public AcaoEvento getAcao() {
        return acao;
    }

    public void setAcao(AcaoEvento acao) {
        this.acao = acao;
    }

    public OrigemEvento getOrigem() {
        return origem;
    }

    public void setOrigem(OrigemEvento origem) {
        this.origem = origem;
    }

    public TipoEvento getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(TipoEvento tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public TipoImpacto getImpacto() {
        return impacto;
    }

    public void setImpacto(TipoImpacto impacto) {
        this.impacto = impacto;
    }

    public Diretoria getDiretoria() {
        return diretoria;
    }

    public void setDiretoria(Diretoria diretoria) {
        this.diretoria = diretoria;
    }

    public OfensorAplicacao getPrimario() {
        return primario;
    }

    public void setPrimario(OfensorAplicacao primario) {
        this.primario = primario;
    }

    public OfensorAplicacao getSecundario() {
        return secundario;
    }

    public void setSecundario(OfensorAplicacao secundario) {
        this.secundario = secundario;
    }

    public TipoIndisponibilidadeEvento getTipoIndisponibilidade() {
        return tipoIndisponibilidade;
    }

    public void setTipoIndisponibilidade(TipoIndisponibilidadeEvento tipoIndisponibilidade) {
        this.tipoIndisponibilidade = tipoIndisponibilidade;
    }

    public Set<ImpactoIndicadorEvento> getImpactosIndicador() {
        return impactosIndicador;
    }

    public void setImpactosIndicador(Set<ImpactoIndicadorEvento> impactosIndicador) {
        this.impactosIndicador = impactosIndicador;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public Long getEventoId() {
        return eventoId;
    }

    public void setEventoId(Long eventoId) {
        this.eventoId = eventoId;
    }

    public Long getEventoPaiId() {
        return eventoPaiId;
    }

    public void setEventoPaiId(Long eventoPaiId) {
        this.eventoPaiId = eventoPaiId;
    }

    public Long getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(Long classificacao) {
        this.classificacao = classificacao;
    }

    public String getChamado() {
        return chamado;
    }

    public void setChamado(String chamado) {
        this.chamado = chamado;
    }

    public Long getRca() {
        return rca;
    }

    public void setRca(Long rca) {
        this.rca = rca;
    }

    public String getMinutos() {
        return minutos;
    }

    public void setMinutos(String minutos) {
        this.minutos = minutos;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getFim() {
        return fim;
    }

    public void setFim(Date fim) {
        this.fim = fim;
    }

    public Date getAtualizacao() {
        return atualizacao;
    }

    public void setAtualizacao(Date atualizacao) {
        this.atualizacao = atualizacao;
    }

    public Boolean getAprovado() {
        return aprovado;
    }

    public void setAprovado(Boolean aprovado) {
        this.aprovado = aprovado;
    }

    public Boolean getImpactoContactRate() {
        return impactoContactRate;
    }

    public void setImpactoContactRate(Boolean impactoContactRate) {
        this.impactoContactRate = impactoContactRate;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        EventoClassificado other = (EventoClassificado) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Aplicação: ", aplicacao).add("Empresa: ", empresa)
                .add("Aprovado: ", aprovado).toString();
    }

}
