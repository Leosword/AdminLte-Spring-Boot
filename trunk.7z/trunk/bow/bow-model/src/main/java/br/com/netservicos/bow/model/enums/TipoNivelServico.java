package br.com.netservicos.bow.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum TipoNivelServico {

    RESIDENCIAL(1, "bow_aplicacao_book_residencial"), PESSOAL(2, "bow_aplicacao_book_pessoal"), EMPRESARIAL(3,
            "bow_aplicacao_book_empresarial"), CORPORATIVO(4, "bow_aplicacao_book_corporativo"), NEGOCIO(5, "bow_aplicacao_book_negocio"), SISTEMICO(
                    6, "bow_aplicacao_book_sistemico"), NET_UNO(7, "bow_aplicacao_book_netuno"), REGIONAL(8, "bow_aplicacao_book_regional");

    protected static final Map<Integer, TipoNivelServico> values = new HashMap<>();

    private Integer value;

    private String description;

    static {

        for (TipoNivelServico tipo : values()) {
            values.put(tipo.value, tipo);
        }
    }

    private TipoNivelServico(Integer value, String description) {
        this.value = value;
        this.description = description;
    }

    public static final TipoNivelServico getTipoNivelServico(final Integer value) {
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}