package br.com.netservicos.bow.model;

import java.io.Serializable;

public interface BaseModel<T> extends Serializable {

	T getId();

	void setId(T id);

}
