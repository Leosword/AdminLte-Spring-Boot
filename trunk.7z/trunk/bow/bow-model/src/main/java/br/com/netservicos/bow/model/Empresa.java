package br.com.netservicos.bow.model;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

import com.google.common.base.MoreObjects;

import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.model.enums.converter.IdentificadorEmpresaConverter;

@Entity
@Table(name = "tb_empresas", catalog = "coti_prd", schema = "coti_prd")
@NamedQuery(name = "Empresa.findAllAtivas", query = "select empresa from Empresa empresa where empresa.status = true")
public class Empresa implements BaseModel<Long> {

    private static final long serialVersionUID = 3056504684774435761L;

    @Id
    @Column(name = "id_empresa", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ds_empresa")
    @NotBlank
    private String descricao;

    @Convert(converter = IdentificadorEmpresaConverter.class)
    @Column(name = "ds_identificador")
    private IdentificadorEmpresa identificador;

    @Column(name = "fl_ativo")
    private Boolean status;

    public Empresa() {
        // Construtor padrão
    }

    public Empresa(Long id, String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public IdentificadorEmpresa getIdentificador() {
        return identificador;
    }

    public void setIdentificador(IdentificadorEmpresa identificador) {
        this.identificador = identificador;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Empresa other = (Empresa) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Descrição: ", descricao).add("Status: ", status).toString();
    }

}
