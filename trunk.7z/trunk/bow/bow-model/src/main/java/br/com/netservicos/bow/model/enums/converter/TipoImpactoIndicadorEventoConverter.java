package br.com.netservicos.bow.model.enums.converter;

import javax.persistence.AttributeConverter;

import br.com.netservicos.bow.model.enums.TipoImpactoIndicadorEvento;

public class TipoImpactoIndicadorEventoConverter implements AttributeConverter<TipoImpactoIndicadorEvento, Integer> {

    @Override
    public Integer convertToDatabaseColumn(TipoImpactoIndicadorEvento situacaoSenha) {
        return situacaoSenha.getValue();
    }

    @Override
    public TipoImpactoIndicadorEvento convertToEntityAttribute(Integer value) {
        return TipoImpactoIndicadorEvento.getTipo(value);
    }

}
