package br.com.netservicos.bow.model;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import com.google.common.base.MoreObjects;

@MappedSuperclass
public abstract class BaseEntity<T> implements BaseModel<T> {

    private static final long serialVersionUID = 4350933809591115243L;

    @Version
    @Column(name = "version")
    private Long version;

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        BaseEntity<?> other = (BaseEntity<?>) obj;

        return Objects.equals(this.getId(), other.getId());
    }

    @Override
    public int hashCode() {

        return Objects.hashCode(this.getId());
    }

    @Override
    public String toString() {

        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", getId()).toString();
    }

}