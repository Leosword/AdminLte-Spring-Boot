package br.com.netservicos.bow.model.enums.converter;

import javax.persistence.AttributeConverter;

import br.com.netservicos.bow.model.enums.StatusAtivoInativo;

public class StatusAtivoInativoConverter implements AttributeConverter<StatusAtivoInativo, Integer> {

    @Override
    public Integer convertToDatabaseColumn(StatusAtivoInativo status) {
        return status.getValue();
    }

    @Override
    public StatusAtivoInativo convertToEntityAttribute(Integer value) {
        return StatusAtivoInativo.getStatusAtivoInativo(value);
    }

}
