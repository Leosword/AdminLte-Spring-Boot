package br.com.netservicos.bow.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_net_bases", schema = "coti_prd", catalog = "coti_prd")
@NamedQuery(name = "Base.findAll", query = "select base from Base base")
public class Base implements BaseModel<Long> {

    private static final long serialVersionUID = -5142692590220513969L;

    @Id
    @Column(name = "id_base", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "base")
    @JsonIgnore
    private Set<BaseAplicacao> basesAplicacoes;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "base")
    @JsonIgnore
    private List<Cidade> cidades;

    @Column(name = "ds_base")
    @NotBlank
    private String nome;

    @Column(name = "vl_peso", precision = 6, scale = 2)
    private BigDecimal peso;

    @Column(name = "fl_ativo")
    private Boolean status;

    public Base() {
        // Construtor padrão
    }

    public Base(Long id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public Base(String nome, BigDecimal peso) {
        this.nome = nome;
        this.peso = peso;
        this.status = true;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Set<BaseAplicacao> getBasesAplicacoes() {
        return basesAplicacoes;
    }

    public void setBasesAplicacoes(Set<BaseAplicacao> basesAplicacoes) {
        this.basesAplicacoes = basesAplicacoes;
    }

    public List<Cidade> getCidades() {
        return cidades;
    }

    public void setCidades(List<Cidade> cidades) {
        this.cidades = cidades;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Base other = (Base) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Nome: ", nome).add("Status: ", status).toString();
    }

}
