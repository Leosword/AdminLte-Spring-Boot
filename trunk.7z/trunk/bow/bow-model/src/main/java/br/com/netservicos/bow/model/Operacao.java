package br.com.netservicos.bow.model;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_localidades", catalog = "coti_prd", schema = "coti_prd")
@NamedQuery(name = "Operacao.findAllAtivas", query = "select operacao from Operacao operacao where operacao.statusOperacao = true")
public class Operacao implements BaseModel<Long> {

    private static final long serialVersionUID = 6022175830797266645L;

    @Id
    @Column(name = "id_localidade", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cidade", foreignKey = @ForeignKey(name = "fk_cidade_localidade"))
    private Cidade cidade;

    @Column(name = "ds_localidade")
    @NotBlank
    private String nome;

    @Embedded
    private Endereco endereco;

    @Column(name = "fl_operacao")
    private Boolean statusOperacao;

    @Column(name = "fl_status")
    private Boolean status;

    @Column(name = "fl_removido")
    private Boolean removido;

    public Operacao() {
        // Construtor padrão
    }

    public Operacao(String nome) {
        this.nome = nome;
        this.status = true;
    }

    public Operacao(Long id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean getStatusOperacao() {
        return statusOperacao;
    }

    public void setStatusOperacao(Boolean statusOperacao) {
        this.statusOperacao = statusOperacao;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Operacao other = (Operacao) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Nome: ", nome).add("Status: ", status).toString();
    }

}
