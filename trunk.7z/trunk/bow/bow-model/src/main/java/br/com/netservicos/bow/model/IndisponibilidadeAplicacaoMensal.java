package br.com.netservicos.bow.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_indisponibilidade_aplicacao_mensal", catalog = "book", schema = "book")
@NamedQuery(name = "IndisponibilidadeAplicacaoMensal.findAll", query = "select indisponibilidade from IndisponibilidadeAplicacaoMensal indisponibilidade where indisponibilidade.desativacao is null")
public class IndisponibilidadeAplicacaoMensal extends BaseEntity<Long> {

    private static final long serialVersionUID = -5266686345330431465L;

    @Id
    @Column(name = "id_indisponibilidade_aplicacao_mensal", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_aplicacao", foreignKey = @ForeignKey(name = "fk_indisponibilidadeaplicacaomensal_aplicacao"))
    private Aplicacao aplicacao;

    @Column(name = "vl_minutos_aplicacao")
    private BigDecimal totalMinutos;

    @Column(name = "vl_percentual_base", precision = 6, scale = 2)
    private BigDecimal percentualBase;

    @Column(name = "vl_minutos_pospatch_aplicacao")
    private BigDecimal totalMinutosPosPatch;

    @Column(name = "vl_percentual_pospatch_base", precision = 6, scale = 2)
    private BigDecimal percentualBasePosPatch;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.DATE)
    private Date criacao;

    @Column(name = "dt_desativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date desativacao;

    public IndisponibilidadeAplicacaoMensal() {
        // Construtor padrão
    }

    public IndisponibilidadeAplicacaoMensal(Aplicacao aplicacao, BigDecimal totalMinutos, BigDecimal percentualBase, BigDecimal totalMinutosPosPatch,
            BigDecimal percentualBasePosPatch, Date criacao) {
        this.aplicacao = aplicacao;
        this.totalMinutos = totalMinutos;
        this.percentualBase = percentualBase;
        this.totalMinutosPosPatch = totalMinutosPosPatch;
        this.percentualBasePosPatch = percentualBasePosPatch;
        this.criacao = criacao;
    }

    public IndisponibilidadeAplicacaoMensal(BigDecimal totalMinutos, BigDecimal percentualBase) {
        this.totalMinutos = totalMinutos;
        this.percentualBase = percentualBase;
    }

    public IndisponibilidadeAplicacaoMensal(BigDecimal totalMinutos, BigDecimal percentualBase, BigDecimal totalMinutosPosPatch,
            BigDecimal percentualBasePosPatch) {
        this.totalMinutos = totalMinutos;
        this.percentualBase = percentualBase;
        this.totalMinutosPosPatch = totalMinutosPosPatch;
        this.percentualBasePosPatch = percentualBasePosPatch;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Aplicacao getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(Aplicacao aplicacao) {
        this.aplicacao = aplicacao;
    }

    public BigDecimal getTotalMinutos() {
        return totalMinutos;
    }

    public void setTotalMinutos(BigDecimal totalMinutos) {
        this.totalMinutos = totalMinutos;
    }

    public BigDecimal getPercentualBase() {
        return percentualBase;
    }

    public void setPercentualBase(BigDecimal percentualBase) {
        this.percentualBase = percentualBase;
    }

    public BigDecimal getTotalMinutosPosPatch() {
        return totalMinutosPosPatch;
    }

    public void setTotalMinutosPosPatch(BigDecimal totalMinutosPosPatch) {
        this.totalMinutosPosPatch = totalMinutosPosPatch;
    }

    public BigDecimal getPercentualBasePosPatch() {
        return percentualBasePosPatch;
    }

    public void setPercentualBasePosPatch(BigDecimal percentualBasePosPatch) {
        this.percentualBasePosPatch = percentualBasePosPatch;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public Date getDesativacao() {
        return desativacao;
    }

    public void setDesativacao(Date desativacao) {
        this.desativacao = desativacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        IndisponibilidadeAplicacaoMensal other = (IndisponibilidadeAplicacaoMensal) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {

        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Aplicação: ", aplicacao).add("Total de Minutos: ", totalMinutos)
                .add("Percentual Base: ", percentualBase).toString();
    }

}
