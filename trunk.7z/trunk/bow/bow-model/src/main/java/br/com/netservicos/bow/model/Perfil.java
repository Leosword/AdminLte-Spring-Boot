package br.com.netservicos.bow.model;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.validator.constraints.NotBlank;

import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_perfil", catalog = "book", schema = "book", uniqueConstraints = {
        @UniqueConstraint(name = "un_perfil_nome", columnNames = { "nome" }) })
public class Perfil extends BaseEntity<Long> {

    private static final long serialVersionUID = 8826128613391337337L;

    @Id
    @Column(name = "id_perfil", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "nome")
    private String nome;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Perfil other = (Perfil) obj;

        return Objects.equals(this.id, other.id) && Objects.equals(this.nome, other.nome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.nome);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Nome: ", nome).toString();
    }

}
