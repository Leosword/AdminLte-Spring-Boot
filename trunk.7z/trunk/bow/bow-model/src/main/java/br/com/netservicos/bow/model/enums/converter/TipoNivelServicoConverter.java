package br.com.netservicos.bow.model.enums.converter;

import javax.persistence.AttributeConverter;

import br.com.netservicos.bow.model.enums.TipoNivelServico;

public class TipoNivelServicoConverter implements AttributeConverter<TipoNivelServico, Integer> {

    @Override
    public Integer convertToDatabaseColumn(TipoNivelServico tipo) {
        return tipo.getValue();
    }

    @Override
    public TipoNivelServico convertToEntityAttribute(Integer value) {
        return TipoNivelServico.getTipoNivelServico(value);
    }

}
