package br.com.netservicos.bow.model.enums.converter;

import javax.persistence.AttributeConverter;

import br.com.netservicos.bow.model.enums.SituacaoSenha;

public class SituacaoSenhaConverter implements AttributeConverter<SituacaoSenha, Integer> {

    @Override
    public Integer convertToDatabaseColumn(SituacaoSenha situacaoSenha) {
        return situacaoSenha.getValue();
    }

    @Override
    public SituacaoSenha convertToEntityAttribute(Integer value) {
        return SituacaoSenha.getSituacaoSenha(value);
    }

}
