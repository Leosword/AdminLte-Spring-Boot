package br.com.netservicos.bow.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum TipoImpactoIndicadorEvento {

    BASE(1), CIDADE(2), OPERACAO(3);

    protected static final Map<Integer, TipoImpactoIndicadorEvento> values = new HashMap<>();
    
    private Integer value;
    
    static {
        
        for (TipoImpactoIndicadorEvento situacao: values()) {
            values.put(situacao.value, situacao);
        }
    }
    
    private TipoImpactoIndicadorEvento(Integer value) {
        this.value = value;
    }
    
    public static final TipoImpactoIndicadorEvento getTipo(final Integer value) {
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
    
}
