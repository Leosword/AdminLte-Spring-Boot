package br.com.netservicos.bow.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.google.common.base.MoreObjects;

@Entity
@Table(name = "tb_regional_aplicacao", catalog = "book", schema = "book")
public class RegionalAplicacao extends BaseEntity<Long> {

    private static final long serialVersionUID = 2081067160280004873L;

    @Id
    @Column(name = "id_regional_aplicacao", precision = 8, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_regional", foreignKey = @ForeignKey(name = "fk_regionalaplicacao_regional"), nullable = false)
    private Regional regional;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_aplicacao", foreignKey = @ForeignKey(name = "fk_regionalaplicacao_aplicacao"), nullable = false)
    private Aplicacao aplicacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", foreignKey = @ForeignKey(name = "fk_regionalaplicacao_usuario"), nullable = false)
    private Usuario usuario;

    @Column(name = "dt_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date criacao;

    @Column(name = "dt_desativacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date desativacao;

    public RegionalAplicacao() {
        // Construtor padrão
    }

    public RegionalAplicacao(Regional regional, Aplicacao aplicacao, Usuario usuario) {
        this.regional = regional;
        this.aplicacao = aplicacao;
        this.usuario = usuario;
        this.criacao = new Date();
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Regional getRegional() {
        return regional;
    }

    public void setRegional(Regional regional) {
        this.regional = regional;
    }

    public Aplicacao getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(Aplicacao aplicacao) {
        this.aplicacao = aplicacao;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

    public Date getDesativacao() {
        return desativacao;
    }

    public void setDesativacao(Date desativacao) {
        this.desativacao = desativacao;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        RegionalAplicacao other = (RegionalAplicacao) obj;

        return Objects.equals(this.id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this.getClass()).add("Id: ", id).add("Regional: ", regional).add("Aplicação: ", aplicacao).toString();
    }

}
