package br.com.netservicos.bow.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum SituacaoEvento {

    CRIAR(1), ATUALIZAR(2), REMOVER(3);

    protected static final Map<Integer, SituacaoEvento> values = new HashMap<>();
    
    private Integer value;
    
    static {
        
        for (SituacaoEvento situacao: values()) {
            values.put(situacao.value, situacao);
        }
    }
    
    private SituacaoEvento(Integer value) {
        this.value = value;
    }
    
    public static final SituacaoEvento getSituacaoEvento(final Integer value) {
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
    
}
