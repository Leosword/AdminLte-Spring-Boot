package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.util.List;

public class DashboardIndisponnibilidadeDiaria implements Serializable {

    private static final long serialVersionUID = -6921187782604099774L;

    private String labelTotal;

    private String labelParcial;

    private String labelFuncional;

    private String labelLinha;

    private String labelSupport;

    private Boolean somenteUmaLinha;
    
    private Boolean semLinha;

    private List<IndisponibilidadeAplicacaoBean> values;

    public DashboardIndisponnibilidadeDiaria() {
        // Construtor padrão
    }

    public DashboardIndisponnibilidadeDiaria(String labelTotal, String labelParcial, String labelFuncional) {
        this.labelTotal = labelTotal;
        this.labelParcial = labelParcial;
        this.labelFuncional = labelFuncional;
    }

    public DashboardIndisponnibilidadeDiaria(String labelTotal, String labelParcial, String labelFuncional, String labelLinha,
            List<IndisponibilidadeAplicacaoBean> values) {
        this.labelTotal = labelTotal;
        this.labelParcial = labelParcial;
        this.labelFuncional = labelFuncional;
        this.labelLinha = labelLinha;
        this.values = values;
    }

    public DashboardIndisponnibilidadeDiaria(String labelTotal, String labelParcial, String labelFuncional, String labelLinha, String labelSupport,
            List<IndisponibilidadeAplicacaoBean> values) {
        this.labelTotal = labelTotal;
        this.labelParcial = labelParcial;
        this.labelFuncional = labelFuncional;
        this.labelLinha = labelLinha;
        this.labelSupport = labelSupport;
        this.values = values;
    }

    public String getLabelTotal() {
        return labelTotal;
    }

    public void setLabelTotal(String labelTotal) {
        this.labelTotal = labelTotal;
    }

    public String getLabelParcial() {
        return labelParcial;
    }

    public void setLabelParcial(String labelParcial) {
        this.labelParcial = labelParcial;
    }

    public String getLabelFuncional() {
        return labelFuncional;
    }

    public void setLabelFuncional(String labelFuncional) {
        this.labelFuncional = labelFuncional;
    }

    public String getLabelLinha() {
        return labelLinha;
    }

    public void setLabelLinha(String labelLinha) {
        this.labelLinha = labelLinha;
    }

    public String getLabelSupport() {
        return labelSupport;
    }

    public void setLabelSupport(String labelSupport) {
        this.labelSupport = labelSupport;
    }

    public List<IndisponibilidadeAplicacaoBean> getValues() {
        return values;
    }

    public void setValues(List<IndisponibilidadeAplicacaoBean> values) {
        this.values = values;
    }

    public Boolean getSomenteUmaLinha() {
        return somenteUmaLinha;
    }

    public void setSomenteUmaLinha(Boolean somenteUmaLinha) {
        this.somenteUmaLinha = somenteUmaLinha;
    }
    public Boolean getSemLinha() {
        return semLinha;
    }

    public void setSemLinha(Boolean semLinha) {
        this.semLinha = semLinha;
    }

}
