package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class DetalhesIndisponibilidadeDiariaBean implements Serializable {

    private static final long serialVersionUID = 2220624146585704208L;

    private String aplicacao;

    private String inicio;

    private String fim;

    private String minutos;

    private String fato;

    private String causa;

    private String acao;

    private String fornecedor;

    private Long rca;

    public DetalhesIndisponibilidadeDiariaBean() {
        // Construtor padrão
    }

    public DetalhesIndisponibilidadeDiariaBean(String aplicacao, String inicio, String fim, String minutos, String fato, String causa, String acao,
            String fornecedor, Long rca) {
        this.aplicacao = aplicacao;
        this.inicio = inicio;
        this.fim = fim;
        this.minutos = minutos;
        this.fato = fato;
        this.causa = causa;
        this.acao = acao;
        this.fornecedor = fornecedor;
        this.rca = rca;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

    public String getInicio() {
        return inicio;
    }

    public void setInicio(String inicio) {
        this.inicio = inicio;
    }

    public String getFim() {
        return fim;
    }

    public void setFim(String fim) {
        this.fim = fim;
    }

    public String getMinutos() {
        return minutos;
    }

    public void setMinutos(String minutos) {
        this.minutos = minutos;
    }

    public String getFato() {
        return fato;
    }

    public void setFato(String fato) {
        this.fato = fato;
    }

    public String getCausa() {
        return causa;
    }

    public void setCausa(String causa) {
        this.causa = causa;
    }

    public String getAcao() {
        return acao;
    }

    public void setAcao(String acao) {
        this.acao = acao;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Long getRca() {
        return rca;
    }

    public void setRca(Long rca) {
        this.rca = rca;
    }

}
