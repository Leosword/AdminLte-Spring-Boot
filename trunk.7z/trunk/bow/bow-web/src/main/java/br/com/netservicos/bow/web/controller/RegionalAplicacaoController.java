package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.RegionalAplicacao;
import br.com.netservicos.bow.service.PaggableSelect;
import br.com.netservicos.bow.service.RegionalAplicacaoService;
import br.com.netservicos.bow.web.bean.AplicacaoBean;
import br.com.netservicos.bow.web.bean.RegionalAplicacaoBean;

@RestController
@RequestMapping(value = RegionalAplicacaoController.REQUEST_MAPPING_PAGE)
public class RegionalAplicacaoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RegionalAplicacaoController.class);

    private static final String VALUE_SEPARATOR = " - ";

    protected static final String REQUEST_MAPPING_PAGE = "/regional-aplicacao";

    @Autowired
    private RegionalAplicacaoService regionalAplicacaoService;

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<RegionalAplicacaoBean>> carregar(PaggableSelect paggable) {

        LOGGER.debug("Carregando as aplicações com a pagina: {}", paggable);

        List<RegionalAplicacao> regionaisAplicacao = regionalAplicacaoService.findByPaggebleSelect(paggable);

        if (regionaisAplicacao.isEmpty()) {

            return new ResponseEntity<List<RegionalAplicacaoBean>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<RegionalAplicacaoBean> regionalAplicacoes = new ArrayList<>();

        regionaisAplicacao.forEach(aplicacaoRegional -> {

            Aplicacao aplicacao = aplicacaoRegional.getAplicacao();

            String nomeCompleto = String.join(VALUE_SEPARATOR, aplicacao.getDescricao(), aplicacao.getEmpresa().getDescricao(),
                    aplicacaoRegional.getRegional().getNome());

            RegionalAplicacaoBean regionalAplicacao = new RegionalAplicacaoBean(aplicacaoRegional.getId(), nomeCompleto);

            regionalAplicacoes.add(regionalAplicacao);
        });

        return new ResponseEntity<List<RegionalAplicacaoBean>>(regionalAplicacoes, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarAplicacao", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Aplicacao>> carregarAplicacao(Long regionalId) {

        List<RegionalAplicacao> regionalAplicacoes = regionalAplicacaoService.findByAplicacoes(regionalId);

        if (regionalAplicacoes.isEmpty()) {

            return new ResponseEntity<List<Aplicacao>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<Aplicacao> aplicacoes = regionalAplicacoes.stream()
                .map(regionalAplicacao -> AplicacaoBean.formaterField(regionalAplicacao.getAplicacao())).collect(Collectors.toList());

        return new ResponseEntity<List<Aplicacao>>(aplicacoes, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarPorId", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RegionalAplicacaoBean> carregarPorId(Long regionalAplicacaoId) {

        if (regionalAplicacaoId != null) {

            Optional<RegionalAplicacao> aplicacaoRegional = regionalAplicacaoService.findFetchAllById(regionalAplicacaoId);

            if (!aplicacaoRegional.isPresent()) {

                return new ResponseEntity<RegionalAplicacaoBean>(HttpStatus.NO_CONTENT);
            }

            RegionalAplicacao regionalAplicacao = aplicacaoRegional.get();

            String nomeCompleto = String.join(VALUE_SEPARATOR, regionalAplicacao.getAplicacao().getDescricao(),
                    regionalAplicacao.getRegional().getNome());

            RegionalAplicacaoBean regionalAplicacaoBean = new RegionalAplicacaoBean(regionalAplicacao.getId(), nomeCompleto);

            return new ResponseEntity<RegionalAplicacaoBean>(regionalAplicacaoBean, HttpStatus.OK);
        }

        return new ResponseEntity<RegionalAplicacaoBean>(HttpStatus.NO_CONTENT);
    }

}
