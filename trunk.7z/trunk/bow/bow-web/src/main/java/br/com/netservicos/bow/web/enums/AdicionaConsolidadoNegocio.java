package br.com.netservicos.bow.web.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.web.bean.ConsolidadoNegocioBean;

public enum AdicionaConsolidadoNegocio {

    NET(IdentificadorEmpresa.NET) {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioBean bean) {

            bean.setMinutosNet(minutos.getMinutos());
            bean.setPercentualNet(minutos.getPercentual());
        }
    },
    CLARO_MOVEL(IdentificadorEmpresa.CLARO_MOVEL) {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioBean bean) {

            bean.setMinutosClaroMovel(minutos.getMinutos());
            bean.setPercentualClaroMovel(minutos.getPercentual());
        }
    },
    EMBRATEL(IdentificadorEmpresa.EMBRATEL) {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioBean bean) {

            bean.setMinutosEmbratel(minutos.getMinutos());
            bean.setPercentualEmbratel(minutos.getPercentual());
        }

    },
    CLARO_HDTV(IdentificadorEmpresa.CLARO_HDTV) {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioBean bean) {

            bean.setMinutosClaroTv(minutos.getMinutos());
            bean.setPercentualClaroTv(minutos.getPercentual());
        }

    };

    protected static final Map<IdentificadorEmpresa, AdicionaConsolidadoNegocio> values = new HashMap<>();

    private IdentificadorEmpresa value;

    static {
        values.putAll(Arrays.asList(values()).stream().collect(Collectors.toMap(AdicionaConsolidadoNegocio::getValue, Function.identity())));
    }

    private AdicionaConsolidadoNegocio(IdentificadorEmpresa value) {
        this.value = value;
    }

    public static AdicionaConsolidadoNegocio getObject(final IdentificadorEmpresa identificador) {
        return values.get(identificador);
    }

    public IdentificadorEmpresa getValue() {
        return value;
    }

    public void setValue(IdentificadorEmpresa value) {
        this.value = value;
    }

    public abstract void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioBean bean);

}
