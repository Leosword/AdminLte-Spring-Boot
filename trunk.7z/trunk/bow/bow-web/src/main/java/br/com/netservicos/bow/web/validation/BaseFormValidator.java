package br.com.netservicos.bow.web.validation;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.google.common.collect.Range;

import br.com.netservicos.bow.web.bean.BaseBean;

@Component
public class BaseFormValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return BaseBean.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {

        BaseBean baseBean = (BaseBean) target;

        if (baseBean.getPeso() != null) {

            boolean contains = Range.closed(new BigDecimal("0.00"), new BigDecimal("1.00")).contains(baseBean.getPeso());

            if (!contains) {

                errors.rejectValue("peso", "rangeInvalido", new Object[] { "'peso'" }, "Campo peso deve esta entre 0.00 e 1.00");
            }
        }

    }

}
