package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.Servico;
import br.com.netservicos.bow.model.ServicoAplicacao;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.EmpresaService;
import br.com.netservicos.bow.service.IndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.ParametroService;
import br.com.netservicos.bow.service.ServicoAplicacaoService;
import br.com.netservicos.bow.service.ServicoService;
import br.com.netservicos.bow.service.TipoAplicacaoService;
import br.com.netservicos.bow.web.bean.ConsolidadoNegocioBean;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;
import br.com.netservicos.bow.web.enums.AdicionaConsolidadoNegocio;

@RestController
@RequestMapping(value = ConsolidadoNegocioController.REQUEST_MAPPING_PAGE)
public class ConsolidadoNegocioController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConsolidadoNegocioController.class);

    private static final String REDIRECT_PAGE_CARREGAR = "/carregar";

    protected static final String REQUEST_MAPPING_PAGE = "/negocio";

    private static final String REQUEST_MAPPING_PAGE_CONSOLIDADO = "consolidadonegocios/pesquisarconsolidadonegocio";

    @Autowired
    private ServicoService service;

    @Autowired
    private ServicoAplicacaoService servicoAplicacaoService;

    @Autowired
    private IndisponibilidadeAplicacaoMensalService indisponibilidadeAplicacaoMensalService;

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    @Autowired
    private ParametroService parametroService;

    @Autowired
    private TipoAplicacaoService tipoAplicacaoService;

    @Autowired
    private EmpresaService empresaService;

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    @RequestMapping(value = "/consolidado", method = RequestMethod.GET)
    public ModelAndView showPesquisarSistemaDetail(Model model) {

        Parametro parametroSla = parametroService.findByNome(ParametroConstants.VALOR_SLA);

        Parametro parametroBH = parametroService.findByNome(ParametroConstants.BUSINESS_HOURS);

        LocalDate localDate = LocalDate.now();

        int ano = localDate.getYear();

        Month month = localDate.getMonth();

        BigDecimal totalMinutos = calculaIndisponibilidadeService.calculaMinutosBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        BigDecimal totalPercentual = calculaIndisponibilidadeService.calculaPercentualBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        model.addAttribute("sla_minutos", totalMinutos);

        model.addAttribute("sla_percentual", totalPercentual);

        model.addAttribute("ano", ano);

        return new ModelAndView(REQUEST_MAPPING_PAGE_CONSOLIDADO);
    }

    @RequestMapping(value = ConsolidadoNegocioController.REDIRECT_PAGE_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ConsolidadoNegocioBean>> carregar(IndisponibilidadeQueryParameterBean parameter) {

        LOGGER.debug("Carregando os consolidados de negocio");

        List<Servico> servicos = service.findAllAtivas();

        if (CollectionUtil.isEmpty(servicos)) {

            LOGGER.error("Não foi possível localizar os serviços cadastrados");

            return new ResponseEntity<List<ConsolidadoNegocioBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        Optional<TipoAplicacao> tipoAplicacao = tipoAplicacaoService.findByAtivo(parameter.getTipoAplicacao());

        if (!tipoAplicacao.isPresent()) {

            LOGGER.error("Não foi possível localizar o tipo com nome: {}", parameter.getTipoAplicacao());

            return new ResponseEntity<List<ConsolidadoNegocioBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<ConsolidadoNegocioBean> consolidados = addConsolidado(servicos, tipoAplicacao);

        return new ResponseEntity<List<ConsolidadoNegocioBean>>(consolidados, HttpStatus.OK);
    }

    private List<ConsolidadoNegocioBean> addConsolidado(List<Servico> servicos, Optional<TipoAplicacao> tipoAplicacao) {

        LocalDate atual = LocalDate.now();

        Integer ano = atual.getYear();

        Integer mes = atual.getMonthValue();

        List<Empresa> empresas = empresaService.findAll();

        List<ConsolidadoNegocioBean> consolidados = new ArrayList<>();

        servicos.forEach(servico -> {

            ConsolidadoNegocioBean bean = new ConsolidadoNegocioBean();

            bean.setServico(servico.getNome());

            empresas.forEach(empresa -> {

                List<ServicoAplicacao> servicosAplicacao = servicoAplicacaoService.findByEmpresa(empresa, servico);

                List<Aplicacao> aplicacoes = servicosAplicacao.stream().map(servicoAplicacao -> servicoAplicacao.getAplicacao())
                        .filter(aplicacao -> tipoAplicacao.get().equals(aplicacao.getTipo())).distinct().collect(Collectors.toList());

                List<IndisponibilidadeAplicacaoMensal> indisponibilidades = indisponibilidadeAplicacaoMensalService.findByPeriodo(ano, mes,
                        aplicacoes);

                if (!CollectionUtil.isEmpty(indisponibilidades)) {

                    BigDecimal minutos = indisponibilidades.stream().map(indisponibilidade -> indisponibilidade.getTotalMinutos())
                            .reduce(BigDecimal.ZERO, BigDecimal::add);

                    BigDecimal percentuais = indisponibilidades.stream().map(indisponibilidade -> indisponibilidade.getPercentualBase())
                            .reduce(BigDecimal.ZERO, BigDecimal::add);

                    BigDecimal minutosAplicacao = minutos.divide(new BigDecimal(aplicacoes.size()), MathContext.DECIMAL32)
                            .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

                    BigDecimal percentualAplicacao = percentuais.divide(new BigDecimal(aplicacoes.size()), MathContext.DECIMAL32)
                            .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

                    MinutosIndisponibilidade minutosIndisponibilidade = new MinutosIndisponibilidade(converter.convert(minutosAplicacao),
                            percentualAplicacao);

                    AdicionaConsolidadoNegocio.getObject(empresa.getIdentificador()).adiciona(minutosIndisponibilidade, bean);
                }

            });

            consolidados.add(bean);

        });

        return consolidados;
    }

}
