package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.service.BaseService;
import br.com.netservicos.bow.service.PaggableSelect;
import br.com.netservicos.bow.service.authetication.Principal;
import br.com.netservicos.bow.web.bean.BaseBean;
import br.com.netservicos.bow.web.constants.ControllerConstants;
import br.com.netservicos.bow.web.validation.BaseFormValidator;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = BaseController.REQUEST_MAPPING_PAGE)
public class BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseController.class);

    private static final String SEPARATOR = "";

    private static final String ACTION_ATUALIZAR = "/base/atualizar";

    private static final String MODEL_NAME = "baseBean";

    private static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REDIRECT_PAGE_CARREGAR = "/carregar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "base/pesquisarbase";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR = "base/incluirbase";

    protected static final String REQUEST_MAPPING_PAGE = "/base";

    @Autowired
    private BaseService baseService;

    @Autowired
    private BaseFormValidator baseFormValidator;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = BaseController.REDIRECT_PAGE_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Base>> carregar() {

        LOGGER.debug("Iniciando o carregamento das bases");

        List<Base> bases = baseService.findAllAtivas();

        return new ResponseEntity<List<Base>>(bases, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarPaginacao", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Base>> carregar(PaggableSelect paggable) {

        LOGGER.debug("Iniciando o carregamento das bases com pagina: {}", paggable);

        List<Base> bases = baseService.findByPaggebleSelect(paggable);

        if (bases.isEmpty()) {

            return new ResponseEntity<List<Base>>(new ArrayList<>(), HttpStatus.OK);
        }

        return new ResponseEntity<List<Base>>(bases, HttpStatus.OK);
    }

    @RequestMapping(value = "/incluir/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ModelAndView viewEditar(@PathVariable("id") Long id, ModelMap model, HttpServletRequest request) {

        LOGGER.debug("O id a ser atualizado é: {}", id);

        Optional<Base> base = baseService.findByFetchAll(id);

        if (!base.isPresent()) {

            throw new BusinessException("Não foi possivel localizar o id.");
        }

        BaseBean baseBean = BaseBean.bindingProperties(base.get());

        model.addAttribute(MODEL_NAME, baseBean);

        model.addAttribute(ControllerConstants.METHOD_NAME, RequestMethod.PUT.name());

        String action = String.join(SEPARATOR, request.getContextPath(), ACTION_ATUALIZAR);

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = "/atualizar/{id}", method = RequestMethod.PUT)
    public ResponseEntity<ValidationResponse> atualizar(@Valid @RequestBody BaseBean baseBean, @PathVariable("id") Long id, BindingResult result) {

        baseFormValidator.validate(baseBean, result);

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            fieldErrors.forEach(fieldError -> {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            });

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Optional<Base> baseOptional = baseService.findByFetchAll(id);

        if (!baseOptional.isPresent()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Base base = baseOptional.get();

        base.setPeso(baseBean.getPeso());

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ((authentication instanceof AnonymousAuthenticationToken)) {

            throw new BusinessException("Não foi possível localizar usuário autenticado.");
        }

        Principal principal = (Principal) authentication.getPrincipal();

        baseService.atualizar(base, baseBean.getAplicacoes(), principal.getEmail(), baseBean.getCidadesId());

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @ExceptionHandler(BusinessException.class)
    public String handleBusinessExceptionException(BusinessException exception) {

        ModelAndView model = new ModelAndView();

        model.addObject("exception", exception.getMessage());

        model.setViewName(REQUEST_MAPPING_PAGE_INCLUIR);

        return exception.getMessage();
    }

}
