package br.com.netservicos.bow.web.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.service.UsuarioService;
import br.com.netservicos.bow.service.authetication.Principal;
import br.com.netservicos.bow.web.bean.UsuarioBean;
import br.com.netservicos.bow.web.validation.UsuarioFormValidator;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = ProfileController.REQUEST_MAPPING_PAGE)
public class ProfileController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProfileController.class);

    protected static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "profile/incluirprofile";

    protected static final String REDIRECT_PAGE_SAVE_USUARIO = "/salvar";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR = "profile/incluirprofile";

    protected static final String REQUEST_MAPPING_PAGE = "/perfil";

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private UsuarioFormValidator validator;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (!(auth instanceof AnonymousAuthenticationToken)) {

            Principal principal = (Principal) auth.getPrincipal();

            UsuarioBean usuario = new UsuarioBean(principal.getId(), principal.getUsername(), principal.getSobrenome(), principal.getLogin(),
                    principal.getTelefone(), principal.getEmail(), principal.getPerfil());

            model.addAttribute("usuario", usuario);
        }

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = REDIRECT_PAGE_SAVE_USUARIO, method = RequestMethod.POST)
    public ResponseEntity<ValidationResponse> salvar(@Valid @RequestBody UsuarioBean usuarioForm, BindingResult result, SessionStatus status,
            HttpServletRequest request) {

        validator.validate(usuarioForm, result);

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            for (FieldError fieldError : fieldErrors) {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            }

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Optional<Usuario> optional = usuarioService.findByIdFetchAll(usuarioForm.getId());

        if (!optional.isPresent()) {

            throw new BusinessException("Não foi possível localizar o usuário!");
        }

        Usuario usuario = optional.get();

        usuario.setNome(usuarioForm.getNome());

        usuario.setSobrenome(usuarioForm.getSobrenome());

        usuario.setLogin(usuarioForm.getLogin());

        usuario.setTelefone(usuarioForm.getTelefone());

        usuario.setEmail(usuarioForm.getEmail());

        if (usuarioForm.isTrocarSenha()) {

            usuario.setSenha(usuarioForm.getSenha());

            usuario.setConfirmarSenha(usuarioForm.getSenha());
        }

        usuarioService.salvar(usuario, usuarioForm.getNomePerfil(), usuarioForm.isTrocarSenha());

        Authentication authentication = new UsernamePasswordAuthenticationToken(usuario, usuario.getPerfil());

        SecurityContextHolder.getContext().setAuthentication(authentication);

        status.setComplete();

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @ExceptionHandler(BusinessException.class)
    public String handleBusinessExceptionException(BusinessException exception) {

        LOGGER.error("Error ao realizar o processamento : {}", exception);

        ModelAndView model = new ModelAndView();

        model.addObject("exception", exception.getMessage());

        model.setViewName(REQUEST_MAPPING_PAGE_INCLUIR);

        return exception.getMessage();
    }

}
