package br.com.netservicos.bow.web.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.web.bean.IndisponibilidadeRegionalBean;

public enum AdicionaIndisponibilidadeRegional {

    SUL("SUL") {
        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {

            bean.setMinutosSUL(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualSUL(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    PR_SC("PR/SC") {
        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosPRSC(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualPRSC(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    SP("SP") {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosSP(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualSP(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    SPI("SPI") {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosSPI(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualSPI(String.valueOf(indisponibilidade.getPercentual()));
        }

    },
    RJ("RJ") {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosRJ(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualRJ(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    MG("MG") {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosMG(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualMG(String.valueOf(indisponibilidade.getPercentual()));
        }

    },
    CO("CO") {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosCO(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualCO(String.valueOf(indisponibilidade.getPercentual()));
        }

    },
    NE("NE") {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosNE(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualNE(String.valueOf(indisponibilidade.getPercentual()));
        }

    },
    BA_SE("BA/SE") {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosBASE(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualBASE(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    NO("NO") {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean) {
            bean.setMinutosNO(String.valueOf(indisponibilidade.getMinutos()));
            bean.setPercentualNO(String.valueOf(indisponibilidade.getPercentual()));
        }

    };

    protected static final Map<String, AdicionaIndisponibilidadeRegional> values = new HashMap<>();

    static {

        values.putAll(Arrays.asList(values()).stream().collect(Collectors.toMap(AdicionaIndisponibilidadeRegional::getValue, Function.identity())));
    }

    private AdicionaIndisponibilidadeRegional(String value) {
        this.value = value;
    }

    private String value;

    public static AdicionaIndisponibilidadeRegional getObject(final String value) {
        return values.get(value);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public abstract void adiciona(MinutosIndisponibilidade indisponibilidade, IndisponibilidadeRegionalBean bean);

}
