package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class OperacaoRegionalBean implements Serializable {

    private static final long serialVersionUID = 961846257554792905L;

    private Long id;

    private Long regionalAplicacaoId;

    private Long[] operacaoIds;

    private String nomeCompleto;

    private String nomeOperacao;

    public OperacaoRegionalBean() {
        // Construtor padrão
    }

    public OperacaoRegionalBean(Long id, String nomeCompleto, String nomeOperacao) {
        this.id = id;
        this.nomeCompleto = nomeCompleto;
        this.nomeOperacao = nomeOperacao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRegionalAplicacaoId() {
        return regionalAplicacaoId;
    }

    public void setRegionalAplicacaoId(Long regionalAplicacaoId) {
        this.regionalAplicacaoId = regionalAplicacaoId;
    }

    public Long[] getOperacaoIds() {
        return operacaoIds;
    }

    public void setOperacaoIds(Long[] operacaoIds) {
        this.operacaoIds = operacaoIds;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getNomeOperacao() {
        return nomeOperacao;
    }

    public void setNomeOperacao(String nomeOperacao) {
        this.nomeOperacao = nomeOperacao;
    }

}