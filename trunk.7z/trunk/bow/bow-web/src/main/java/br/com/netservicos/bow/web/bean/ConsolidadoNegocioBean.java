package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class ConsolidadoNegocioBean implements Serializable {

    private static final long serialVersionUID = -6625466389395810360L;

    private String servico;

    private BigDecimal minutosNet;

    private BigDecimal percentualNet;

    private BigDecimal minutosClaroMovel;

    private BigDecimal percentualClaroMovel;

    private BigDecimal minutosEmbratel;

    private BigDecimal percentualEmbratel;

    private BigDecimal minutosClaroTv;

    private BigDecimal percentualClaroTv;

    public ConsolidadoNegocioBean() {
        // Construtor padrão
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public BigDecimal getMinutosNet() {
        return minutosNet;
    }

    public void setMinutosNet(BigDecimal minutosNet) {
        this.minutosNet = minutosNet;
    }

    public BigDecimal getPercentualNet() {
        return percentualNet;
    }

    public void setPercentualNet(BigDecimal percentualNet) {
        this.percentualNet = percentualNet;
    }

    public BigDecimal getMinutosClaroMovel() {
        return minutosClaroMovel;
    }

    public void setMinutosClaroMovel(BigDecimal minutosClaroMovel) {
        this.minutosClaroMovel = minutosClaroMovel;
    }

    public BigDecimal getPercentualClaroMovel() {
        return percentualClaroMovel;
    }

    public void setPercentualClaroMovel(BigDecimal percentualClaroMovel) {
        this.percentualClaroMovel = percentualClaroMovel;
    }

    public BigDecimal getMinutosEmbratel() {
        return minutosEmbratel;
    }

    public void setMinutosEmbratel(BigDecimal minutosEmbratel) {
        this.minutosEmbratel = minutosEmbratel;
    }

    public BigDecimal getPercentualEmbratel() {
        return percentualEmbratel;
    }

    public void setPercentualEmbratel(BigDecimal percentualEmbratel) {
        this.percentualEmbratel = percentualEmbratel;
    }

    public BigDecimal getMinutosClaroTv() {
        return minutosClaroTv;
    }

    public void setMinutosClaroTv(BigDecimal minutosClaroTv) {
        this.minutosClaroTv = minutosClaroTv;
    }

    public BigDecimal getPercentualClaroTv() {
        return percentualClaroTv;
    }

    public void setPercentualClaroTv(BigDecimal percentualClaroTv) {
        this.percentualClaroTv = percentualClaroTv;
    }

}
