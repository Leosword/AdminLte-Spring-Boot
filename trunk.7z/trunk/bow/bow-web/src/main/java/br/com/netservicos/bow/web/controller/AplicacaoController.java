package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.service.AplicacaoService;
import br.com.netservicos.bow.service.PaggableSelect;
import br.com.netservicos.bow.service.TipoAplicacaoService;
import br.com.netservicos.bow.web.bean.AplicacaoBean;
import br.com.netservicos.bow.web.constants.ControllerConstants;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = AplicacaoController.REQUEST_MAPPING_PAGE)
public class AplicacaoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AplicacaoController.class);

    protected static final String REDIRECT_PAGE_PESQUISAR = "/aplicacao/{nome}";

    protected static final String REDIRECT_PAGE_FORM_PESQUISAR = "redirect:aplicacao/";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "aplicacao/pesquisaraplicacao";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR_GLOSSARIO = "aplicacao/incluirglossarioaplicacao";

    protected static final String REQUEST_MAPPING_PAGE = "/aplicacao";

    private static final String ACTION_ATUALIZAR = "/aplicacao/atualizar";

    private static final String MODEL_NAME = "aplicacaoBean";

    private static final String SEPARATOR = "";
    
    private static final String TIPO_APLICACAO = "tipoAplicacao";

    @Autowired
    private AplicacaoService aplicacaoService;

    @Autowired
    private TipoAplicacaoService tipoAplicacaoService;

    @RequestMapping(value = "/pesquisar/{tipo}", method = RequestMethod.GET)
    public ModelAndView showPesquisar(@PathVariable("tipo") String tipo, Model model, HttpServletRequest request) {

        model.addAttribute("tipoAplicacao", tipo);

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = "/incluir/glossario/{tipoAplicacao}/{id}", method = RequestMethod.GET)
    public ModelAndView showPesquisarGlossario(@PathVariable Long id, @PathVariable String tipoAplicacao, ModelMap model, HttpServletRequest request) {

        Optional<Aplicacao> optional = aplicacaoService.findById(id);

        if (!optional.isPresent()) {

            LOGGER.error("Não foi possível localizar a aplicação com Id: {}", id);

            throw new BusinessException("Não foi possível localizar o ID da aplicação.");
        }

        Aplicacao aplicacao = optional.get();

        AplicacaoBean aplicacaoBean = new AplicacaoBean(aplicacao.getId(), aplicacao.getEmpresa().getDescricao(), aplicacao.getDescricao(),
                aplicacao.getComplemento(), aplicacao.getImpacto());

        model.addAttribute(MODEL_NAME, aplicacaoBean);

        model.addAttribute(TIPO_APLICACAO, tipoAplicacao);

        model.addAttribute(ControllerConstants.METHOD_NAME, RequestMethod.PUT.name());

        String action = String.join(SEPARATOR, request.getContextPath(), ACTION_ATUALIZAR);

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR_GLOSSARIO);
    }

    @RequestMapping(value = "/atualizar/{id}", method = RequestMethod.PUT)
    public ResponseEntity<ValidationResponse> atualizar(@Valid @RequestBody AplicacaoBean bean, @PathVariable("id") Long id, BindingResult result) {

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            fieldErrors.forEach(fieldError -> {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            });

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Optional<Aplicacao> optional = aplicacaoService.findById(id);

        if (!optional.isPresent()) {

            LOGGER.error("Não foi possível localizar a aplicação com Id: {}", id);

            throw new BusinessException("Não foi possível localizar o ID da aplicação.");
        }

        Aplicacao aplicacao = optional.get();

        aplicacao.setComplemento(bean.getComplemento());

        aplicacao.setImpacto(bean.getImpacto());

        aplicacaoService.atualizar(aplicacao);

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);

    }

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Aplicacao>> carregarAplicacao(PaggableSelect paggable) {

        LOGGER.debug("Iniciando o carregamento das aplicações");

        List<Aplicacao> aplicacoes = aplicacaoService.findByPaggebleSelect(paggable);

        if (aplicacoes.isEmpty()) {

            return new ResponseEntity<List<Aplicacao>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<Aplicacao> aplicacoesBean = AplicacaoBean.formaterFields(aplicacoes);

        return new ResponseEntity<List<Aplicacao>>(aplicacoesBean, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregar/{tipo}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AplicacaoBean>> carregar(@PathVariable("tipo") String value) {

        Optional<String> tipo = Optional.ofNullable(value);

        if (!tipo.isPresent()) {

            LOGGER.error("Não foi possível localizar o campo tipo");

            return new ResponseEntity<List<AplicacaoBean>>(new ArrayList<AplicacaoBean>(), HttpStatus.OK);
        }

        Optional<TipoAplicacao> tipoAplicacao = tipoAplicacaoService.findByAtivo(tipo.get());

        if (!tipoAplicacao.isPresent()) {

            LOGGER.error("Não foi possível localizar o tipo com o nome: {}", tipo);

            return new ResponseEntity<List<AplicacaoBean>>(new ArrayList<AplicacaoBean>(), HttpStatus.OK);
        }

        List<Aplicacao> aplicacoes = aplicacaoService.findByTipo(tipoAplicacao.get());

        List<AplicacaoBean> aplicacoesBean = aplicacoes.stream().map(aplicacao -> new AplicacaoBean(aplicacao.getId(), aplicacao.getEmpresa().getDescricao(), aplicacao.getDescricao(),
                aplicacao.getComplemento(), aplicacao.getImpacto())).collect(Collectors.toList());

        return new ResponseEntity<List<AplicacaoBean>>(aplicacoesBean, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregar/empresa", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AplicacaoBean>> carregarEmpresa(PaggableSelect select) {

        List<Aplicacao> aplicacoes = aplicacaoService.findByEmpresa(select);

        List<AplicacaoBean> aplicacoesBean = aplicacoes.stream().map(aplicacao -> new AplicacaoBean(aplicacao.getId(), aplicacao.getDescricao()))
                .collect(Collectors.toList());

        return new ResponseEntity<List<AplicacaoBean>>(aplicacoesBean, HttpStatus.OK);
    }

}
