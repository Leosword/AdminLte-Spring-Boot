package br.com.netservicos.bow.web.constants;

public final class ControllerConstants {

    public static final String METHOD_NAME = "methodName";

    public static final String ACTION = "action";

    private ControllerConstants() {
    }
}
