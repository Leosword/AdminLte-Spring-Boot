package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.model.enums.TipoNivelServico;
import br.com.netservicos.bow.service.AplicacaoBookService;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.ParametroService;
import br.com.netservicos.bow.web.bean.IndisponibilidadeAplicacaoMensalBean;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;

@RestController
@RequestMapping(value = IndisponibilidadeMensalController.REQUEST_MAPPING_PAGE)
public class IndisponibilidadeMensalController extends AbstractIndisponibilidadeMensalController {

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeMensalController.class);

    protected static final String REQUEST_MAPPING_PAGE = "/indisponibilidade-mensal";

    private static final String REQUEST_MAPPING_CARREGAR_MENSAL = "/carregar-sistemico";

    private static final String REQUEST_MAPPING_CARREGAR_MENSAL_SEM_SLA = "/carregar-sistemico-sem-sla";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL = "indisponibilidade/pesquisarindisponibilidademensal";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL_SISTEMA_DETAIL = "indisponibilidade/pesquisarindisponibilidademensalsistemadetail";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL_SISTEMA = "indisponibilidade/pesquisarindisponibilidademensalsistema";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL_POSPATCH = "indisponibilidade/pesquisarindisponibilidademensalpospatch";

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    @Autowired
    private AplicacaoBookService aplicacaoBookService;

    @Autowired
    private ParametroService parametroService;

    @RequestMapping(value = "/pesquisar/sistema-detail/{tipoAplicacao}/{empresa}/{servico}", method = RequestMethod.GET)
    public ModelAndView showPesquisarSistemaDetail(Model model, @PathVariable String empresa, @PathVariable String tipoAplicacao,
            @PathVariable Integer servico) {

        addProperties(model, servico, tipoAplicacao, empresa);

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL_SISTEMA_DETAIL);
    }

    @RequestMapping(value = "/pesquisar/sistema/{tipoAplicacao}/{empresa}/{servico}", method = RequestMethod.GET)
    public ModelAndView showPesquisarSistema(Model model, @PathVariable String empresa, @PathVariable String tipoAplicacao,
            @PathVariable Integer servico) {

        addProperties(model, servico, tipoAplicacao, empresa);

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL_SISTEMA);
    }

    @RequestMapping(value = "/pesquisar/pospatch/{tipoAplicacao}/{empresa}/{servico}", method = RequestMethod.GET)
    public ModelAndView showPesquisarPosPatch(Model model, @PathVariable String empresa, @PathVariable String tipoAplicacao,
            @PathVariable Integer servico) {

        addProperties(model, servico, tipoAplicacao, empresa);

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL_POSPATCH);
    }

    @RequestMapping(value = "/pesquisar/{tipoAplicacao}/{empresa}/{servico}", method = RequestMethod.GET)
    public ModelAndView showPesquisa(Model model, @PathVariable String empresa, @PathVariable String tipoAplicacao, @PathVariable Integer servico) {

        addProperties(model, servico, tipoAplicacao, empresa);

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL);
    }

    private void addProperties(Model model, Integer servico, String tipoAplicacao, String empresa) {

        Parametro parametroSla = parametroService.findByNome(ParametroConstants.VALOR_SLA);

        Parametro parametroBH = parametroService.findByNome(ParametroConstants.BUSINESS_HOURS);

        LocalDate localDate = LocalDate.now();

        int ano = localDate.getYear();

        Month month = localDate.getMonth();

        BigDecimal totalMinutos = calculaIndisponibilidadeService.calculaMinutosBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        BigDecimal totalPercentual = calculaIndisponibilidadeService.calculaPercentualBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        model.addAttribute("sla_minutos", totalMinutos);

        model.addAttribute("sla_percentual", totalPercentual);

        model.addAttribute("servico", servico);

        model.addAttribute("tipoAplicacao", tipoAplicacao);

        model.addAttribute("empresa", empresa);

        model.addAttribute("nomeempresa", IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(empresa)).getDescription());

        model.addAttribute("ano", ano);
    }

    @RequestMapping(value = REQUEST_MAPPING_CARREGAR_MENSAL, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>> carregar(IndisponibilidadeQueryParameterBean parameter) {

        TipoNivelServico nivelServico = TipoNivelServico.getTipoNivelServico(parameter.getTipo());

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipoComSla(nivelServico, parameter.getEmpresa(),
                parameter.getTipoAplicacao());

        if (CollectionUtil.isEmpty(aplicacoesBook)) {

            LOGGER.error("Não foi possível localizar as aplicações que compõe o book");

            return new ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<IndisponibilidadeAplicacaoMensalBean> indisponibilidades = carregarIndisponibilidade(aplicacoesBook);

        return new ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>>(indisponibilidades, HttpStatus.OK);
    }

    @RequestMapping(value = REQUEST_MAPPING_CARREGAR_MENSAL_SEM_SLA, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>> carregarSemSLA(IndisponibilidadeQueryParameterBean parameter) {

        TipoNivelServico tipo = TipoNivelServico.getTipoNivelServico(parameter.getTipo());

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipo(tipo, parameter.getEmpresa(), parameter.isSlaGeral());

        if (CollectionUtil.isEmpty(aplicacoesBook)) {

            LOGGER.error("Não foi possível localizar as aplicações que compõe o book");

            return new ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<IndisponibilidadeAplicacaoMensalBean> indisponibilidades = carregarIndisponibilidade(aplicacoesBook);

        return new ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>>(indisponibilidades, HttpStatus.OK);
    }

}