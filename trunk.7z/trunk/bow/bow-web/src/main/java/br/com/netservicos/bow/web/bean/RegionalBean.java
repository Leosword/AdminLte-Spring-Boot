package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;

import com.google.gson.Gson;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.Regional;

public class RegionalBean implements Serializable {

    private static final long serialVersionUID = 6541153550151238074L;

    private Long id;

    private Long[] aplicacoes;

    private String empresa;

    @NotBlank
    private String nome;

    @NotBlank
    private String descricao;

    private BigDecimal peso;

    public RegionalBean() {
        // Construtor padrão
    }

    public RegionalBean(Long id, String nome, String descricao, BigDecimal peso) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.peso = peso;
    }

    public RegionalBean(Long id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public RegionalBean(Long id, String nome, String descricao, String empresa, BigDecimal peso) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.empresa = empresa;
        this.peso = peso;
    }

    public static final RegionalBean bindingProperties(Regional regional) {

        RegionalBean regionalBean = new RegionalBean(regional.getId(), regional.getNome(), regional.getDescricao(), regional.getPeso());

        if (regional.getEmpresa() != null) {

            Empresa empresa = new Empresa(regional.getEmpresa().getId(), regional.getEmpresa().getDescricao());

            Gson gson = new Gson();

            regionalBean.setEmpresa(gson.toJson(empresa));
        }

        return regionalBean;
    }

    public static final List<RegionalBean> bindingProperties(List<Regional> regionais) {

        List<RegionalBean> regionaisBean = new ArrayList<>();

        regionais.forEach(regional -> {

            RegionalBean regionalBean = new RegionalBean(regional.getId(), regional.getNome(), regional.getDescricao(),
                    regional.getEmpresa().getDescricao(), regional.getPeso());

            regionaisBean.add(regionalBean);

        });

        return regionaisBean;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long[] getAplicacoes() {
        return aplicacoes;
    }

    public void setAplicacoes(Long[] aplicacoes) {
        this.aplicacoes = aplicacoes;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

}