package br.com.netservicos.bow.web.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.service.EmpresaService;
import br.com.netservicos.bow.service.EventoClassificadoService;
import br.com.netservicos.bow.service.TipoIndisponibilidadeEventoService;
import br.com.netservicos.bow.web.bean.DetalhesIndisponibilidadeDiariaBean;
import br.com.netservicos.bow.web.bean.DetalhesIndisponibilidadeDiariaParameterBean;

@RestController
public class DetalhesIndisponibilidadeDiariaController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DetalhesIndisponibilidadeDiariaController.class);

    private static final String REQUEST_MAPPING_DETALHES = "/indisponibilidade-diaria/carregar-detalhes-custom";

    private static final String PATTERN_DAY = "dd/MM/yyyy";

    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";

    @Autowired
    private TipoIndisponibilidadeEventoService tipoIndisponibilidadeEventoService;

    @Autowired
    private EmpresaService empresaService;

    @Autowired
    private EventoClassificadoService eventoClassificadoService;

    @RequestMapping(value = REQUEST_MAPPING_DETALHES, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DetalhesIndisponibilidadeDiariaBean>> carregarDetalhes(DetalhesIndisponibilidadeDiariaParameterBean bean) {

        LOGGER.debug("Carregando os os detalhes: {}", bean);

        Optional<TipoIndisponibilidadeEvento> tipoOptional = tipoIndisponibilidadeEventoService.findByNome(bean.getTipo());

        if (!tipoOptional.isPresent()) {

            LOGGER.error("Não foi possível localizar o tipo com o nome: {}", bean.getTipo());

            return new ResponseEntity<List<DetalhesIndisponibilidadeDiariaBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        IdentificadorEmpresa identificador = IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(bean.getEmpresa()));

        Optional<Empresa> empresaOptional = empresaService.findByIdentificador(identificador);

        if (!empresaOptional.isPresent()) {

            LOGGER.error("Não foi possível localizar a empresa com Identificador: {}", bean.getEmpresa());

            return new ResponseEntity<List<DetalhesIndisponibilidadeDiariaBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        Date dia = getDate(bean.getDia());

        List<EventoClassificado> eventos = eventoClassificadoService.findByPeriodo(dia, empresaOptional.get(), tipoOptional.get());

        if (CollectionUtil.isEmpty(eventos)) {

            LOGGER.error("Não foi possível localizar os eventos para o dia: {}, empresa: {} e tipo: {}", dia, bean.getEmpresa(), bean.getTipo());

            return new ResponseEntity<List<DetalhesIndisponibilidadeDiariaBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        DateFormat format = new SimpleDateFormat(PATTERN);

        List<DetalhesIndisponibilidadeDiariaBean> detalhes = eventos.stream()
                .map(evento -> new DetalhesIndisponibilidadeDiariaBean(evento.getAplicacao().getDescricao(), format.format(evento.getInicio()),
                        format.format(evento.getFim()), evento.getMinutos(), evento.getFcaEvento().getFato(), evento.getFcaEvento().getCausa(),
                        evento.getFcaEvento().getAcao(), evento.getGrupo().getDescricao(), evento.getRca()))
                .collect(Collectors.toList());

        return new ResponseEntity<List<DetalhesIndisponibilidadeDiariaBean>>(detalhes, HttpStatus.OK);
    }

    private Date getDate(String dia) {

        try {

            return new SimpleDateFormat(PATTERN_DAY).parse(dia);

        } catch (ParseException e) {

            return null;
        }
    }

}
