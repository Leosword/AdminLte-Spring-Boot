package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Servico;
import br.com.netservicos.bow.model.ServicoAplicacao;
import br.com.netservicos.bow.service.ServicoAplicacaoService;
import br.com.netservicos.bow.service.ServicoService;
import br.com.netservicos.bow.service.authetication.Principal;
import br.com.netservicos.bow.web.bean.AplicacaoBean;
import br.com.netservicos.bow.web.bean.ServicoBean;
import br.com.netservicos.bow.web.constants.ControllerConstants;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = ServicoController.REQUEST_MAPPING_PAGE)
public class ServicoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServicoController.class);

    private static final String SEPARATOR = "";

    private static final String ACTION_SALVAR = "/servico/salvar";

    private static final String ACTION_ATUALIZAR = "/servico/atualizar";

    private static final String MODEL_NAME = "servicoBean";

    private static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REDIRECT_PAGE_CARREGAR = "/carregar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "servico/pesquisarservico";

    private static final String REDIRECT_PAGE_SALVAR = "/salvar";

    private static final String REDIRECT_PAGE_INCLUIR = "/incluir";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR = "servico/incluirservico";

    protected static final String REQUEST_MAPPING_PAGE = "/servico";

    @Autowired
    private ServicoService servicoService;

    @Autowired
    private ServicoAplicacaoService servicoAplicacaoService;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = ServicoController.REDIRECT_PAGE_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Servico>> carregar() {

        LOGGER.debug("Iniciando o carregamento das servicos");

        List<Servico> servicos = servicoService.findAllAtivas();

        return new ResponseEntity<List<Servico>>(servicos, HttpStatus.OK);
    }

    @RequestMapping(value = REDIRECT_PAGE_INCLUIR, method = RequestMethod.GET)
    public ModelAndView viewIncluir(ModelMap model, HttpServletRequest request) {

        model.addAttribute(MODEL_NAME, new ServicoBean());

        model.addAttribute(ControllerConstants.METHOD_NAME, RequestMethod.POST.name());

        String action = String.join(SEPARATOR, request.getContextPath(), ACTION_SALVAR);

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = "/incluir/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ModelAndView viewEditar(@PathVariable("id") Long id, ModelMap model, HttpServletRequest request) {

        LOGGER.debug("O id a ser atualizado é: {}", id);

        Optional<Servico> servico = servicoService.findById(id);

        if (!servico.isPresent()) {

            throw new BusinessException("Não foi possivel localizar o id.");
        }

        ServicoBean servicoBean = new ServicoBean(servico.get().getId(), servico.get().getNome(), servico.get().getDescricao());

        model.addAttribute(MODEL_NAME, servicoBean);

        model.addAttribute(ControllerConstants.METHOD_NAME, RequestMethod.PUT.name());

        String action = String.join(SEPARATOR, request.getContextPath(), ACTION_ATUALIZAR);

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = "/carregarAplicacaoPorServico", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Aplicacao>> carregarAplicacao(Long servicoId) {

        List<ServicoAplicacao> servicoAplicacoes = servicoAplicacaoService.findByAplicacoes(servicoId);

        if (servicoAplicacoes.isEmpty()) {

            return new ResponseEntity<List<Aplicacao>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<Aplicacao> aplicacoes = servicoAplicacoes.stream().map(servicoAplicacao -> AplicacaoBean.formaterField(servicoAplicacao.getAplicacao()))
                .collect(Collectors.toList());

        return new ResponseEntity<List<Aplicacao>>(aplicacoes, HttpStatus.OK);
    }

    @RequestMapping(value = REDIRECT_PAGE_SALVAR, method = RequestMethod.POST)
    public ResponseEntity<ValidationResponse> salvar(@Valid @RequestBody ServicoBean servicoBean, BindingResult result) {

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            fieldErrors.forEach(fieldError -> {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            });

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Servico servico = new Servico(servicoBean.getNome(), servicoBean.getDescricao());

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ((authentication instanceof AnonymousAuthenticationToken)) {

            throw new BusinessException("Não foi possível localizar usuário autenticado.");
        }

        Principal principal = (Principal) authentication.getPrincipal();

        servicoService.salvar(servico, servicoBean.getAplicacoes(), principal.getEmail());

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @RequestMapping(value = "/atualizar/{id}", method = RequestMethod.PUT)
    public ResponseEntity<ValidationResponse> atualizar(@Valid @RequestBody ServicoBean servicoAplicacaoBean, @PathVariable("id") Long id,
            BindingResult result) {

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            fieldErrors.forEach(fieldError -> {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            });

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Optional<Servico> servicoOptional = servicoService.findById(id);

        if (!servicoOptional.isPresent()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Servico servico = servicoOptional.get();

        servico.setNome(servicoAplicacaoBean.getNome());

        servico.setDescricao(servicoAplicacaoBean.getDescricao());

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ((authentication instanceof AnonymousAuthenticationToken)) {

            throw new BusinessException("Não foi possível localizar usuário autenticado.");
        }

        Principal principal = (Principal) authentication.getPrincipal();

        servicoService.atualizar(servico, servicoAplicacaoBean.getAplicacoes(), principal.getEmail());

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @RequestMapping(value = "/remover/{ids}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> remover(@PathVariable("ids") Long[] ids) {

        LOGGER.debug("Serviços a serem removidos: {}", new Object[] { ids });

        servicoService.deletar(ids);

        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(BusinessException.class)
    public String handleBusinessExceptionException(BusinessException exception) {

        ModelAndView model = new ModelAndView();

        model.addObject("exception", exception.getMessage());

        model.setViewName(REQUEST_MAPPING_PAGE_INCLUIR);

        return exception.getMessage();
    }

}
