package br.com.netservicos.bow.web.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.service.EmpresaService;
import br.com.netservicos.bow.service.IndisponibilidadeEventoService;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;
import br.com.netservicos.bow.web.bean.ResumoIndisponibilidadeAplicacaoBean;

@RestController
@RequestMapping(value = ResumoIndisponibilidadeAplicacaoController.REQUEST_MAPPING_PAGE)
public class ResumoIndisponibilidadeAplicacaoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResumoIndisponibilidadeAplicacaoController.class);

    private static final String REDIRECT_PAGE_CARREGAR = "/carregar";

    protected static final String REQUEST_MAPPING_PAGE = "/resumo";

    private static final String PATTERN = "dd/MM/yyyy";

    @Autowired
    private IndisponibilidadeEventoService service;

    @Autowired
    private EmpresaService empresaService;

    @RequestMapping(value = ResumoIndisponibilidadeAplicacaoController.REDIRECT_PAGE_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ResumoIndisponibilidadeAplicacaoBean>> carregar(IndisponibilidadeQueryParameterBean parameter) {

        LOGGER.debug("Carregando as indiponibilidades por empresa");

        LocalDate atual = LocalDate.now();

        Integer ano = atual.getYear();

        Integer mes = atual.getMonthValue();

        Optional<Empresa> optional = empresaService.findByIdentificador(IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(parameter.getEmpresa())));

        if (!optional.isPresent()) {

            LOGGER.error("Não foi possível localizar a empresa com o Identificador: {}", parameter.getEmpresa());

            return new ResponseEntity<List<ResumoIndisponibilidadeAplicacaoBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<IndisponibilidadeEvento> indisponibilidades = service.findByPeriodo(ano, mes, optional.get());

        List<ResumoIndisponibilidadeAplicacaoBean> resumos = indisponibilidades.stream()
                .map(indisponibilidade -> new ResumoIndisponibilidadeAplicacaoBean(
                        new SimpleDateFormat(PATTERN).format(indisponibilidade.getCriacao()), indisponibilidade.getAplicacao().getDescricao(),
                        indisponibilidade.getEvento().getFcaEvento().getFato(), indisponibilidade.getEvento().getFcaEvento().getCausa()))
                .collect(Collectors.toList());

        return new ResponseEntity<List<ResumoIndisponibilidadeAplicacaoBean>>(resumos, HttpStatus.OK);
    }

}
