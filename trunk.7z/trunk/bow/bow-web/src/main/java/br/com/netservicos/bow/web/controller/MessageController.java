package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.service.EventoClassificadoService;
import br.com.netservicos.bow.service.UsuarioService;
import br.com.netservicos.bow.web.bean.EventoClassificadoBean;

@RestController
@RequestMapping(value = MessageController.REQUEST_MAPPING_PAGE)
public class MessageController {

    protected static final String REQUEST_MAPPING_PAGE = "/message";

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageController.class);

    private static final String PERFIL_INDICADORES = "MASTER";

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private SimpMessagingTemplate template;

    @Autowired
    private EventoClassificadoService eventoClassificadoService;

    @RequestMapping(value = "/evento/{eventoPai}/{situacao}", method = RequestMethod.GET)
    public ResponseEntity<List<EventoClassificadoBean>> carregarTarefas(@PathVariable("eventoPai") Long eventoId,
            @PathVariable("situacao") Integer situacao) {

        if (eventoId == null) {

            return new ResponseEntity<List<EventoClassificadoBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<EventoClassificado> eventosSemAprovacao = eventoClassificadoService.findUtimosSemAprovacao();

        if (CollectionUtil.isEmpty(eventosSemAprovacao)) {

            return new ResponseEntity<List<EventoClassificadoBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<EventoClassificadoBean> eventosBean = eventosSemAprovacao.stream().map(
                evento -> new EventoClassificadoBean(evento.getMinutos(), evento.getAplicacao().getDescricao(), evento.getEmpresa().getDescricao()))
                .collect(Collectors.toList());

        LOGGER.info("Evento com Id: {}, foi disponibilizado", eventoId);

        List<Usuario> usuarios = usuarioService.findNomeUsuarioByPerfil(PERFIL_INDICADORES);

        if (!CollectionUtil.isEmpty(usuarios)) {

            usuarios.forEach(usuario -> {

                LOGGER.debug("Enviando notificação de Tarefa para usuário: {}", usuario.getNome());

                template.convertAndSendToUser(usuario.getNome(), "/topic/carregarTarefas", eventosBean);
            });
        }

        return new ResponseEntity<List<EventoClassificadoBean>>(eventosBean, HttpStatus.OK);
    }

}
