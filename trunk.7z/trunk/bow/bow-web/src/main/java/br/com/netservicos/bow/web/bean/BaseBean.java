package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.hibernate.validator.constraints.NotBlank;

import com.google.common.collect.Iterables;
import com.google.gson.Gson;

import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.Cidade;
import br.com.netservicos.bow.model.Estado;

public class BaseBean implements Serializable {

    private static final long serialVersionUID = -773118672250435050L;

    private static final String TODAS_OU_NENHUMA = "TODAS OU NENHUMA";

    private Long id;

    private Long[] aplicacoes;

    private boolean endereco = false;

    private Long[] cidadesId;

    private String cidade;

    private String estado;

    @NotBlank
    private String nome;

    private BigDecimal peso;

    public BaseBean() {
        // Construtor Padrão
    }

    public BaseBean(Long id, String nome, BigDecimal peso) {
        this.id = id;
        this.nome = nome;
        this.peso = peso;
    }

    public BaseBean(String nome, BigDecimal peso) {
        this.nome = nome;
        this.peso = peso;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long[] getAplicacoes() {
        return aplicacoes;
    }

    public void setAplicacoes(Long[] aplicacoes) {
        this.aplicacoes = aplicacoes;
    }

    public Long[] getCidadesId() {
        return cidadesId;
    }

    public void setCidadesId(Long[] cidadesId) {
        this.cidadesId = cidadesId;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public boolean isEndereco() {
        return endereco;
    }

    public void setEndereco(boolean endereco) {
        this.endereco = endereco;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public static BaseBean bindingProperties(Base base) {

        BaseBean baseBean = new BaseBean(base.getId(), base.getNome(), base.getPeso());

        if (!Iterables.isEmpty(base.getCidades())) {

            List<Cidade> cidadesFilter = base.getCidades().stream().filter(cidade -> !TODAS_OU_NENHUMA.equalsIgnoreCase(cidade.getNome()))
                    .collect(Collectors.toList());

            List<Cidade> cidades = new ArrayList<>();

            cidadesFilter.forEach(cidade -> {

                cidades.add(new Cidade(cidade.getId(), cidade.getNome()));
            });

            String cidade = new Gson().toJson(cidades);

            baseBean.setCidade(cidade);

            String estado = new Gson().toJson(transformEstado(cidadesFilter));

            baseBean.setEstado(estado);

            baseBean.setEndereco(true);
        }

        return baseBean;

    }

    private static List<Estado> transformEstado(List<Cidade> cidades) {

        Function<Cidade, Estado> cidadeFunction = new Function<Cidade, Estado>() {

            @Override
            public Estado apply(Cidade cidade) {

                Estado estado = cidade.getEstado();

                if (estado == null) {

                    return new Estado();
                }

                return new Estado(estado.getId(), estado.getNome());
            }
        };

        List<Estado> estados = cidades.stream().map(cidadeFunction).distinct().collect(Collectors.<Estado> toList());

        return estados;
    }

}
