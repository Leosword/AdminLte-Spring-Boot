package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Multimap;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.DateUtil;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.model.enums.TipoNivelServico;
import br.com.netservicos.bow.service.AplicacaoBookService;
import br.com.netservicos.bow.service.IndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.collector.MultimapCollector;
import br.com.netservicos.bow.web.bean.DetalhesIndisponibilidadeMensalBean;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;
import br.com.netservicos.bow.web.enums.Meses;

@RestController
public class DetalhesIndisponibilidadeMensalController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DetalhesIndisponibilidadeMensalController.class);

    private static final String REQUEST_MAPPING_DETALHES = "/indisponibilidade-mensal/carregar-detalhes";

    private static final String REQUEST_MAPPING_DETALHES_NIVEL_SERVICO = "/indisponibilidade-mensal/carregar-detalhes-nivelservico";

    private static final String REQUEST_MAPPING_DETALHES_POS_PATCH = "/indisponibilidade-mensal/carregar-detalhes-pospatch";

    private static final String SEPARATOR = ", ";

    @Autowired
    private AplicacaoBookService aplicacaoBookService;

    @Autowired
    private IndisponibilidadeAplicacaoMensalService indisponibilidadeAplicacaoMensalService;

    @RequestMapping(value = REQUEST_MAPPING_DETALHES, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>> detalhes(IndisponibilidadeQueryParameterBean parameter) {

        TipoNivelServico nivelServico = TipoNivelServico.getTipoNivelServico(parameter.getTipo());

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipo(nivelServico, parameter.getEmpresa(),
                parameter.getTipoAplicacao());

        if (CollectionUtil.isEmpty(aplicacoesBook)) {

            LOGGER.error("Não foi possível localizar as aplicações que compõe o book");

            return new ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<DetalhesIndisponibilidadeMensalBean> detalhes = carregar(aplicacoesBook);

        return new ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>>(detalhes, HttpStatus.OK);
    }

    @RequestMapping(value = REQUEST_MAPPING_DETALHES_NIVEL_SERVICO, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>> detalhesNivelServico(IndisponibilidadeQueryParameterBean parameter) {

        TipoNivelServico nivelServico = TipoNivelServico.getTipoNivelServico(parameter.getTipo());

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipo(nivelServico);

        if (CollectionUtil.isEmpty(aplicacoesBook)) {

            LOGGER.error("Não foi possível localizar as aplicações que compõe o book");

            return new ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<DetalhesIndisponibilidadeMensalBean> detalhes = carregar(aplicacoesBook);

        return new ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>>(detalhes, HttpStatus.OK);
    }

    private List<DetalhesIndisponibilidadeMensalBean> carregar(List<AplicacaoBook> aplicacoesBook) {

        List<Aplicacao> aplicacoes = aplicacoesBook.stream().map(AplicacaoBook::getAplicacao).collect(Collectors.toList());

        Integer ano = DateUtil.getYear(new Date());

        List<DetalhesIndisponibilidadeMensalBean> detalhes = new ArrayList<>();

        List<IndisponibilidadeAplicacaoMensal> indisponibilidades = indisponibilidadeAplicacaoMensalService.findByAno(ano, aplicacoes);

        Multimap<Integer, IndisponibilidadeAplicacaoMensal> indisponibilidadesMes = indisponibilidades.stream()
                .collect(MultimapCollector.toMultimap((IndisponibilidadeAplicacaoMensal v) -> DateUtil.getMonth(v.getCriacao())));

        indisponibilidadesMes.asMap().keySet().iterator().forEachRemaining(mes -> {

            Collection<IndisponibilidadeAplicacaoMensal> indisponibilidadesAplicacoes = indisponibilidadesMes.get(mes);

            Set<String> aplicacoesValidas = indisponibilidadesAplicacoes.stream().map(IndisponibilidadeAplicacaoMensal::getAplicacao)
                    .map(Aplicacao::getDescricao).collect(Collectors.toSet());

            String descricoes = String.join(SEPARATOR, aplicacoesValidas);

            detalhes.add(new DetalhesIndisponibilidadeMensalBean(Meses.getObject(mes).getExtension(), descricoes));

        });
        
        return detalhes;
    }

    @RequestMapping(value = REQUEST_MAPPING_DETALHES_POS_PATCH, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>> detalhesPosPatch(IndisponibilidadeQueryParameterBean parameter) {

        TipoNivelServico nivelServico = TipoNivelServico.getTipoNivelServico(parameter.getTipo());

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipo(nivelServico, parameter.getEmpresa(),
                parameter.getTipoAplicacao());

        if (CollectionUtil.isEmpty(aplicacoesBook)) {

            LOGGER.error("Não foi possível localizar as aplicações que compõe o book");

            return new ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<Aplicacao> aplicacoes = aplicacoesBook.stream().map(AplicacaoBook::getAplicacao).collect(Collectors.toList());

        Integer ano = DateUtil.getYear(new Date());

        List<DetalhesIndisponibilidadeMensalBean> detalhes = new ArrayList<>();

        List<IndisponibilidadeAplicacaoMensal> indisponibilidades = indisponibilidadeAplicacaoMensalService.findByAno(ano, aplicacoes);

        Multimap<Integer, IndisponibilidadeAplicacaoMensal> indisponibilidadesMes = indisponibilidades.stream()
                .filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch()))
                .collect(MultimapCollector.toMultimap((IndisponibilidadeAplicacaoMensal v) -> DateUtil.getMonth(v.getCriacao())));

        indisponibilidadesMes.asMap().keySet().iterator().forEachRemaining(mes -> {

            Collection<IndisponibilidadeAplicacaoMensal> indisponibilidadesAplicacoes = indisponibilidadesMes.get(mes);

            Set<String> aplicacoesValidas = indisponibilidadesAplicacoes.stream().map(IndisponibilidadeAplicacaoMensal::getAplicacao)
                    .map(Aplicacao::getDescricao).collect(Collectors.toSet());

            String descricoes = String.join(SEPARATOR, aplicacoesValidas);

            detalhes.add(new DetalhesIndisponibilidadeMensalBean(Meses.getObject(mes).getExtension(), descricoes));

        });

        return new ResponseEntity<List<DetalhesIndisponibilidadeMensalBean>>(detalhes, HttpStatus.OK);
    }

}
