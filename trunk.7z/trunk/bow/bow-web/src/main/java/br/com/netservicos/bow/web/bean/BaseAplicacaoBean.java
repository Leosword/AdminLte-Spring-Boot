package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class BaseAplicacaoBean implements Serializable {

    private static final long serialVersionUID = 8263601024436500762L;

    private Long id;

    private String nomeCompleto;

    public BaseAplicacaoBean() {
        // Construtor padrão
    }

    public BaseAplicacaoBean(Long id, String nomeCompleto) {
        this.id = id;
        this.nomeCompleto = nomeCompleto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

}
