package br.com.netservicos.bow.web.enums;

import java.util.HashMap;
import java.util.Map;

import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.web.bean.DetalhesConsolidadoNegocioBean;

public enum AdicionaConsolidadoNegocioMensal {

    JANEIRO(1) {
        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosJaneiro(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualJaneiro(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    FEVEREIRO(2) {
        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosFevereiro(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualFevereiro(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    MARCO(3) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosMarco(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualMarco(String.valueOf(indisponibilidade.getPercentual()));
        }

    },
    ABRIL(4) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosAbril(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualAbril(String.valueOf(indisponibilidade.getPercentual()));
        }

    },
    MAIO(5) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosMaio(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualMaio(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    JUNHO(6) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosJunho(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualJunho(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    JULHO(7) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosJulho(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualJulho(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    AGOSTO(8) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosAgosto(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualAgosto(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    SETEMBRO(9) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosSetembro(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualSetembro(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    OUTUBRO(10) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosOutubro(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualOutubro(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    NOVEMBRO(11) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosNovembro(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualNovembro(String.valueOf(indisponibilidade.getPercentual()));
        }
    },
    DEZEMBRO(12) {

        @Override
        public void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean) {

            bean.setMinutosDezembro(String.valueOf(indisponibilidade.getMinutos()));

            bean.setPercentualDezembro(String.valueOf(indisponibilidade.getPercentual()));

        }
    };

    protected static final Map<Integer, AdicionaConsolidadoNegocioMensal> values = new HashMap<>();

    private Integer value;

    static {

        for (AdicionaConsolidadoNegocioMensal situacao : values()) {
            values.put(situacao.value, situacao);
        }
    }

    private AdicionaConsolidadoNegocioMensal(Integer value) {
        this.value = value;
    }

    public static final AdicionaConsolidadoNegocioMensal getObject(final Integer value) {
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public abstract void adiciona(MinutosIndisponibilidade indisponibilidade, DetalhesConsolidadoNegocioBean bean);

}
