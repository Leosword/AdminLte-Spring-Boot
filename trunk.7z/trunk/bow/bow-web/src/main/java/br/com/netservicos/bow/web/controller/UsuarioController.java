package br.com.netservicos.bow.web.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Usuario;
import br.com.netservicos.bow.service.UsuarioService;
import br.com.netservicos.bow.web.bean.UsuarioBean;
import br.com.netservicos.bow.web.constants.ControllerConstants;
import br.com.netservicos.bow.web.validation.UsuarioFormValidator;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = UsuarioController.REQUEST_MAPPING_PAGE)
public class UsuarioController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UsuarioController.class);

    private static final String SEPARATOR = "";

    private static final String TROCAR_SENHA = "trocarsenha";

    private static final String HABILITAR_CAMPOS = "habilitaCampos";

    private static final String MODEL_NAME = "usuario";

    private static final String ACTION_SALVAR = "/usuario/salvar";

    private static final String ACTION_ATUALIZAR = "/usuario/atualizar";

    protected static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "usuario/pesquisarusuario";

    protected static final String REDIRECT_PAGE_SAVE_USUARIO = "/salvar";

    protected static final String REDIRECT_PAGE_INCLUIR = "/incluir";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR = "usuario/incluirusuario";

    protected static final String REQUEST_MAPPING_PAGE = "/usuario";

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private UsuarioFormValidator validator;

    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = REDIRECT_PAGE_INCLUIR, method = RequestMethod.GET)
    public ModelAndView viewIncluir(ModelMap model, HttpServletRequest request) {

        model.addAttribute(MODEL_NAME, new UsuarioBean(false));

        model.addAttribute(TROCAR_SENHA, false);

        model.addAttribute(HABILITAR_CAMPOS, true);

        model.addAttribute(ControllerConstants.METHOD_NAME, RequestMethod.POST.name());

        String action = String.join(SEPARATOR, request.getContextPath(), ACTION_SALVAR);

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<UsuarioBean>> carregar() {

        List<Usuario> usuarios = usuarioService.findFetchAll();

        List<UsuarioBean> usuariosBean = UsuarioBean.bindingProperties(usuarios);

        return new ResponseEntity<List<UsuarioBean>>(usuariosBean, HttpStatus.OK);
    }

    @RequestMapping(value = "/remover/{ids}", method = RequestMethod.DELETE)
    public ResponseEntity<Usuario> remover(@PathVariable("ids") Long[] ids) {

        LOGGER.debug("Usuarios a serem removidos: {}", new Object[] { ids });

        usuarioService.deletar(ids);

        return new ResponseEntity<Usuario>(HttpStatus.NO_CONTENT);
    }

    @RequestMapping(value = "/incluir/{id}", method = RequestMethod.GET)
    public ModelAndView viewEditar(@PathVariable("id") Long id, ModelMap model, HttpServletRequest request) {

        LOGGER.debug("O id a ser atualizado é: {}", id);

        Optional<Usuario> optional = usuarioService.findByIdFetchAll(id);

        if (!optional.isPresent()) {

            LOGGER.error("Não foi possível localizar usuário com Id: {}", id);

            throw new BusinessException("Não foi possível localizar o usuário!");
        }

        Usuario usuario = optional.get();

        UsuarioBean usuarioBean = new UsuarioBean(usuario.getId(), usuario.getNome(), usuario.getSobrenome(), usuario.getLogin(),
                usuario.getTelefone(), usuario.getEmail(), usuario.getPerfil().getNome(), usuario.getVersion());

        model.addAttribute(TROCAR_SENHA, true);

        model.addAttribute(HABILITAR_CAMPOS, true);

        model.addAttribute(MODEL_NAME, usuarioBean);

        model.addAttribute(ControllerConstants.METHOD_NAME, RequestMethod.PUT.name());

        String action = String.join(SEPARATOR, request.getContextPath(), ACTION_ATUALIZAR);

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = REDIRECT_PAGE_SAVE_USUARIO, method = RequestMethod.POST)
    public ResponseEntity<ValidationResponse> salvar(@Valid @RequestBody UsuarioBean usuarioBean, BindingResult result, SessionStatus status,
            HttpServletRequest request) {

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            fieldErrors.forEach(fieldError -> {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            });

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Usuario usuario = new Usuario(usuarioBean.getNome(), usuarioBean.getSobrenome(), usuarioBean.getLogin(), usuarioBean.getTelefone(),
                usuarioBean.getEmail(), usuarioBean.getSenha(), usuarioBean.getConfirmarSenha());

        usuarioService.salvar(usuario, usuarioBean.getNomePerfil());

        status.setComplete();

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @RequestMapping(value = "/atualizar/{id}", method = RequestMethod.PUT)
    public ResponseEntity<ValidationResponse> atualizar(@Valid @RequestBody UsuarioBean usuarioBean, @PathVariable("id") Long id,
            BindingResult result) {

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            fieldErrors.forEach(fieldError -> {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            });

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Optional<Usuario> optional = usuarioService.findById(id);

        if (!optional.isPresent()) {

            LOGGER.debug("Não foi possivel localizar usuário com Id: {}", id);

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Usuario usuario = optional.get();

        usuario.setNome(usuarioBean.getNome());

        usuario.setSobrenome(usuarioBean.getSobrenome());

        usuario.setLogin(usuarioBean.getLogin());

        usuario.setEmail(usuarioBean.getEmail());

        usuario.setTelefone(usuarioBean.getTelefone());

        if (usuarioBean.isTrocarSenha()) {

            usuario.setSenha(usuarioBean.getSenha());

            usuario.setConfirmarSenha(usuarioBean.getConfirmarSenha());
        }

        usuarioService.salvar(usuario, usuarioBean.getNomePerfil(), usuarioBean.isTrocarSenha());

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @ExceptionHandler(BusinessException.class)
    public String handleBusinessExceptionException(BusinessException exception) {

        ModelAndView model = new ModelAndView();

        model.addObject("exception", exception.getMessage());
        model.addObject("usuario", new UsuarioBean());

        model.setViewName(REQUEST_MAPPING_PAGE_INCLUIR);

        return exception.getMessage();
    }

}
