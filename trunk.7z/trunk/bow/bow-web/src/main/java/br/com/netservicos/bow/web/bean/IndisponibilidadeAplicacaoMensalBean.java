package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class IndisponibilidadeAplicacaoMensalBean implements Serializable {

    private static final long serialVersionUID = -680705910912044306L;

    private Long id;

    private String aplicacao;

    private String minutosJaneiro;

    private String minutosFevereiro;

    private String minutosMarco;

    private String minutosAbril;

    private String minutosMaio;

    private String minutosJunho;

    private String minutosJulho;

    private String minutosAgosto;

    private String minutosSetembro;

    private String minutosOutubro;

    private String minutosNovembro;

    private String minutosDezembro;

    private String consolidadoMinutosMensal;

    private String percentualJaneiro;

    private String percentualFevereiro;

    private String percentualMarco;

    private String percentualAbril;

    private String percentualMaio;

    private String percentualJunho;

    private String percentualJulho;

    private String percentualAgosto;

    private String percentualSetembro;

    private String percentualOutubro;

    private String percentualNovembro;

    private String percentualDezembro;

    private String consolidadoPercentualMensal;

    private String minutosPosPatchJaneiro;

    private String minutosPosPatchFevereiro;

    private String minutosPosPatchMarco;

    private String minutosPosPatchAbril;

    private String minutosPosPatchMaio;

    private String minutosPosPatchJunho;

    private String minutosPosPatchJulho;

    private String minutosPosPatchAgosto;

    private String minutosPosPatchSetembro;

    private String minutosPosPatchOutubro;

    private String minutosPosPatchNovembro;

    private String minutosPosPatchDezembro;

    private String consolidadoMinutosPosPatchMensal;

    private String percentualPosPatchJaneiro;

    private String percentualPosPatchFevereiro;

    private String percentualPosPatchMarco;

    private String percentualPosPatchAbril;

    private String percentualPosPatchMaio;

    private String percentualPosPatchJunho;

    private String percentualPosPatchJulho;

    private String percentualPosPatchAgosto;

    private String percentualPosPatchSetembro;

    private String percentualPosPatchOutubro;

    private String percentualPosPatchNovembro;

    private String percentualPosPatchDezembro;

    private String consolidadoPercentualPosPatchMensal;

    private Integer inicio;

    private Integer fim;

    public IndisponibilidadeAplicacaoMensalBean() {
        // Construtor padrão
    }

    public IndisponibilidadeAplicacaoMensalBean(Long id, String aplicacao, String minutosJaneiro, String minutosFevereiro, String minutosMarco,
            String minutosAbril, String minutosMaio, String minutosJunho, String minutosJulho, String minutosAgosto, String minutosSetembro,
            String minutosOutubro, String minutosNovembro, String minutosDezembro) {

        this.id = id;
        this.minutosJaneiro = minutosJaneiro;
        this.minutosFevereiro = minutosFevereiro;
        this.minutosMarco = minutosMarco;
        this.minutosAbril = minutosAbril;
        this.minutosMaio = minutosMaio;
        this.minutosJunho = minutosJunho;
        this.minutosJulho = minutosJulho;
        this.minutosAgosto = minutosAgosto;
        this.minutosSetembro = minutosSetembro;
        this.minutosOutubro = minutosOutubro;
        this.minutosNovembro = minutosNovembro;
        this.minutosDezembro = minutosDezembro;
        this.aplicacao = aplicacao;
    }

    public IndisponibilidadeAplicacaoMensalBean(Integer inicio, Integer fim) {
        this.inicio = inicio;
        this.fim = fim;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMinutosJaneiro() {
        return minutosJaneiro;
    }

    public void setMinutosJaneiro(String minutosJaneiro) {
        this.minutosJaneiro = minutosJaneiro;
    }

    public String getMinutosFevereiro() {
        return minutosFevereiro;
    }

    public void setMinutosFevereiro(String minutosFevereiro) {
        this.minutosFevereiro = minutosFevereiro;
    }

    public String getMinutosMarco() {
        return minutosMarco;
    }

    public void setMinutosMarco(String minutosMarco) {
        this.minutosMarco = minutosMarco;
    }

    public String getMinutosAbril() {
        return minutosAbril;
    }

    public void setMinutosAbril(String minutosAbril) {
        this.minutosAbril = minutosAbril;
    }

    public String getMinutosMaio() {
        return minutosMaio;
    }

    public void setMinutosMaio(String minutosMaio) {
        this.minutosMaio = minutosMaio;
    }

    public String getMinutosJunho() {
        return minutosJunho;
    }

    public void setMinutosJunho(String minutosJunho) {
        this.minutosJunho = minutosJunho;
    }

    public String getMinutosJulho() {
        return minutosJulho;
    }

    public void setMinutosJulho(String minutosJulho) {
        this.minutosJulho = minutosJulho;
    }

    public String getMinutosAgosto() {
        return minutosAgosto;
    }

    public void setMinutosAgosto(String minutosAgosto) {
        this.minutosAgosto = minutosAgosto;
    }

    public String getMinutosSetembro() {
        return minutosSetembro;
    }

    public void setMinutosSetembro(String minutosSetembro) {
        this.minutosSetembro = minutosSetembro;
    }

    public String getMinutosOutubro() {
        return minutosOutubro;
    }

    public void setMinutosOutubro(String minutosOutubro) {
        this.minutosOutubro = minutosOutubro;
    }

    public String getMinutosNovembro() {
        return minutosNovembro;
    }

    public void setMinutosNovembro(String minutosNovembro) {
        this.minutosNovembro = minutosNovembro;
    }

    public String getMinutosDezembro() {
        return minutosDezembro;
    }

    public void setMinutosDezembro(String minutosDezembro) {
        this.minutosDezembro = minutosDezembro;
    }

    public String getConsolidadoMinutosMensal() {
        return consolidadoMinutosMensal;
    }

    public void setConsolidadoMinutosMensal(String consolidadoMinutosMensal) {
        this.consolidadoMinutosMensal = consolidadoMinutosMensal;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

    public String getPercentualJaneiro() {
        return percentualJaneiro;
    }

    public void setPercentualJaneiro(String percentualJaneiro) {
        this.percentualJaneiro = percentualJaneiro;
    }

    public String getPercentualFevereiro() {
        return percentualFevereiro;
    }

    public void setPercentualFevereiro(String percentualFevereiro) {
        this.percentualFevereiro = percentualFevereiro;
    }

    public String getPercentualMarco() {
        return percentualMarco;
    }

    public void setPercentualMarco(String percentualMarco) {
        this.percentualMarco = percentualMarco;
    }

    public String getPercentualAbril() {
        return percentualAbril;
    }

    public void setPercentualAbril(String percentualAbril) {
        this.percentualAbril = percentualAbril;
    }

    public String getPercentualMaio() {
        return percentualMaio;
    }

    public void setPercentualMaio(String percentualMaio) {
        this.percentualMaio = percentualMaio;
    }

    public String getPercentualJunho() {
        return percentualJunho;
    }

    public void setPercentualJunho(String percentualJunho) {
        this.percentualJunho = percentualJunho;
    }

    public String getPercentualJulho() {
        return percentualJulho;
    }

    public void setPercentualJulho(String percentualJulho) {
        this.percentualJulho = percentualJulho;
    }

    public String getPercentualAgosto() {
        return percentualAgosto;
    }

    public void setPercentualAgosto(String percentualAgosto) {
        this.percentualAgosto = percentualAgosto;
    }

    public String getPercentualSetembro() {
        return percentualSetembro;
    }

    public void setPercentualSetembro(String percentualSetembro) {
        this.percentualSetembro = percentualSetembro;
    }

    public String getPercentualOutubro() {
        return percentualOutubro;
    }

    public void setPercentualOutubro(String percentualOutubro) {
        this.percentualOutubro = percentualOutubro;
    }

    public String getPercentualNovembro() {
        return percentualNovembro;
    }

    public void setPercentualNovembro(String percentualNovembro) {
        this.percentualNovembro = percentualNovembro;
    }

    public String getPercentualDezembro() {
        return percentualDezembro;
    }

    public void setPercentualDezembro(String percentualDezembro) {
        this.percentualDezembro = percentualDezembro;
    }

    public String getConsolidadoPercentualMensal() {
        return consolidadoPercentualMensal;
    }

    public void setConsolidadoPercentualMensal(String consolidadoPercentualMensal) {
        this.consolidadoPercentualMensal = consolidadoPercentualMensal;
    }

    public String getMinutosPosPatchJaneiro() {
        return minutosPosPatchJaneiro;
    }

    public void setMinutosPosPatchJaneiro(String minutosPosPatchJaneiro) {
        this.minutosPosPatchJaneiro = minutosPosPatchJaneiro;
    }

    public String getMinutosPosPatchFevereiro() {
        return minutosPosPatchFevereiro;
    }

    public void setMinutosPosPatchFevereiro(String minutosPosPatchFevereiro) {
        this.minutosPosPatchFevereiro = minutosPosPatchFevereiro;
    }

    public String getMinutosPosPatchMarco() {
        return minutosPosPatchMarco;
    }

    public void setMinutosPosPatchMarco(String minutosPosPatchMarco) {
        this.minutosPosPatchMarco = minutosPosPatchMarco;
    }

    public String getMinutosPosPatchAbril() {
        return minutosPosPatchAbril;
    }

    public void setMinutosPosPatchAbril(String minutosPosPatchAbril) {
        this.minutosPosPatchAbril = minutosPosPatchAbril;
    }

    public String getMinutosPosPatchMaio() {
        return minutosPosPatchMaio;
    }

    public void setMinutosPosPatchMaio(String minutosPosPatchMaio) {
        this.minutosPosPatchMaio = minutosPosPatchMaio;
    }

    public String getMinutosPosPatchJunho() {
        return minutosPosPatchJunho;
    }

    public void setMinutosPosPatchJunho(String minutosPosPatchJunho) {
        this.minutosPosPatchJunho = minutosPosPatchJunho;
    }

    public String getMinutosPosPatchJulho() {
        return minutosPosPatchJulho;
    }

    public void setMinutosPosPatchJulho(String minutosPosPatchJulho) {
        this.minutosPosPatchJulho = minutosPosPatchJulho;
    }

    public String getMinutosPosPatchAgosto() {
        return minutosPosPatchAgosto;
    }

    public void setMinutosPosPatchAgosto(String minutosPosPatchAgosto) {
        this.minutosPosPatchAgosto = minutosPosPatchAgosto;
    }

    public String getMinutosPosPatchSetembro() {
        return minutosPosPatchSetembro;
    }

    public void setMinutosPosPatchSetembro(String minutosPosPatchSetembro) {
        this.minutosPosPatchSetembro = minutosPosPatchSetembro;
    }

    public String getMinutosPosPatchOutubro() {
        return minutosPosPatchOutubro;
    }

    public void setMinutosPosPatchOutubro(String minutosPosPatchOutubro) {
        this.minutosPosPatchOutubro = minutosPosPatchOutubro;
    }

    public String getMinutosPosPatchNovembro() {
        return minutosPosPatchNovembro;
    }

    public void setMinutosPosPatchNovembro(String minutosPosPatchNovembro) {
        this.minutosPosPatchNovembro = minutosPosPatchNovembro;
    }

    public String getMinutosPosPatchDezembro() {
        return minutosPosPatchDezembro;
    }

    public void setMinutosPosPatchDezembro(String minutosPosPatchDezembro) {
        this.minutosPosPatchDezembro = minutosPosPatchDezembro;
    }

    public String getConsolidadoMinutosPosPatchMensal() {
        return consolidadoMinutosPosPatchMensal;
    }

    public void setConsolidadoMinutosPosPatchMensal(String consolidadoMinutosPosPatchMensal) {
        this.consolidadoMinutosPosPatchMensal = consolidadoMinutosPosPatchMensal;
    }

    public String getPercentualPosPatchJaneiro() {
        return percentualPosPatchJaneiro;
    }

    public void setPercentualPosPatchJaneiro(String percentualPosPatchJaneiro) {
        this.percentualPosPatchJaneiro = percentualPosPatchJaneiro;
    }

    public String getPercentualPosPatchFevereiro() {
        return percentualPosPatchFevereiro;
    }

    public void setPercentualPosPatchFevereiro(String percentualPosPatchFevereiro) {
        this.percentualPosPatchFevereiro = percentualPosPatchFevereiro;
    }

    public String getPercentualPosPatchMarco() {
        return percentualPosPatchMarco;
    }

    public void setPercentualPosPatchMarco(String percentualPosPatchMarco) {
        this.percentualPosPatchMarco = percentualPosPatchMarco;
    }

    public String getPercentualPosPatchAbril() {
        return percentualPosPatchAbril;
    }

    public void setPercentualPosPatchAbril(String percentualPosPatchAbril) {
        this.percentualPosPatchAbril = percentualPosPatchAbril;
    }

    public String getPercentualPosPatchMaio() {
        return percentualPosPatchMaio;
    }

    public void setPercentualPosPatchMaio(String percentualPosPatchMaio) {
        this.percentualPosPatchMaio = percentualPosPatchMaio;
    }

    public String getPercentualPosPatchJunho() {
        return percentualPosPatchJunho;
    }

    public void setPercentualPosPatchJunho(String percentualPosPatchJunho) {
        this.percentualPosPatchJunho = percentualPosPatchJunho;
    }

    public String getPercentualPosPatchJulho() {
        return percentualPosPatchJulho;
    }

    public void setPercentualPosPatchJulho(String percentualPosPatchJulho) {
        this.percentualPosPatchJulho = percentualPosPatchJulho;
    }

    public String getPercentualPosPatchAgosto() {
        return percentualPosPatchAgosto;
    }

    public void setPercentualPosPatchAgosto(String percentualPosPatchAgosto) {
        this.percentualPosPatchAgosto = percentualPosPatchAgosto;
    }

    public String getPercentualPosPatchSetembro() {
        return percentualPosPatchSetembro;
    }

    public void setPercentualPosPatchSetembro(String percentualPosPatchSetembro) {
        this.percentualPosPatchSetembro = percentualPosPatchSetembro;
    }

    public String getPercentualPosPatchOutubro() {
        return percentualPosPatchOutubro;
    }

    public void setPercentualPosPatchOutubro(String percentualPosPatchOutubro) {
        this.percentualPosPatchOutubro = percentualPosPatchOutubro;
    }

    public String getPercentualPosPatchNovembro() {
        return percentualPosPatchNovembro;
    }

    public void setPercentualPosPatchNovembro(String percentualPosPatchNovembro) {
        this.percentualPosPatchNovembro = percentualPosPatchNovembro;
    }

    public String getPercentualPosPatchDezembro() {
        return percentualPosPatchDezembro;
    }

    public void setPercentualPosPatchDezembro(String percentualPosPatchDezembro) {
        this.percentualPosPatchDezembro = percentualPosPatchDezembro;
    }

    public String getConsolidadoPercentualPosPatchMensal() {
        return consolidadoPercentualPosPatchMensal;
    }

    public void setConsolidadoPercentualPosPatchMensal(String consolidadoPercentualPosPatchMensal) {
        this.consolidadoPercentualPosPatchMensal = consolidadoPercentualPosPatchMensal;
    }

    public Integer getInicio() {
        return inicio;
    }

    public void setInicio(Integer inicio) {
        this.inicio = inicio;
    }

    public Integer getFim() {
        return fim;
    }

    public void setFim(Integer fim) {
        this.fim = fim;
    }

}