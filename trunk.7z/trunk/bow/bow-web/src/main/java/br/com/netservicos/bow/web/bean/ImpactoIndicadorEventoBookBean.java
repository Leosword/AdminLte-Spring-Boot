package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class ImpactoIndicadorEventoBookBean implements Serializable {

    private static final long serialVersionUID = -4726969706986187097L;

    private Long id;

    private String base;

    private String operacao;

    private String cidade;

    private String regional;

    private Integer minutos;

    private String inicio;

    private String fim;

    public ImpactoIndicadorEventoBookBean() {
        // Construtor padrão
    }

    public ImpactoIndicadorEventoBookBean(Long id, String base, String operacao, String cidade, String regional, Integer minutos, String inicio,
            String fim) {
        this.id = id;
        this.base = base;
        this.operacao = operacao;
        this.cidade = cidade;
        this.regional = regional;
        this.minutos = minutos;
        this.inicio = inicio;
        this.fim = fim;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getRegional() {
        return regional;
    }

    public void setRegional(String regional) {
        this.regional = regional;
    }

    public Integer getMinutos() {
        return minutos;
    }

    public void setMinutos(Integer minutos) {
        this.minutos = minutos;
    }

    public String getInicio() {
        return inicio;
    }

    public void setInicio(String inicio) {
        this.inicio = inicio;
    }

    public String getFim() {
        return fim;
    }

    public void setFim(String fim) {
        this.fim = fim;
    }

}
