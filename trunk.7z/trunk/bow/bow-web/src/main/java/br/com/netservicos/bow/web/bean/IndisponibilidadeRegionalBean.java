package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class IndisponibilidadeRegionalBean implements Serializable {

    private static final long serialVersionUID = 8653410899103706355L;

    private String regional;

    private String minutosSUL;

    private String minutosPRSC;

    private String minutosSP;

    private String minutosSPI;

    private String minutosRJ;

    private String minutosMG;

    private String minutosCO;

    private String minutosNE;

    private String minutosBASE;

    private String minutosNO;

    private String percentualSUL;

    private String percentualPRSC;

    private String percentualSP;

    private String percentualSPI;

    private String percentualRJ;

    private String percentualMG;

    private String percentualCO;

    private String percentualNE;

    private String percentualBASE;

    private String percentualNO;

    private String aplicacao;

    public IndisponibilidadeRegionalBean() {
        // Construtor padrão
    }

    public String getRegional() {
        return regional;
    }

    public void setRegional(String regional) {
        this.regional = regional;
    }

    public String getMinutosSUL() {
        return minutosSUL;
    }

    public void setMinutosSUL(String minutosSUL) {
        this.minutosSUL = minutosSUL;
    }

    public String getMinutosPRSC() {
        return minutosPRSC;
    }

    public void setMinutosPRSC(String minutosPRSC) {
        this.minutosPRSC = minutosPRSC;
    }

    public String getMinutosSP() {
        return minutosSP;
    }

    public void setMinutosSP(String minutosSP) {
        this.minutosSP = minutosSP;
    }

    public String getMinutosSPI() {
        return minutosSPI;
    }

    public void setMinutosSPI(String minutosSPI) {
        this.minutosSPI = minutosSPI;
    }

    public String getMinutosRJ() {
        return minutosRJ;
    }

    public void setMinutosRJ(String minutosRJ) {
        this.minutosRJ = minutosRJ;
    }

    public String getMinutosMG() {
        return minutosMG;
    }

    public void setMinutosMG(String minutosMG) {
        this.minutosMG = minutosMG;
    }

    public String getMinutosCO() {
        return minutosCO;
    }

    public void setMinutosCO(String minutosCO) {
        this.minutosCO = minutosCO;
    }

    public String getMinutosNE() {
        return minutosNE;
    }

    public void setMinutosNE(String minutosNE) {
        this.minutosNE = minutosNE;
    }

    public String getMinutosBASE() {
        return minutosBASE;
    }

    public void setMinutosBASE(String minutosBASE) {
        this.minutosBASE = minutosBASE;
    }

    public String getMinutosNO() {
        return minutosNO;
    }

    public void setMinutosNO(String minutosNO) {
        this.minutosNO = minutosNO;
    }

    public String getPercentualSUL() {
        return percentualSUL;
    }

    public void setPercentualSUL(String percentualSUL) {
        this.percentualSUL = percentualSUL;
    }

    public String getPercentualPRSC() {
        return percentualPRSC;
    }

    public void setPercentualPRSC(String percentualPRSC) {
        this.percentualPRSC = percentualPRSC;
    }

    public String getPercentualSP() {
        return percentualSP;
    }

    public void setPercentualSP(String percentualSP) {
        this.percentualSP = percentualSP;
    }

    public String getPercentualSPI() {
        return percentualSPI;
    }

    public void setPercentualSPI(String percentualSPI) {
        this.percentualSPI = percentualSPI;
    }

    public String getPercentualRJ() {
        return percentualRJ;
    }

    public void setPercentualRJ(String percentualRJ) {
        this.percentualRJ = percentualRJ;
    }

    public String getPercentualMG() {
        return percentualMG;
    }

    public void setPercentualMG(String percentualMG) {
        this.percentualMG = percentualMG;
    }

    public String getPercentualCO() {
        return percentualCO;
    }

    public void setPercentualCO(String percentualCO) {
        this.percentualCO = percentualCO;
    }

    public String getPercentualNE() {
        return percentualNE;
    }

    public void setPercentualNE(String percentualNE) {
        this.percentualNE = percentualNE;
    }

    public String getPercentualBASE() {
        return percentualBASE;
    }

    public void setPercentualBASE(String percentualBASE) {
        this.percentualBASE = percentualBASE;
    }

    public String getPercentualNO() {
        return percentualNO;
    }

    public void setPercentualNO(String percentualNO) {
        this.percentualNO = percentualNO;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

}