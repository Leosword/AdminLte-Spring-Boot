package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class BaseAplicacaoOperacaoBean implements Serializable {

    private static final long serialVersionUID = -7104501377107051931L;

    private Long id;

    private Long baseAplicacaoId;

    private Long estadoId;

    private Long[] operacaoIds;

    private String nomeCompleto;

    private String nomeOperacao;

    public BaseAplicacaoOperacaoBean() {
        // Construtor padrão
    }

    public BaseAplicacaoOperacaoBean(Long id, String nomeCompleto) {
        this.id = id;
        this.nomeCompleto = nomeCompleto;
    }

    public BaseAplicacaoOperacaoBean(Long id, String nomeCompleto, String nomeOperacao) {
        this.id = id;
        this.nomeCompleto = nomeCompleto;
        this.nomeOperacao = nomeOperacao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBaseAplicacaoId() {
        return baseAplicacaoId;
    }

    public void setBaseAplicacaoId(Long baseAplicacaoId) {
        this.baseAplicacaoId = baseAplicacaoId;
    }

    public Long getEstadoId() {
        return estadoId;
    }

    public void setEstadoId(Long estadoId) {
        this.estadoId = estadoId;
    }

    public Long[] getOperacaoIds() {
        return operacaoIds;
    }

    public void setOperacaoIds(Long[] operacaoIds) {
        this.operacaoIds = operacaoIds;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getNomeOperacao() {
        return nomeOperacao;
    }

    public void setNomeOperacao(String nomeOperacao) {
        this.nomeOperacao = nomeOperacao;
    }

}
