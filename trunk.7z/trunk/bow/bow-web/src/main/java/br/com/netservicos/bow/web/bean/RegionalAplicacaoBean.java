package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class RegionalAplicacaoBean implements Serializable {

    private static final long serialVersionUID = 3676857884709872797L;

    private Long id;

    private String nomeCompleto;

    public RegionalAplicacaoBean() {
        // Construtor padrão
    }

    public RegionalAplicacaoBean(Long id, String nomeCompleto) {
        this.id = id;
        this.nomeCompleto = nomeCompleto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

}
