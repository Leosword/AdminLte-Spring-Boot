package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoCidade;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.service.AplicacaoCidadeService;
import br.com.netservicos.bow.web.bean.AplicacaoCidadeBean;
import br.com.netservicos.bow.web.constants.ControllerConstants;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = AplicacaoCidadeController.REQUEST_MAPPING_PAGE)
public class AplicacaoCidadeController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AplicacaoCidadeController.class);

    private static final String SEPARATOR_EMPTY = "";

    private static final String SEPARATOR_NAME = " - ";

    private static final String MODEL_NAME = "aplicacaoCidadeBean";

    private static final String ACTION_SALVAR = "/aplicacao-cidade/salvar";

    private static final String REDIRECT_PAGE_INCLUIR = "/incluir";

    private static final String REDIRECT_PAGE_SALVAR = "/salvar";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR = "aplicacaocidade/incluiraplicacaocidade";

    private static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "aplicacaocidade/pesquisaraplicacaocidade";

    protected static final String REQUEST_MAPPING_PAGE = "/aplicacao-cidade";

    @Autowired
    private AplicacaoCidadeService aplicacaoCidadeService;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AplicacaoCidadeBean>> carregar() {

        LOGGER.debug("Iniciando o carregamento das aplicações que contém base.");

        List<AplicacaoCidade> aplicacoes = aplicacaoCidadeService.findFecthAll();

        if (aplicacoes.isEmpty()) {

            return new ResponseEntity<List<AplicacaoCidadeBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<AplicacaoCidadeBean> aplicacoesCidadeBean = new ArrayList<>();

        aplicacoes.forEach(aplicacaoCidade -> {

            BaseAplicacao baseAplicacao = aplicacaoCidade.getBaseAplicacao();

            Aplicacao aplicacao = baseAplicacao.getAplicacao();

            String nomeCompleto = String.join(SEPARATOR_NAME, aplicacao.getDescricao(), aplicacao.getEmpresa().getDescricao(),
                    baseAplicacao.getBase().getNome());

            AplicacaoCidadeBean aplicacaoCidadeBean = new AplicacaoCidadeBean(aplicacaoCidade.getId(), nomeCompleto,
                    aplicacaoCidade.getCidade().getNome());

            aplicacoesCidadeBean.add(aplicacaoCidadeBean);
        });

        return new ResponseEntity<List<AplicacaoCidadeBean>>(aplicacoesCidadeBean, HttpStatus.OK);
    }

    @RequestMapping(value = REDIRECT_PAGE_INCLUIR, method = RequestMethod.GET)
    public ModelAndView viewIncluir(ModelMap model, HttpServletRequest request) {

        model.addAttribute(MODEL_NAME, new AplicacaoCidadeBean());

        model.addAttribute(ControllerConstants.METHOD_NAME, RequestMethod.POST.name());

        String action = String.join(SEPARATOR_EMPTY, request.getContextPath(), ACTION_SALVAR);

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = REDIRECT_PAGE_SALVAR, method = RequestMethod.POST)
    public ResponseEntity<ValidationResponse> salvar(@Valid @RequestBody AplicacaoCidadeBean aplicacaoCidadeBean) {

        aplicacaoCidadeService.salvar(aplicacaoCidadeBean.getBaseAplicacaoId(), aplicacaoCidadeBean.getCidadeIds());

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @RequestMapping(value = "/remover/{ids}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> deletar(@PathVariable("ids") Long[] ids) {

        LOGGER.debug("Aplicação cidade a serem removidos: {}", new Object[] { ids });

        aplicacaoCidadeService.deletar(ids);

        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(BusinessException.class)
    public String handleBusinessExceptionException(BusinessException exception) {

        ModelAndView model = new ModelAndView();

        model.addObject("exception", exception.getMessage());

        model.setViewName(REQUEST_MAPPING_PAGE_INCLUIR);

        return exception.getMessage();
    }

}