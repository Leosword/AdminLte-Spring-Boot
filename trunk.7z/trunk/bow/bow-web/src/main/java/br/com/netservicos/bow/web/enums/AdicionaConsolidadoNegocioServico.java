package br.com.netservicos.bow.web.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.web.bean.ConsolidadoNegocioEmpresaBean;

public enum AdicionaConsolidadoNegocioServico {

    VENDER("VENDER") {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioEmpresaBean bean) {

            bean.setMinutosVender(String.valueOf(minutos.getMinutos()));
            bean.setPercentualVender(String.valueOf(minutos.getPercentual()));
        }
    },
    ATIVAR("ATIVAR") {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioEmpresaBean bean) {

            bean.setMinutosAtivar(String.valueOf(minutos.getMinutos()));
            bean.setPercentualAtivar(String.valueOf(minutos.getPercentual()));

        }
    },
    ATENDER("ATENDER") {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioEmpresaBean bean) {

            bean.setMinutosAtender(String.valueOf(minutos.getMinutos()));
            bean.setPercentualAtender(String.valueOf(minutos.getPercentual()));
        }

    },
    FATURAR("FATURAR") {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioEmpresaBean bean) {

            bean.setMinutosFaturar(String.valueOf(minutos.getMinutos()));
            bean.setPercentualFaturar(String.valueOf(minutos.getPercentual()));
        }

    },
    ARRECADAR("ARRECADAR") {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioEmpresaBean bean) {

            bean.setMinutosArrecadar(String.valueOf(minutos.getMinutos()));
            bean.setPercentualArrecadar(String.valueOf(minutos.getPercentual()));
        }

    },
    CONTABILIZAR("CONTABILIZAR") {

        @Override
        public void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioEmpresaBean bean) {

            bean.setMinutosContabilizar(String.valueOf(minutos.getMinutos()));
            bean.setPercentualContabilizar(String.valueOf(minutos.getPercentual()));
        }

    };

    protected static final Map<String, AdicionaConsolidadoNegocioServico> values = new HashMap<>();

    private String value;

    static {
        values.putAll(Arrays.asList(values()).stream().collect(Collectors.toMap(AdicionaConsolidadoNegocioServico::getValue, Function.identity())));
    }

    private AdicionaConsolidadoNegocioServico(String value) {
        this.value = value;
    }

    public static AdicionaConsolidadoNegocioServico getObject(final String identificador) {
        return values.get(identificador);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public abstract void adiciona(MinutosIndisponibilidade minutos, ConsolidadoNegocioEmpresaBean bean);
}
