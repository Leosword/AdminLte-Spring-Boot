package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Multimap;
import com.google.gson.Gson;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.DateUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.enums.TipoNivelServico;
import br.com.netservicos.bow.service.AplicacaoBookService;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.IndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.ParametroService;
import br.com.netservicos.bow.service.collector.MultimapCollector;
import br.com.netservicos.bow.web.bean.DashboardIndisponibilidadeMensalBean;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;
import br.com.netservicos.bow.web.enums.Meses;

@RestController
public class DashboardIndisponibilidadeMensalController {

    private static final String REQUEST_MAPPING_PAGE = "/indisponibilidade-mensal/dashboard";

    private static final String REQUEST_MAPPING_PAGE_SERVICO = "/indisponibilidade-mensal/dashboard/carregar-nivelservico";

    private static final String EMPTY_VALUE = "";

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardIndisponibilidadeMensalController.class);

    private static final List<Integer> MESES = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    @Autowired
    private AplicacaoBookService aplicacaoBookService;

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    @Autowired
    private ParametroService parametroService;

    @Autowired
    private IndisponibilidadeAplicacaoMensalService indisponibilidadeAplicacaoMensalService;

    @RequestMapping(value = REQUEST_MAPPING_PAGE, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> dashboard(IndisponibilidadeQueryParameterBean parameter) {

        TipoNivelServico nivelServico = TipoNivelServico.getTipoNivelServico(parameter.getTipo());

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipoComSla(nivelServico, parameter.getEmpresa(),
                parameter.getTipoAplicacao());

        if (CollectionUtil.isEmpty(aplicacoesBook)) {

            LOGGER.error("Não foi possível localizar as aplicações que compõe o book");

            return new ResponseEntity<String>(EMPTY_VALUE, HttpStatus.OK);
        }

        List<DashboardIndisponibilidadeMensalBean> dashboards = carregar(aplicacoesBook);

        return new ResponseEntity<String>(new Gson().toJson(dashboards), HttpStatus.OK);
    }

    @RequestMapping(value = REQUEST_MAPPING_PAGE_SERVICO, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> dashboardNivelServico(IndisponibilidadeQueryParameterBean parameter) {

        TipoNivelServico nivelServico = TipoNivelServico.getTipoNivelServico(parameter.getTipo());

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipoComSla(nivelServico);

        if (CollectionUtil.isEmpty(aplicacoesBook)) {

            LOGGER.error("Não foi possível localizar as aplicações que compõe o book");

            return new ResponseEntity<String>(EMPTY_VALUE, HttpStatus.OK);
        }

        List<DashboardIndisponibilidadeMensalBean> dashboards = carregar(aplicacoesBook);

        return new ResponseEntity<String>(new Gson().toJson(dashboards), HttpStatus.OK);
    }

    private List<DashboardIndisponibilidadeMensalBean> carregar(List<AplicacaoBook> aplicacoesBook) {

        List<Aplicacao> aplicacoes = aplicacoesBook.stream().map(AplicacaoBook::getAplicacao).collect(Collectors.toList());

        Integer fim = DateUtil.getYear(new Date());

        Integer inicio = fim - NumberUtil.INTEGER_ONE;

        Parametro parametroSla = parametroService.findByNome(ParametroConstants.VALOR_SLA);

        Parametro parametroBH = parametroService.findByNome(ParametroConstants.BUSINESS_HOURS);

        List<IndisponibilidadeAplicacaoMensal> indisponibilidades = indisponibilidadeAplicacaoMensalService.findByPeriodoAno(inicio, fim, aplicacoes);

        List<DashboardIndisponibilidadeMensalBean> dashboards = new ArrayList<>();

        MESES.forEach(mes -> {

            DashboardIndisponibilidadeMensalBean dashboard = new DashboardIndisponibilidadeMensalBean();

            dashboard.setMes(Meses.getObject(mes).getLabel());

            List<IndisponibilidadeAplicacaoMensal> indisponibilidadesMes = indisponibilidades.stream()
                    .filter(indisponibilidade -> DateUtil.getMonth(indisponibilidade.getCriacao()).equals(mes)).collect(Collectors.toList());

            Multimap<Integer, IndisponibilidadeAplicacaoMensal> indisponibilidadesAno = indisponibilidadesMes.stream()
                    .collect(MultimapCollector.toMultimap((IndisponibilidadeAplicacaoMensal v) -> DateUtil.getYear(v.getCriacao())));

            indisponibilidadesAno.asMap().keySet().iterator().forEachRemaining(ano -> {

                Collection<IndisponibilidadeAplicacaoMensal> indiponibilidadesMensalAno = indisponibilidadesAno.get(ano);

                BigDecimal minutos = calculaMinutos(aplicacoesBook, indiponibilidadesMensalAno);

                BigDecimal minutosPosPatch = calculaMinutosPosPatch(aplicacoesBook, indiponibilidadesMensalAno);

                if (ano.equals(inicio)) {

                    dashboard.setAnterior(minutos);

                } else {

                    dashboard.setPosPatch(minutosPosPatch);

                    dashboard.setAtual(minutos);
                }
            });

            LocalDate data = LocalDate.of(fim, mes, NumberUtil.INTEGER_ONE);

            Month month = data.getMonth();

            BigDecimal sla = calculaIndisponibilidadeService.calculaMinutosBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                    month.maxLength());

            dashboard.setSla(sla);

            dashboards.add(dashboard);
        });

        return dashboards;
    }

    private BigDecimal calculaMinutos(List<AplicacaoBook> aplicacoes, Collection<IndisponibilidadeAplicacaoMensal> indiponibilidades) {

        BigDecimal totalMinutos = indiponibilidades.stream().filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getTotalMinutos()))
                .map(indisponibilidade -> indisponibilidade.getTotalMinutos()).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal resultado = totalMinutos.divide(new BigDecimal(aplicacoes.size()), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO,
                RoundingMode.HALF_EVEN);

        return converter.convert(resultado);
    }

    private BigDecimal calculaMinutosPosPatch(List<AplicacaoBook> aplicacoes, Collection<IndisponibilidadeAplicacaoMensal> indisponibilidades) {

        BigDecimal totalMinutos = indisponibilidades.stream()
                .filter(indisponibilidade -> Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch()))
                .map(indisponibilidade -> indisponibilidade.getTotalMinutosPosPatch()).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal resultado = totalMinutos.divide(new BigDecimal(aplicacoes.size()), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO,
                RoundingMode.HALF_EVEN);

        return converter.convert(resultado);
    }
}
