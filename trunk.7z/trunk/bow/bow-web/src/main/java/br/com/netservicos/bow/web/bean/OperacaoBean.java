package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.util.StringUtils;

import com.google.gson.Gson;

import br.com.netservicos.bow.model.Cidade;
import br.com.netservicos.bow.model.Endereco;
import br.com.netservicos.bow.model.Estado;
import br.com.netservicos.bow.model.Operacao;

public class OperacaoBean implements Serializable {

    private static final long serialVersionUID = -6977631556488219960L;

    private Long id;

    private Long[] aplicacoes;

    private Long[] bases;

    private String complemento;

    private String logradouro;

    private String numero;

    private String bairro;

    private String cep;

    private boolean endereco = false;

    private String cidade;

    private String estado;

    private Long cidadeId;

    @NotBlank
    private String nome;

    public OperacaoBean() {
        // Construtor Padrão
    }

    public OperacaoBean(Long id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public OperacaoBean(String nome) {
        this.nome = nome;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long[] getAplicacoes() {
        return aplicacoes;
    }

    public void setAplicacoes(Long[] aplicacoes) {
        this.aplicacoes = aplicacoes;
    }

    public Long[] getBases() {
        return bases;
    }

    public void setBases(Long[] bases) {
        this.bases = bases;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public boolean getEndereco() {
        return endereco;
    }

    public void setEndereco(boolean endereco) {
        this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getCidadeId() {
        return cidadeId;
    }

    public void setCidadeId(Long cidadeId) {
        this.cidadeId = cidadeId;
    }

    public String getCidade() {
        return cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    private boolean habilitaCampoEndereco(Operacao operacao) {

        Endereco endereco = operacao.getEndereco();

        boolean existeEndereco = !StringUtils.isEmpty(endereco.getBairro()) || !StringUtils.isEmpty(endereco.getComplemento())
                || !StringUtils.isEmpty(endereco.getLogradouro()) || !StringUtils.isEmpty(endereco.getNumero());

        boolean existeCidade = operacao.getCidade() != null;

        return existeEndereco || existeCidade;
    }

    public static OperacaoBean bindPropertes(Operacao operacao) {

        OperacaoBean operacaoBean = new OperacaoBean(operacao.getId(), operacao.getNome());

        if (operacao.getEndereco() != null) {

            operacaoBean.setBairro(operacao.getEndereco().getBairro());

            operacaoBean.setComplemento(operacao.getEndereco().getComplemento());

            operacaoBean.setCep(operacao.getEndereco().getCep());

            operacaoBean.setNumero(operacao.getEndereco().getNumero());

            operacaoBean.setLogradouro(operacao.getEndereco().getLogradouro());

            if (operacao.getCidade() != null) {

                Cidade cidade = new Cidade(operacao.getCidade().getId(), operacao.getCidade().getNome());

                Gson gson = new Gson();

                operacaoBean.setCidade(gson.toJson(cidade));

                Estado estado = new Estado(operacao.getCidade().getEstado().getId(), operacao.getCidade().getEstado().getNome());

                operacaoBean.setEstado(gson.toJson(estado));
            }

            if (operacaoBean.habilitaCampoEndereco(operacao)) {

                operacaoBean.setEndereco(true);
            }
        }

        return operacaoBean;
    }

}
