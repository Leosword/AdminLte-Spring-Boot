package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.model.Base;
import br.com.netservicos.bow.model.Operacao;
import br.com.netservicos.bow.model.OperacaoBase;
import br.com.netservicos.bow.service.OperacaoBaseService;
import br.com.netservicos.bow.service.OperacaoService;
import br.com.netservicos.bow.service.PaggableSelect;

@RestController
@RequestMapping(value = OperacaoController.REQUEST_MAPPING_PAGE)
public class OperacaoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(OperacaoController.class);

    private static final String TODAS_NENHUMA = "TODAS OU NENHUMA";

    private static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REDIRECT_PAGE_CARREGAR = "/carregar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "operacao/pesquisaroperacao";

    protected static final String REQUEST_MAPPING_PAGE = "/operacao";

    @Autowired
    private OperacaoService operacaoService;

    @Autowired
    private OperacaoBaseService operacaoBaseService;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = OperacaoController.REDIRECT_PAGE_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Operacao>> carregar() {

        LOGGER.debug("Iniciando o carregamento das operações");

        List<Operacao> operacoes = operacaoService.findAllAtivas();

        if (CollectionUtil.isEmpty(operacoes)) {

            return new ResponseEntity<List<Operacao>>(operacoes, HttpStatus.OK);
        }

        List<Operacao> operacoesValidas = operacoes.stream().filter(operacao -> !TODAS_NENHUMA.equals(operacao.getNome()))
                .collect(Collectors.toList());

        return new ResponseEntity<List<Operacao>>(operacoesValidas, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarComPaginacao", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Operacao>> carregar(PaggableSelect paggable) {

        LOGGER.debug("Iniciando o carregamento das operações com paginação");

        List<Operacao> operacoes = operacaoService.findByPaggebleSelect(paggable);

        if (operacoes.isEmpty()) {

            LOGGER.debug("Não foi possível localizar a operação com pagina: {}", paggable);

            return new ResponseEntity<List<Operacao>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Operacao>>(operacoes, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarBasePorOperacao", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Base>> carregarBase(Long operacaoId) {

        List<OperacaoBase> operacaoBases = operacaoBaseService.findByAplicacoes(operacaoId);

        if (operacaoBases.isEmpty()) {

            return new ResponseEntity<List<Base>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<Base> bases = operacaoBases.stream().map(operacaoBase -> new Base(operacaoBase.getBase().getId(), operacaoBase.getBase().getNome()))
                .collect(Collectors.toList());

        return new ResponseEntity<List<Base>>(bases, HttpStatus.OK);
    }

}
