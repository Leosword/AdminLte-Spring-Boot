package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class ServicoBean implements Serializable {

    private static final long serialVersionUID = -5087279668149129284L;

    private Long id;

    private Long[] aplicacoes;

    @NotBlank
    private String nome;

    @NotBlank
    private String descricao;

    public ServicoBean() {
        // Construtor Padrão
    }

    public ServicoBean(Long id, String nome, String descricao) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
    }

    public ServicoBean(String nome, String descricao) {
        this.nome = nome;
        this.descricao = descricao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long[] getAplicacoes() {
        return aplicacoes;
    }

    public void setAplicacoes(Long[] aplicacoes) {
        this.aplicacoes = aplicacoes;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

}
