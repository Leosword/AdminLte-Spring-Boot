package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.service.PaggableSelect;
import br.com.netservicos.bow.service.RegionalService;
import br.com.netservicos.bow.web.bean.RegionalBean;
import br.com.netservicos.bow.web.constants.ControllerConstants;
import br.com.netservicos.bow.web.validation.RegionalFormValidator;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = RegionalController.REQUEST_MAPPING_PAGE)
public class RegionalController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RegionalController.class);

    private static final String SEPARATOR = "";

    private static final String ACTION_SALVAR = "/regional/salvar";

    private static final String MODEL_NAME = "regionalBean";

    private static final String TODAS_NENHUMA = "BRASIL";

    private static final String SEPARATOR_NAME = " - ";

    private static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REDIRECT_PAGE_CARREGAR = "/carregar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "regional/pesquisarregional";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR = "regional/incluiraplicacaoregional";

    protected static final String REQUEST_MAPPING_PAGE = "/regional";

    @Autowired
    private RegionalService regionalService;

    @Autowired
    private RegionalFormValidator regionalFormValidator;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = RegionalController.REDIRECT_PAGE_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<RegionalBean>> carregar() {

        LOGGER.debug("Iniciando o carregamento das regionais");

        List<Regional> regionais = regionalService.findFetchAllAtivas();

        List<RegionalBean> regionaisBean = RegionalBean.bindingProperties(regionais);

        return new ResponseEntity<List<RegionalBean>>(regionaisBean, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarComPaginacao", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<RegionalBean>> carregar(PaggableSelect paggable) {

        LOGGER.debug("Iniciando o carregamento das regionais com paginação");

        List<Regional> regionais = regionalService.findByPaggebleSelect(paggable);

        if (regionais.isEmpty()) {

            LOGGER.debug("Não foi possível localizar regionais com a pagina: {}", paggable);

            return new ResponseEntity<List<RegionalBean>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<RegionalBean> operacoesValidas = regionais.stream().filter(regional -> !TODAS_NENHUMA.equals(regional.getNome())).map(regional -> {
            String nomeCompleto = String.join(SEPARATOR_NAME, regional.getNome(), regional.getEmpresa().getDescricao());
            return new RegionalBean(regional.getId(), nomeCompleto);
        }).collect(Collectors.toList());

        return new ResponseEntity<List<RegionalBean>>(operacoesValidas, HttpStatus.OK);
    }

    @RequestMapping(value = "/incluir/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ModelAndView viewEditar(@PathVariable("id") Long id, ModelMap model, HttpServletRequest request) {

        LOGGER.debug("O id a ser atualizado é: {}", id);

        Optional<Regional> regional = regionalService.findByIdFetchAll(id);

        if (!regional.isPresent()) {

            throw new BusinessException("Não foi possivel localizar o id.");
        }

        RegionalBean regionalBean = RegionalBean.bindingProperties(regional.get());

        model.addAttribute(MODEL_NAME, regionalBean);

        model.addAttribute(ControllerConstants.METHOD_NAME, RequestMethod.PUT.name());

        String action = String.join(SEPARATOR, request.getContextPath(), ACTION_SALVAR);

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = "/salvar/{id}", method = RequestMethod.PUT)
    public ResponseEntity<ValidationResponse> salvar(@Valid @RequestBody RegionalBean regionalBean, @PathVariable("id") Long id,
            BindingResult result) {

        regionalFormValidator.validate(regionalBean, result);

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            fieldErrors.forEach(fieldError -> {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            });

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Optional<Regional> regionalOptional = regionalService.findByIdFetchAll(id);

        if (!regionalOptional.isPresent()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        Regional regional = regionalOptional.get();

        regional.setPeso(regionalBean.getPeso());

        regionalService.salvar(regional, regionalBean.getAplicacoes());

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @ExceptionHandler(BusinessException.class)
    public String handleBusinessExceptionException(BusinessException exception) {

        ModelAndView model = new ModelAndView();

        model.addObject("exception", exception.getMessage());

        model.setViewName(REQUEST_MAPPING_PAGE_INCLUIR);

        return exception.getMessage();
    }

}