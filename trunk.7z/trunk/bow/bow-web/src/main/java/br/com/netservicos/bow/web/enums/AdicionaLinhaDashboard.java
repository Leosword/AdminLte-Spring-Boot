package br.com.netservicos.bow.web.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import br.com.netservicos.bow.model.DashboardConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.model.enums.TipoConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.web.bean.IndisponibilidadeAplicacaoBean;

public enum AdicionaLinhaDashboard {

    NET_TI_CONTACT_RATE("NET_TI_CONTACT_RATE") {
        @Override
        public void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean) {

            configuracoes.forEach(configuracao -> {

                if (TipoConfiguracaoIndisponibilidade.RECHAMADA.equals(configuracao.getTipo())) {

                    bean.setLinha(configuracao.getValor());

                } else if (TipoConfiguracaoIndisponibilidade.QUANTIDADE_LIGACAO.equals(configuracao.getTipo())) {

                    bean.setLinhaSupport(configuracao.getValor());
                }
            });
        }
    },
    NET_TI_VENDAS("NET_TI_VENDAS") {

        @Override
        public void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean) {

            configuracoes.forEach(configuracao -> {

                if (TipoConfiguracaoIndisponibilidade.VENDA_BRUTA.equals(configuracao.getTipo())) {

                    bean.setLinha(configuracao.getValor());
                }
            });
        }
    },
    NET_TI_VISITA_TECNICA("NET_TI_VISITA_TECNICA") {
        
        @Override
        public void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean) {
            
            configuracoes.forEach(configuracao -> {
                
                if (TipoConfiguracaoIndisponibilidade.VISITA_PRODUTIVA.equals(configuracao.getTipo())) {
                    
                    bean.setLinha(configuracao.getValor());
                }else if(TipoConfiguracaoIndisponibilidade.VISITA_IMPRODUTIVA.equals(configuracao.getTipo())){
                    
                    bean.setLinha(configuracao.getValor());
                }
            });
        }
    },
    CLARO_MOVEL_TI_CONTACT_RATE("CLARO_MOVEL_TI_CONTACT_RATE") {
        
        @Override
        public void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean) {
            
            configuracoes.forEach(configuracao -> {
                
                if (TipoConfiguracaoIndisponibilidade.VOLUME_DE_LIGACAO.equals(configuracao.getTipo())) {
                    
                    bean.setLinha(configuracao.getValor());
                }
            });
        }
    },
    CLARO_MOVEL_TI_VENDAS("CLARO_MOVEL_TI_VENDAS") {
        
        @Override
        public void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean) {
            
            configuracoes.forEach(configuracao -> {
                
                if (TipoConfiguracaoIndisponibilidade.ATIVACAO_BRUTA.equals(configuracao.getTipo())) {
                    
                    bean.setLinha(configuracao.getValor());
                }
            });
        }
    },
    CLARO_HDTV_TI_CONTACT_RATE("CLARO_HDTV_TI_CONTACT_RATE") {
        
        @Override
        public void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean) {
            
            configuracoes.forEach(configuracao -> {
                
                if (TipoConfiguracaoIndisponibilidade.ATIVACAO_BRUTA.equals(configuracao.getTipo())) {
                    
                    bean.setLinha(configuracao.getValor());
                }
            });
        }
    },
    CLARO_HDTV_TI_VENDAS("CLARO_HDTV_TI_VENDAS") {
        
        @Override
        public void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean) {
            
            configuracoes.forEach(configuracao -> {
                
                if (TipoConfiguracaoIndisponibilidade.VENDA_BRUTA.equals(configuracao.getTipo())) {
                    
                    bean.setLinha(configuracao.getValor());
                }
            });
        }
    },
    EMBRATEL_TI_CONTACT_RATE("EMBRATEL_TI_CONTACT_RATE") {
        
        @Override
        public void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean) {
            
            configuracoes.forEach(configuracao -> {
                
                
            });
        }
    };

    protected static final Map<String, AdicionaLinhaDashboard> values = new HashMap<>();

    static {
        values.putAll(Arrays.asList(values()).stream().collect(Collectors.toMap(AdicionaLinhaDashboard::getValue, Function.identity())));
    }

    private String value;

    private AdicionaLinhaDashboard(String value) {
        this.value = value;
    }

    public static AdicionaLinhaDashboard getObject(final String composite) {
        return values.get(composite);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public abstract void adiciona(List<DashboardConfiguracaoIndisponibilidade> configuracoes, IndisponibilidadeAplicacaoBean bean);

}
