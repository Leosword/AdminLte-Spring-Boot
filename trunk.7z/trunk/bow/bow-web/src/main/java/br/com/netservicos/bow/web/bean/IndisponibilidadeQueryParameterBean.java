package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class IndisponibilidadeQueryParameterBean implements Serializable {

    private static final long serialVersionUID = -2280694394712865937L;

    private Integer tipo;

    private String empresa;

    private String tipoAplicacao;

    private boolean slaGeral;

    public Integer getTipo() {
        return tipo;
    }

    public void setTipo(Integer tipo) {
        this.tipo = tipo;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getTipoAplicacao() {
        return tipoAplicacao;
    }

    public void setTipoAplicacao(String tipoAplicacao) {
        this.tipoAplicacao = tipoAplicacao;
    }

    public boolean isSlaGeral() {
        return slaGeral;
    }

    public void setSlaGeral(boolean slaGeral) {
        this.slaGeral = slaGeral;
    }

}