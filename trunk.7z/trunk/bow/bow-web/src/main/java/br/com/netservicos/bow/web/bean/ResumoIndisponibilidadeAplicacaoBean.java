package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class ResumoIndisponibilidadeAplicacaoBean implements Serializable {

    private static final long serialVersionUID = -8616159110134783560L;

    private String dia;

    private String aplicacao;

    private String fato;

    private String causa;

    public ResumoIndisponibilidadeAplicacaoBean() {
        // Construtor padrão
    }

    public ResumoIndisponibilidadeAplicacaoBean(String dia, String aplicacao, String fato, String causa) {
        this.dia = dia;
        this.aplicacao = aplicacao;
        this.fato = fato;
        this.causa = causa;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

    public String getFato() {
        return fato;
    }

    public void setFato(String fato) {
        this.fato = fato;
    }

    public String getCausa() {
        return causa;
    }

    public void setCausa(String causa) {
        this.causa = causa;
    }

}
