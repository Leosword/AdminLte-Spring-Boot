package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.netservicos.bow.model.Cidade;
import br.com.netservicos.bow.model.Estado;
import br.com.netservicos.bow.service.CidadeService;
import br.com.netservicos.bow.service.EstadoService;
import br.com.netservicos.bow.service.PaggableSelect;

@RestController
@RequestMapping(value = EstadoController.REQUEST_MAPPING_PAGE)
public class EstadoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EstadoController.class);

    protected static final String REQUEST_MAPPING_PAGE = "/estado";

    @Autowired
    private EstadoService estadoService;

    @Autowired
    private CidadeService cidadeService;

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Estado>> carregar(PaggableSelect paggable) {

        List<Estado> estados = estadoService.findByPaggebleSelect(paggable);

        if (estados.isEmpty()) {

            LOGGER.debug("Não foi possível localizar o estado com a paginação: {}", paggable);

            return new ResponseEntity<List<Estado>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Estado>>(estados, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarPorBase", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Estado>> carregarEstado(Long baseId) {

        List<Cidade> cidades = cidadeService.findByFetchAllBase(baseId);

        if (cidades.isEmpty()) {

            LOGGER.debug("Não foi possível localizar o cidades com o id da Base: {}", baseId);

            return new ResponseEntity<List<Estado>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<Estado> estados = estadoService.transform(cidades);

        return new ResponseEntity<List<Estado>>(estados, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarPorId", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Estado> carregarPorId(Long estadoId) {

        if (estadoId != null) {

            Optional<Estado> estado = estadoService.findById(estadoId);

            if (!estado.isPresent()) {

                return new ResponseEntity<Estado>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<Estado>(estado.get(), HttpStatus.OK);
        }

        return new ResponseEntity<Estado>(HttpStatus.NO_CONTENT);
    }

}
