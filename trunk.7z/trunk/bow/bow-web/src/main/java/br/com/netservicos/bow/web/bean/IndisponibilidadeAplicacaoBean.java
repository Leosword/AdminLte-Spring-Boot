package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class IndisponibilidadeAplicacaoBean implements Serializable {

    private static final long serialVersionUID = 7869996259784452036L;

    private BigDecimal tipoTotal;

    private BigDecimal tipoParcial;

    private BigDecimal tipoFuncional;

    private BigDecimal totalMinutos;
    
    private BigDecimal linha;

    private BigDecimal linhaSupport;

    private String aplicacao;

    private String dia;

    private String tipoIndisponibilidade;

    public IndisponibilidadeAplicacaoBean() {
        // Construtor padrão
    }

    public IndisponibilidadeAplicacaoBean(String dia) {
        this.dia = dia;
    }

    public IndisponibilidadeAplicacaoBean(BigDecimal tipoTotal, BigDecimal tipoParcial, BigDecimal tipoFuncional, String dia) {
        this.tipoTotal = tipoTotal;
        this.tipoParcial = tipoParcial;
        this.tipoFuncional = tipoFuncional;
        this.dia = dia;
    }

    public IndisponibilidadeAplicacaoBean(BigDecimal totalMinutos, String aplicacao, String dia, String tipo) {
        this.totalMinutos = totalMinutos;
        this.aplicacao = aplicacao;
        this.dia = dia;
        this.tipoIndisponibilidade = tipo;
    }
    
    public IndisponibilidadeAplicacaoBean(BigDecimal totalMinutos, String aplicacao, String dia, String tipo, BigDecimal linha) {
        this.totalMinutos = totalMinutos;
        this.aplicacao = aplicacao;
        this.dia = dia;
        this.tipoIndisponibilidade = tipo;
        this.linha = linha;
    }
    
    public IndisponibilidadeAplicacaoBean(BigDecimal totalMinutos, String aplicacao, String dia, String tipo, BigDecimal linha, BigDecimal linhaSupport) {
        this.totalMinutos = totalMinutos;
        this.aplicacao = aplicacao;
        this.dia = dia;
        this.tipoIndisponibilidade = tipo;
        this.linha = linha;
        this.linhaSupport = linhaSupport;
    }
    
    

    public BigDecimal getTipoTotal() {
        return tipoTotal;
    }

    public void setTipoTotal(BigDecimal tipoTotal) {
        this.tipoTotal = tipoTotal;
    }

    public BigDecimal getTipoParcial() {
        return tipoParcial;
    }

    public void setTipoParcial(BigDecimal tipoParcial) {
        this.tipoParcial = tipoParcial;
    }

    public BigDecimal getTipoFuncional() {
        return tipoFuncional;
    }

    public void setTipoFuncional(BigDecimal tipoFuncional) {
        this.tipoFuncional = tipoFuncional;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

    public BigDecimal getTotalMinutos() {
        return totalMinutos;
    }

    public void setTotalMinutos(BigDecimal totalMinutos) {
        this.totalMinutos = totalMinutos;
    }

    public String getTipoIndisponibilidade() {
        return tipoIndisponibilidade;
    }

    public void setTipoIndisponibilidade(String tipoIndisponibilidade) {
        this.tipoIndisponibilidade = tipoIndisponibilidade;
    }

    public BigDecimal getLinha() {
        return linha;
    }

    public void setLinha(BigDecimal linha) {
        this.linha = linha;
    }

    public BigDecimal getLinhaSupport() {
        return linhaSupport;
    }

    public void setLinhaSupport(BigDecimal linhaSupport) {
        this.linhaSupport = linhaSupport;
    }

}
