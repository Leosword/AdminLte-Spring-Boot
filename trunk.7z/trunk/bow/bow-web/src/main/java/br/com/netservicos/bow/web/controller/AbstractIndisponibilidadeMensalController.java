package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import br.com.netservicos.bow.common.util.DateUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.IndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.web.bean.IndisponibilidadeAplicacaoMensalBean;
import br.com.netservicos.bow.web.enums.AdicionaIndisponibilidadeMensal;

public class AbstractIndisponibilidadeMensalController {

    private static final List<Integer> MESES = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractIndisponibilidadeMensalController.class);

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    @Autowired
    private IndisponibilidadeAplicacaoMensalService service;

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    protected List<IndisponibilidadeAplicacaoMensalBean> carregarIndisponibilidade(List<AplicacaoBook> aplicacoesBook) {

        List<Aplicacao> aplicacoes = aplicacoesBook.stream().map(AplicacaoBook::getAplicacao).collect(Collectors.toList());

        List<IndisponibilidadeAplicacaoMensal> indisponibilidadesMensais = service.findByAno(DateUtil.getYear(new Date()), aplicacoes);

        List<IndisponibilidadeAplicacaoMensalBean> indisponibilidades = new ArrayList<>();

        try {

            final Integer ano = DateUtil.getYear(new Date());

            aplicacoesBook.forEach(new Consumer<AplicacaoBook>() {

                @Override
                public void accept(AplicacaoBook aplicacaoBook) {

                    Aplicacao aplicacao = aplicacaoBook.getAplicacao();

                    IndisponibilidadeAplicacaoMensalBean bean = new IndisponibilidadeAplicacaoMensalBean();

                    bean.setAplicacao(aplicacao.getDescricao());

                    List<IndisponibilidadeAplicacaoMensal> collectFilter = indisponibilidadesMensais.stream()
                            .filter(indisponibilidade -> indisponibilidade.getAplicacao().equals(aplicacao)).collect(Collectors.toList());

                    MESES.forEach(mes -> {

                        LocalDate periodo = LocalDate.of(ano, mes, NumberUtil.INTEGER_ONE);

                        Optional<IndisponibilidadeAplicacaoMensal> indisponibilidadeMensal = service.filterByPeriodo(collectFilter, periodo);

                        if (indisponibilidadeMensal.isPresent()) {

                            AdicionaIndisponibilidadeMensal.getObject(mes).adiciona(indisponibilidadeMensal.get(), bean);
                        }

                    });

                    String consolidado = calculaIndisponibilidadeService.calculaMediaMinutos(collectFilter);

                    String consolidadoPercentual = calculaIndisponibilidadeService.calculaMediaPercentual(collectFilter);

                    String consolidadoPosPatch = calculaIndisponibilidadeService.calculaMediaMinutosPosPatch(collectFilter);

                    String consolidadoPercentualPosPatch = calculaIndisponibilidadeService.calculaMediaPercentualPosPatch(collectFilter);

                    bean.setConsolidadoMinutosMensal(consolidado);

                    bean.setConsolidadoPercentualMensal(consolidadoPercentual);

                    bean.setConsolidadoMinutosPosPatchMensal(consolidadoPosPatch);

                    bean.setConsolidadoPercentualPosPatchMensal(consolidadoPercentualPosPatch);

                    indisponibilidades.add(bean);
                }
            });

            IndisponibilidadeAplicacaoMensalBean indisponbilidadeGeral = createConsolidadoGeral(indisponibilidadesMensais, ano,
                    aplicacoesBook.size());

            indisponibilidades.add(indisponbilidadeGeral);

        } catch (Exception ex) {

            LOGGER.error("Error ao carregar as indisponibilidades por aplicação: {}", ex);
        }

        return indisponibilidades;
    }

    private IndisponibilidadeAplicacaoMensalBean createConsolidadoGeral(List<IndisponibilidadeAplicacaoMensal> indisponibilidades, Integer ano,
            Integer total) {

        IndisponibilidadeAplicacaoMensalBean bean = new IndisponibilidadeAplicacaoMensalBean();

        List<BigDecimal> consolidadosMinutos = new ArrayList<>();

        List<BigDecimal> consolidadosPercentuais = new ArrayList<>();

        List<BigDecimal> consolidadosMinutosPosPatch = new ArrayList<>();

        List<BigDecimal> consolidadosPercentuaisPosPatch = new ArrayList<>();

        MESES.forEach(new Consumer<Integer>() {

            @Override
            public void accept(Integer mes) {

                LocalDate periodo = LocalDate.of(ano, mes, NumberUtil.INTEGER_ONE);

                BigDecimal minutos = calculaIndisponibilidadeService.calculaMinutos(indisponibilidades, total, periodo);

                BigDecimal resultadoPercentual = calculaIndisponibilidadeService.calculaPercentual(indisponibilidades, total, periodo);

                consolidadosMinutos.add(minutos);

                consolidadosPercentuais.add(resultadoPercentual);

                BigDecimal minutosPosPatch = calculaIndisponibilidadeService.calculaMinutosPosPatch(indisponibilidades, total, periodo);

                BigDecimal percentualPosPatch = calculaIndisponibilidadeService.calculaPercentualPosPatch(indisponibilidades, total, periodo);

                consolidadosMinutosPosPatch.add(minutosPosPatch);

                consolidadosPercentuaisPosPatch.add(percentualPosPatch);

                IndisponibilidadeAplicacaoMensal indisponibilidadeAplicacaoMensal = new IndisponibilidadeAplicacaoMensal(minutos, resultadoPercentual,
                        minutosPosPatch, percentualPosPatch);

                AdicionaIndisponibilidadeMensal.getObject(mes).adiciona(indisponibilidadeAplicacaoMensal, bean);
            }

        });

        adicionaMinutos(bean, consolidadosMinutos);

        adicionaPercentual(bean, consolidadosPercentuais);

        adicionaMinutosPosPatch(bean, consolidadosMinutosPosPatch);

        adicionaPercentualPosPatch(bean, consolidadosPercentuaisPosPatch);

        return bean;
    }

    private void adicionaPercentualPosPatch(IndisponibilidadeAplicacaoMensalBean bean, List<BigDecimal> consolidadosPercentuaisPosPatch) {

        int divisor = LocalDate.now().getMonthValue();

        BigDecimal consolidadoMensalPercentualPosPatch = consolidadosPercentuaisPosPatch.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(new BigDecimal(divisor), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        bean.setConsolidadoPercentualPosPatchMensal(String.valueOf(consolidadoMensalPercentualPosPatch));
    }

    private void adicionaMinutosPosPatch(IndisponibilidadeAplicacaoMensalBean bean, List<BigDecimal> consolidadosMinutosPosPatch) {

        int divisor = LocalDate.now().getMonthValue();

        BigDecimal consolidadoMensalMinutosPosPatch = consolidadosMinutosPosPatch.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(new BigDecimal(divisor), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        BigDecimal minutosPosPatch = converter.convert(consolidadoMensalMinutosPosPatch);

        bean.setConsolidadoMinutosPosPatchMensal(String.valueOf(minutosPosPatch));
    }

    private void adicionaPercentual(IndisponibilidadeAplicacaoMensalBean bean, List<BigDecimal> consolidadosPercentuais) {

        int divisor = LocalDate.now().getMonthValue();

        BigDecimal consolidadoMensalPercentual = consolidadosPercentuais.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(new BigDecimal(divisor), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        bean.setConsolidadoPercentualMensal(String.valueOf(consolidadoMensalPercentual));
    }

    private void adicionaMinutos(IndisponibilidadeAplicacaoMensalBean bean, List<BigDecimal> consolidadosMinutos) {

        int divisor = LocalDate.now().getMonthValue();

        BigDecimal consolidadoMensalMinutos = consolidadosMinutos.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(new BigDecimal(divisor), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        BigDecimal minutos = converter.convert(consolidadoMensalMinutos);

        bean.setConsolidadoMinutosMensal(String.valueOf(minutos));
    }

}
