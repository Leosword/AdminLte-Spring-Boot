package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class DashboardIndisponibilidadeMensalBean implements Serializable {

    private static final long serialVersionUID = 2680480393604601072L;

    private String mes;

    private BigDecimal anterior;

    private BigDecimal atual;

    private BigDecimal posPatch;

    private BigDecimal sla;

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public BigDecimal getAnterior() {
        return anterior;
    }

    public void setAnterior(BigDecimal anterior) {
        this.anterior = anterior;
    }

    public BigDecimal getAtual() {
        return atual;
    }

    public void setAtual(BigDecimal atual) {
        this.atual = atual;
    }

    public BigDecimal getPosPatch() {
        return posPatch;
    }

    public void setPosPatch(BigDecimal posPatch) {
        this.posPatch = posPatch;
    }

    public BigDecimal getSla() {
        return sla;
    }

    public void setSla(BigDecimal sla) {
        this.sla = sla;
    }

}