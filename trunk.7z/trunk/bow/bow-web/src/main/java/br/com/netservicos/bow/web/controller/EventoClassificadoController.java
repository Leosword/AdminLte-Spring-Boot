package br.com.netservicos.bow.web.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.ImpactoIndicadorEvento;
import br.com.netservicos.bow.model.ImpactoIndicadorEventoBook;
import br.com.netservicos.bow.service.EventoClassificadoService;
import br.com.netservicos.bow.service.ImpactoIndicadorEventoService;
import br.com.netservicos.bow.service.RemoverEventoClassificadoService;
import br.com.netservicos.bow.web.bean.EventoClassificadoBean;
import br.com.netservicos.bow.web.bean.ImpactoIndicadorEventoBookBean;
import br.com.netservicos.bow.web.constants.ControllerConstants;

@RestController
@RequestMapping(value = EventoClassificadoController.REQUEST_MAPPING_PAGE)
public class EventoClassificadoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AplicacaoController.class);

    protected static final String REQUEST_MAPPING_PAGE = "/evento";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "evento/pesquisarevento";

    private static final String REQUEST_MAPPING_PAGE_RECALCULAR = "evento/recalcularevento";

    private static final String REQUEST_MAPPING_CARREGAR_SEM_APROVACAO = "/carregar-sem-aprovacao";

    private static final String REQUEST_MAPPING_CARREGAR_IMPACTOS = "/carregar-impactos";

    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";

    private static final String EMPTY_VALUE = "N/A";

    private static final String SEPARATOR = "";

    @Autowired
    private EventoClassificadoService eventoClassificadoService;

    @Autowired
    private ImpactoIndicadorEventoService impactoIndicadorService;

    @Autowired
    private RemoverEventoClassificadoService removerEventoClassificadoService;

    @RequestMapping(value = "/pesquisar", method = RequestMethod.GET)
    public ModelAndView showPesquisar() {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = "/recalcular", method = RequestMethod.GET)
    public ModelAndView showRecalcular(Model model, HttpServletRequest request) {

        model.addAttribute("eventoClassificadoBean", new EventoClassificadoBean());

        String action = String.join(SEPARATOR, request.getContextPath(), "/evento/remover");

        model.addAttribute(ControllerConstants.ACTION, action);

        return new ModelAndView(REQUEST_MAPPING_PAGE_RECALCULAR);
    }

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<EventoClassificadoBean>> carregar() {

        LOGGER.debug("Iniciando o carregamento dos eventos classificados");

        List<EventoClassificado> eventos = eventoClassificadoService.findByFetchAllAtivos();

        if (eventos.isEmpty()) {

            return new ResponseEntity<List<EventoClassificadoBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<EventoClassificadoBean> eventosBean = EventoClassificadoBean.bindingProperties(eventos);

        return new ResponseEntity<List<EventoClassificadoBean>>(eventosBean, HttpStatus.OK);
    }

    @RequestMapping(value = REQUEST_MAPPING_CARREGAR_SEM_APROVACAO, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<EventoClassificadoBean>> carregarNaoAprovados() {

        LOGGER.debug("Iniciando o carregamento dos eventos sem classificação");

        List<EventoClassificado> eventos = eventoClassificadoService.findUtimosSemAprovacao();

        if (eventos.isEmpty()) {

            return new ResponseEntity<List<EventoClassificadoBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<EventoClassificadoBean> eventosBean = eventos.stream().map(evento -> new EventoClassificadoBean(evento.getMinutos(),
                evento.getAplicacao().getDescricao(), evento.getAplicacao().getEmpresa().getDescricao())).collect(Collectors.toList());

        return new ResponseEntity<List<EventoClassificadoBean>>(eventosBean, HttpStatus.OK);
    }

    @RequestMapping(value = REQUEST_MAPPING_CARREGAR_IMPACTOS, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ImpactoIndicadorEventoBookBean>> carregarImpactos(Long eventoId) {

        LOGGER.debug("Carregando os impactos do Book para o evento: {}", eventoId);

        List<ImpactoIndicadorEvento> impactosEventos = impactoIndicadorService.findByEvento(eventoId);

        if (CollectionUtil.isEmpty(impactosEventos)) {

            return new ResponseEntity<List<ImpactoIndicadorEventoBookBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        Set<ImpactoIndicadorEvento> impactosSet = new HashSet<>(impactosEventos);

        List<ImpactoIndicadorEventoBookBean> impactos = new ArrayList<>();

        impactosSet.forEach(impacto -> {

            adicionaImpactosBook(impactos, impacto);
        });

        return new ResponseEntity<List<ImpactoIndicadorEventoBookBean>>(impactos, HttpStatus.OK);
    }

    private void adicionaImpactosBook(List<ImpactoIndicadorEventoBookBean> impactos, ImpactoIndicadorEvento impacto) {

        DateFormat format = new SimpleDateFormat(PATTERN);

        Set<ImpactoIndicadorEventoBook> impactosBook = impacto.getImpactosBook();

        String base = Objects.isNull(impacto.getBase()) ? EMPTY_VALUE : impacto.getBase().getNome();

        String cidade = Objects.isNull(impacto.getCidade()) ? EMPTY_VALUE : impacto.getCidade().getNome();

        String operacao = Objects.isNull(impacto.getOperacao()) ? EMPTY_VALUE : impacto.getOperacao().getNome();

        String regional = Objects.isNull(impacto.getRegional()) ? EMPTY_VALUE : impacto.getRegional().getNome();

        impactosBook.forEach(impactoBook -> {

            String inicio = format.format(impactoBook.getInicio());

            String fim = format.format(impactoBook.getTermino());

            impactos.add(
                    new ImpactoIndicadorEventoBookBean(impactoBook.getId(), base, operacao, cidade, regional, impactoBook.getDuracao(), inicio, fim));
        });
    }

    @RequestMapping(value = "/remover", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> remover(@RequestBody EventoClassificadoBean eventoClassificadoBean) {

        LOGGER.debug("Removendo Evento com Id: {}", eventoClassificadoBean.getEventoId());

        removerEventoClassificadoService.remover(eventoClassificadoBean.getEventoId());

        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @RequestMapping(value = "/aprovar/{ids}", method = RequestMethod.POST)
    public ResponseEntity<Void> aprovar(@PathVariable("ids") Long[] ids) {

        eventoClassificadoService.aprovar(ids);

        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @RequestMapping(value = "/reprovar/{ids}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> reprovar(@PathVariable("ids") Long[] ids) {

        eventoClassificadoService.reprovar(ids);

        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
}
