package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

import br.com.netservicos.bow.model.EventoClassificado;
import br.com.netservicos.bow.model.FCAEvento;

public class EventoClassificadoBean implements Serializable {

    private static final long serialVersionUID = 7670007304715727586L;

    private Long id;

    private Long eventoId;

    private Long eventoPai;

    private Long[] ids;

    private String fato;

    private String causa;

    private String acao;

    private String categoria;

    private String chamado;

    private String fornecedor;

    private Long rca;

    private String minutos;

    private String ofensor;

    private String origem;

    private String tipo;

    private String aplicacao;

    private String empresa;

    public EventoClassificadoBean() {
        // Construtor padrão
    }

    public EventoClassificadoBean(Long id, Long eventoId, Long eventoPai, String fato, String causa, String acao, String categoria, String chamado,
            String fornecedor, Long rca, String ofensor, String origem, String tipo, String aplicacao, String empresa) {
        this.id = id;
        this.eventoId = eventoId;
        this.eventoPai = eventoPai;
        this.fato = fato;
        this.causa = causa;
        this.acao = acao;
        this.categoria = categoria;
        this.chamado = chamado;
        this.fornecedor = fornecedor;
        this.rca = rca;
        this.ofensor = ofensor;
        this.origem = origem;
        this.tipo = tipo;
        this.aplicacao = aplicacao;
        this.empresa = empresa;
    }

    public EventoClassificadoBean(String minutos, String aplicacao, String empresa) {
        this.minutos = minutos;
        this.aplicacao = aplicacao;
        this.empresa = empresa;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getEventoId() {
        return eventoId;
    }

    public void setEventoId(Long eventoId) {
        this.eventoId = eventoId;
    }

    public Long getEventoPai() {
        return eventoPai;
    }

    public void setEventoPai(Long eventoPai) {
        this.eventoPai = eventoPai;
    }

    public Long[] getIds() {
        return ids;
    }

    public void setIds(Long[] ids) {
        this.ids = ids;
    }

    public String getFato() {
        return fato;
    }

    public void setFato(String fato) {
        this.fato = fato;
    }

    public String getCausa() {
        return causa;
    }

    public void setCausa(String causa) {
        this.causa = causa;
    }

    public String getAcao() {
        return acao;
    }

    public void setAcao(String acao) {
        this.acao = acao;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getChamado() {
        return chamado;
    }

    public void setChamado(String chamado) {
        this.chamado = chamado;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Long getRca() {
        return rca;
    }

    public void setRca(Long rca) {
        this.rca = rca;
    }

    public String getMinutos() {
        return minutos;
    }

    public void setMinutos(String minutos) {
        this.minutos = minutos;
    }

    public String getOfensor() {
        return ofensor;
    }

    public void setOfensor(String ofensor) {
        this.ofensor = ofensor;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public static List<EventoClassificadoBean> bindingProperties(List<EventoClassificado> eventos) {

        List<EventoClassificadoBean> eventosBean = eventos.stream()
                .map(evento -> new EventoClassificadoBean(evento.getId(), evento.getEventoId(), evento.getEventoPaiId(),
                        getFato(evento.getFcaEvento()), getCausa(evento.getFcaEvento()), getAcao(evento.getFcaEvento()),
                        evento.getAplicacao().getTipo().getDescricao(), evento.getChamado(), evento.getGrupo().getDescricao(), evento.getRca(),
                        evento.getPrimario().getDescricao(), evento.getOrigem().getDescricao(), evento.getTipoIndisponibilidade().getDescricao(),
                        evento.getAplicacao().getDescricao(), evento.getAplicacao().getEmpresa().getDescricao()))
                .collect(Collectors.toList());

        return eventosBean;
    }

    public static String getFato(FCAEvento fcaEvento) {

        return fcaEvento == null ? "" : fcaEvento.getFato();
    }

    public static String getCausa(FCAEvento fcaEvento) {

        return fcaEvento == null ? "" : fcaEvento.getCausa();
    }

    public static String getAcao(FCAEvento fcaEvento) {

        return fcaEvento == null ? "" : fcaEvento.getAcao();
    }

}
