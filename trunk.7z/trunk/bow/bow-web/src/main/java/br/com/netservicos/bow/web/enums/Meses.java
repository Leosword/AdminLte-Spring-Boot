package br.com.netservicos.bow.web.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum Meses {

    JANEIRO(1, "jan", "Janeiro"), FEVEREIRO(2, "fev", "Fevereiro"), MARCO(3, "mar", "Março"), ABRIL(4, "abr", "Abril"), MAIO(5, "mai", "Maio"), JUNHO(
            6, "jun", "Junho"), JULHO(7, "jul", "Julho"), AGOSTO(8, "ago", "Agosto"), SETEMBRO(9, "set",
                    "Setembro"), OUTUBRO(10, "out", "Outubro"), NOVEMBRO(11, "nov", "Novembro"), DEZEMBRO(12, "dez", "Dezembro");

    protected static final Map<Integer, Meses> meses = new HashMap<>();

    static {
        meses.putAll(Arrays.asList(values()).stream().collect(Collectors.toMap(Meses::getMes, Function.identity())));
    }

    private Integer mes;

    private String label;

    private String extension;

    private Meses(Integer mes, String label, String extension) {
        this.mes = mes;
        this.label = label;
        this.extension = extension;
    }

    public Integer getMes() {
        return mes;
    }

    public void setMes(Integer mes) {
        this.mes = mes;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public static final Meses getObject(final Integer mes) {
        return meses.get(mes);
    }

}
