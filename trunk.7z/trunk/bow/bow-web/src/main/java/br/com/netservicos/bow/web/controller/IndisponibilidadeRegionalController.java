package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Multimap;
import com.google.common.collect.Table;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeEvento;
import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.Regional;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.model.enums.TipoNivelServico;
import br.com.netservicos.bow.service.AplicacaoBookService;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeEventoService;
import br.com.netservicos.bow.service.EmpresaService;
import br.com.netservicos.bow.service.IndisponibilidadeEventoService;
import br.com.netservicos.bow.service.ParametroService;
import br.com.netservicos.bow.service.RegionalService;
import br.com.netservicos.bow.service.collector.MultimapCollector;
import br.com.netservicos.bow.web.bean.IndisponibilidadeRegionalBean;
import br.com.netservicos.bow.web.enums.AdicionaIndisponibilidadeRegional;
import br.com.netservicos.bow.web.enums.Meses;

@RestController
public class IndisponibilidadeRegionalController {

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeRegionalController.class);

    private static final String REQUEST_MAPPING_CARREGAR = "/indisponibilidade-mensal/regional/carregar";

    private static final String REQUEST_MAPPING_PAGE_REGIONAL = "indisponibilidade/pesquisarindisponibilidaderegionalconsolidado";

    private static final String URA = "URA";

    private static final String LINK = "LINK";

    private static final String BRASIL = "BRASIL";

    private static final String SISTEMA = "Sistema";

    private Table<String, BigDecimal, BigDecimal> table;

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    @Autowired
    private AplicacaoBookService aplicacaoBookService;

    @Autowired
    private RegionalService regionalService;

    @Autowired
    private EmpresaService empresaService;

    @Autowired
    private IndisponibilidadeEventoService indisponibilidadeService;

    @Autowired
    private CalculaIndisponibilidadeEventoService calculaService;

    @Autowired
    private ParametroService parametroService;

    @RequestMapping(value = "/indisponibilidade-mensal/regional/{empresa}", method = RequestMethod.GET)
    public ModelAndView showPesquisa(Model model, @PathVariable Integer empresa) {

        LOGGER.debug("Visulizando a tela de pesquisa por regional");

        Parametro parametroSla = parametroService.findByNome(ParametroConstants.VALOR_SLA);

        Parametro parametroBH = parametroService.findByNome(ParametroConstants.BUSINESS_HOURS);

        LocalDate localDate = LocalDate.now();

        int ano = localDate.getYear();

        Month month = localDate.getMonth();

        BigDecimal totalMinutos = calculaIndisponibilidadeService.calculaMinutosBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        BigDecimal totalPercentual = calculaIndisponibilidadeService.calculaPercentualBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        model.addAttribute("sla_minutos", totalMinutos);

        model.addAttribute("sla_percentual", totalPercentual);

        model.addAttribute("empresa", empresa);

        model.addAttribute("nomeempresa", IdentificadorEmpresa.getIdentificadorEmpresa(empresa).getDescription());

        model.addAttribute("ano", ano);

        model.addAttribute("mes", Meses.getObject(month.getValue()));

        return new ModelAndView(REQUEST_MAPPING_PAGE_REGIONAL);
    }

    @RequestMapping(value = REQUEST_MAPPING_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<IndisponibilidadeRegionalBean>> carregar() {

        LOGGER.debug("Carregando as informações de regional por mes atual");

        LocalDate data = LocalDate.now();

        table = HashBasedTable.create();

        Optional<Empresa> empresa = empresaService.findByIdentificador(IdentificadorEmpresa.CLARO_MOVEL);

        List<Regional> regionais = regionalService.findByEmpresa(empresa.get()).stream().filter(regional -> !BRASIL.equals(regional.getNome()))
                .collect(Collectors.toList());

        if (CollectionUtil.isEmpty(regionais)) {

            LOGGER.warn("Não foi possível localizar regionais cadastradas para a empresa: {}.", empresa.get());

            return new ResponseEntity<List<IndisponibilidadeRegionalBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<IndisponibilidadeRegionalBean> indisponibilidades = new ArrayList<>();

        List<IndisponibilidadeRegionalBean> urasLinks = addIndisponibilidadeUraLink(regionais, data);

        indisponibilidades.addAll(urasLinks);

        List<IndisponibilidadeRegionalBean> sistemicas = addIndisponibilidadeSistemica(regionais, data);

        indisponibilidades.addAll(sistemicas);

        IndisponibilidadeRegionalBean consolidado = addIndisponibilidadeConsolidado();

        indisponibilidades.add(consolidado);

        return new ResponseEntity<List<IndisponibilidadeRegionalBean>>(indisponibilidades, HttpStatus.OK);
    }

    private IndisponibilidadeRegionalBean addIndisponibilidadeConsolidado() {

        IndisponibilidadeRegionalBean bean = new IndisponibilidadeRegionalBean();

        table.rowMap().keySet().forEach(regional -> {

            Map<BigDecimal, BigDecimal> row = table.row(regional);

            Set<BigDecimal> minutosReais = row.keySet();

            BigDecimal totalMinutos = minutosReais.stream().filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal minutos = totalMinutos.divide(new BigDecimal(minutosReais.size()), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO,
                    RoundingMode.HALF_EVEN);

            Collection<BigDecimal> percentuaisReais = row.values();

            BigDecimal totalPercentual = percentuaisReais.stream().filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal percentual = totalPercentual.divide(new BigDecimal(percentuaisReais.size()), MathContext.DECIMAL32)
                    .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

            BigDecimal minutoPonderados = minutos.setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

            MinutosIndisponibilidade indisponibilidade = new MinutosIndisponibilidade(minutoPonderados, percentual);

            AdicionaIndisponibilidadeRegional.getObject(regional.toUpperCase()).adiciona(indisponibilidade, bean);
        });

        return bean;
    }

    private List<IndisponibilidadeRegionalBean> addIndisponibilidadeSistemica(List<Regional> regionais, LocalDate data) {

        List<IndisponibilidadeRegionalBean> indisponibilidadesRegionais = new ArrayList<>();

        Parametro parametro = parametroService.findByNome(ParametroConstants.MINUTOS_DIA);

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipoComSla(TipoNivelServico.REGIONAL, "2", SISTEMA);

        List<Aplicacao> aplicacoes = aplicacoesBook.stream().map(aplicacaoBook -> aplicacaoBook.getAplicacao()).collect(Collectors.toList());

        aplicacoes.forEach(aplicacao -> {

            IndisponibilidadeRegionalBean bean = new IndisponibilidadeRegionalBean();

            bean.setAplicacao(aplicacao.getDescricao());

            regionais.forEach(regional -> {

                List<IndisponibilidadeEvento> indisponibilidades = indisponibilidadeService.findByRegional(regional, aplicacao, data.getMonthValue(),
                        data.getYear());

                if (CollectionUtil.isEmpty(indisponibilidades)) {

                    table.put(regional.getNome(), BigDecimal.ZERO, BigDecimal.ZERO);

                } else {

                    MinutosIndisponibilidade indisponibilidade = calculaService.calculaMinutosRegional(indisponibilidades, parametro.getValor());

                    table.put(regional.getNome(), indisponibilidade.getMinutos(), indisponibilidade.getPercentual());

                    AdicionaIndisponibilidadeRegional.getObject(regional.getNome().toUpperCase()).adiciona(indisponibilidade, bean);
                }
            });

            indisponibilidadesRegionais.add(bean);

        });

        return indisponibilidadesRegionais;
    }

    private List<IndisponibilidadeRegionalBean> addIndisponibilidadeUraLink(List<Regional> regionais, LocalDate data) {

        List<IndisponibilidadeRegionalBean> indisponibilidadesRegionais = new ArrayList<>();

        Parametro parametro = parametroService.findByNome(ParametroConstants.MINUTOS_DIA);

        List<TipoNivelServico> tiposNiveis = Arrays.asList(TipoNivelServico.SISTEMICO);

        List<String> nomesAplicacoes = Arrays.asList(URA, LINK);

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipos(tiposNiveis, "2", nomesAplicacoes);

        Multimap<TipoAplicacao, Aplicacao> tipos = aplicacoesBook.stream().map(aplicacaoBook -> aplicacaoBook.getAplicacao())
                .collect(MultimapCollector.toMultimap(Aplicacao::getTipo));

        tipos.asMap().keySet().forEach(tipo -> {

            IndisponibilidadeRegionalBean bean = new IndisponibilidadeRegionalBean();

            bean.setAplicacao(tipo.getDescricao());

            List<Aplicacao> aplicacoes = tipos.get(tipo).stream().collect(Collectors.toList());

            regionais.forEach(regional -> {

                bean.setRegional(regional.getDescricao());

                List<IndisponibilidadeEvento> indisponibilidades = indisponibilidadeService.findByRegional(regional, aplicacoes, data.getMonthValue(),
                        data.getYear());

                if (CollectionUtil.isEmpty(indisponibilidades)) {

                    table.put(regional.getNome(), BigDecimal.ZERO, BigDecimal.ZERO);

                } else {

                    MinutosIndisponibilidade indisponibilidade = calculaService.calculaMinutosRegional(indisponibilidades, parametro.getValor());

                    table.put(regional.getNome(), indisponibilidade.getMinutos(), indisponibilidade.getPercentual());

                    AdicionaIndisponibilidadeRegional.getObject(regional.getNome()).adiciona(indisponibilidade, bean);
                }
            });

            indisponibilidadesRegionais.add(bean);

        });

        return indisponibilidadesRegionais;
    }

    public Table<String, BigDecimal, BigDecimal> getTable() {
        return table;
    }

}