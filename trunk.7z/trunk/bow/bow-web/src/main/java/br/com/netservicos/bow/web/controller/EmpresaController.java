package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.service.EmpresaService;
import br.com.netservicos.bow.service.PaggableSelect;

@RestController
@RequestMapping(value = EmpresaController.REQUEST_MAPPING_PAGE)
public class EmpresaController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmpresaController.class);

    protected static final String REQUEST_MAPPING_PAGE = "/empresa";

    @Autowired
    private EmpresaService empresaService;

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Empresa>> carregar(PaggableSelect paggable) {

        LOGGER.debug("Iniciando o carregamento dos empresas");

        List<Empresa> empresas = empresaService.findByPaggebleSelect(paggable);

        if (empresas.isEmpty()) {

            return new ResponseEntity<List<Empresa>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Empresa>>(empresas, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarPorId", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Empresa> carregarPorId(Long empresaId) {

        if (empresaId != null) {

            Optional<Empresa> empresa = empresaService.findById(empresaId);

            if (!empresa.isPresent()) {

                LOGGER.error("Não foi possível localizar a empresa com Id: {}", empresaId);

                return new ResponseEntity<Empresa>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<Empresa>(empresa.get(), HttpStatus.OK);
        }

        return new ResponseEntity<Empresa>(HttpStatus.NO_CONTENT);
    }

}
