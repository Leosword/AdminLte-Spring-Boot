package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.netservicos.bow.model.Cidade;
import br.com.netservicos.bow.service.CidadeService;
import br.com.netservicos.bow.service.PaggableSelect;

@RestController
@RequestMapping(value = CidadeController.REQUEST_MAPPING_PAGE)
public class CidadeController {

    protected static final String REQUEST_MAPPING_PAGE = "/cidade";

    @Autowired
    private CidadeService cidadeService;

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Cidade>> carregarAplicacao(PaggableSelect paggable) {

        List<Cidade> cidades = cidadeService.findByPaggebleSelect(paggable);

        if (cidades.isEmpty()) {

            return new ResponseEntity<List<Cidade>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Cidade>>(cidades, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarPorId", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Cidade> carregarPorId(Long cidadeId) {

        if (cidadeId != null) {

            Optional<Cidade> cidade = cidadeService.findById(cidadeId);

            if (!cidade.isPresent()) {

                return new ResponseEntity<Cidade>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<Cidade>(cidade.get(), HttpStatus.OK);
        }
        
        return new ResponseEntity<Cidade>(HttpStatus.NO_CONTENT);
    }
    
    @RequestMapping(value = "/carregarPorBase", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Cidade>> carregarCidade(Long baseId) {

        List<Cidade> cidades = cidadeService.findByBase(baseId);

        if (cidades.isEmpty()) {

            return new ResponseEntity<List<Cidade>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Cidade>>(cidades, HttpStatus.OK);
    }

}
