package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class DetalhesIndisponibilidadeDiariaParameterBean implements Serializable {

    private static final long serialVersionUID = -6736845372592709528L;

    private String dia;

    private String tipo;

    private String empresa;

    public DetalhesIndisponibilidadeDiariaParameterBean() {
        // Construtor padrão
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

}
