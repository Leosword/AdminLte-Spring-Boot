package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class DetalhesConsolidadoNegocioBean implements Serializable {

    private static final long serialVersionUID = -7386751794527548407L;

    private String servico;

    private String minutosJaneiro;

    private String minutosFevereiro;

    private String minutosMarco;

    private String minutosAbril;

    private String minutosMaio;

    private String minutosJunho;

    private String minutosJulho;

    private String minutosAgosto;

    private String minutosSetembro;

    private String minutosOutubro;

    private String minutosNovembro;

    private String minutosDezembro;

    private String percentualJaneiro;

    private String percentualFevereiro;

    private String percentualMarco;

    private String percentualAbril;

    private String percentualMaio;

    private String percentualJunho;

    private String percentualJulho;

    private String percentualAgosto;

    private String percentualSetembro;

    private String percentualOutubro;

    private String percentualNovembro;

    private String percentualDezembro;

    public DetalhesConsolidadoNegocioBean() {
        // Construtor padrão
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public String getMinutosJaneiro() {
        return minutosJaneiro;
    }

    public void setMinutosJaneiro(String minutosJaneiro) {
        this.minutosJaneiro = minutosJaneiro;
    }

    public String getMinutosFevereiro() {
        return minutosFevereiro;
    }

    public void setMinutosFevereiro(String minutosFevereiro) {
        this.minutosFevereiro = minutosFevereiro;
    }

    public String getMinutosMarco() {
        return minutosMarco;
    }

    public void setMinutosMarco(String minutosMarco) {
        this.minutosMarco = minutosMarco;
    }

    public String getMinutosAbril() {
        return minutosAbril;
    }

    public void setMinutosAbril(String minutosAbril) {
        this.minutosAbril = minutosAbril;
    }

    public String getMinutosMaio() {
        return minutosMaio;
    }

    public void setMinutosMaio(String minutosMaio) {
        this.minutosMaio = minutosMaio;
    }

    public String getMinutosJunho() {
        return minutosJunho;
    }

    public void setMinutosJunho(String minutosJunho) {
        this.minutosJunho = minutosJunho;
    }

    public String getMinutosJulho() {
        return minutosJulho;
    }

    public void setMinutosJulho(String minutosJulho) {
        this.minutosJulho = minutosJulho;
    }

    public String getMinutosAgosto() {
        return minutosAgosto;
    }

    public void setMinutosAgosto(String minutosAgosto) {
        this.minutosAgosto = minutosAgosto;
    }

    public String getMinutosSetembro() {
        return minutosSetembro;
    }

    public void setMinutosSetembro(String minutosSetembro) {
        this.minutosSetembro = minutosSetembro;
    }

    public String getMinutosOutubro() {
        return minutosOutubro;
    }

    public void setMinutosOutubro(String minutosOutubro) {
        this.minutosOutubro = minutosOutubro;
    }

    public String getMinutosNovembro() {
        return minutosNovembro;
    }

    public void setMinutosNovembro(String minutosNovembro) {
        this.minutosNovembro = minutosNovembro;
    }

    public String getMinutosDezembro() {
        return minutosDezembro;
    }

    public void setMinutosDezembro(String minutosDezembro) {
        this.minutosDezembro = minutosDezembro;
    }

    public String getPercentualJaneiro() {
        return percentualJaneiro;
    }

    public void setPercentualJaneiro(String percentualJaneiro) {
        this.percentualJaneiro = percentualJaneiro;
    }

    public String getPercentualFevereiro() {
        return percentualFevereiro;
    }

    public void setPercentualFevereiro(String percentualFevereiro) {
        this.percentualFevereiro = percentualFevereiro;
    }

    public String getPercentualMarco() {
        return percentualMarco;
    }

    public void setPercentualMarco(String percentualMarco) {
        this.percentualMarco = percentualMarco;
    }

    public String getPercentualAbril() {
        return percentualAbril;
    }

    public void setPercentualAbril(String percentualAbril) {
        this.percentualAbril = percentualAbril;
    }

    public String getPercentualMaio() {
        return percentualMaio;
    }

    public void setPercentualMaio(String percentualMaio) {
        this.percentualMaio = percentualMaio;
    }

    public String getPercentualJunho() {
        return percentualJunho;
    }

    public void setPercentualJunho(String percentualJunho) {
        this.percentualJunho = percentualJunho;
    }

    public String getPercentualJulho() {
        return percentualJulho;
    }

    public void setPercentualJulho(String percentualJulho) {
        this.percentualJulho = percentualJulho;
    }

    public String getPercentualAgosto() {
        return percentualAgosto;
    }

    public void setPercentualAgosto(String percentualAgosto) {
        this.percentualAgosto = percentualAgosto;
    }

    public String getPercentualSetembro() {
        return percentualSetembro;
    }

    public void setPercentualSetembro(String percentualSetembro) {
        this.percentualSetembro = percentualSetembro;
    }

    public String getPercentualOutubro() {
        return percentualOutubro;
    }

    public void setPercentualOutubro(String percentualOutubro) {
        this.percentualOutubro = percentualOutubro;
    }

    public String getPercentualNovembro() {
        return percentualNovembro;
    }

    public void setPercentualNovembro(String percentualNovembro) {
        this.percentualNovembro = percentualNovembro;
    }

    public String getPercentualDezembro() {
        return percentualDezembro;
    }

    public void setPercentualDezembro(String percentualDezembro) {
        this.percentualDezembro = percentualDezembro;
    }

}
