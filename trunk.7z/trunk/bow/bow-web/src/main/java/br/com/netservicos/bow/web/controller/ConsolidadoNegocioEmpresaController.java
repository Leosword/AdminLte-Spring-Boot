package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.Servico;
import br.com.netservicos.bow.model.ServicoAplicacao;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.EmpresaService;
import br.com.netservicos.bow.service.IndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.ParametroService;
import br.com.netservicos.bow.service.ServicoAplicacaoService;
import br.com.netservicos.bow.service.ServicoService;
import br.com.netservicos.bow.service.TipoAplicacaoService;
import br.com.netservicos.bow.web.bean.ConsolidadoNegocioEmpresaBean;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;
import br.com.netservicos.bow.web.enums.AdicionaConsolidadoNegocioServico;
import br.com.netservicos.bow.web.enums.Meses;

@RestController
public class ConsolidadoNegocioEmpresaController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConsolidadoNegocioEmpresaController.class);

    private static final String REDIRECT_PAGE_CARREGAR = "/negocio/consolidado-empresa/carregar";

    private static final String REQUEST_MAPPING_PAGE_CONSOLIDADO = "consolidadonegocios/pesquisarconsolidadonegocioempresa";

    @Autowired
    private ServicoService service;

    @Autowired
    private ServicoAplicacaoService servicoAplicacaoService;

    @Autowired
    private IndisponibilidadeAplicacaoMensalService indisponibilidadeAplicacaoMensalService;

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    @Autowired
    private ParametroService parametroService;

    @Autowired
    private TipoAplicacaoService tipoAplicacaoService;

    @Autowired
    private EmpresaService empresaService;

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    @RequestMapping(value = "/negocio/empresa/{empresa}", method = RequestMethod.GET)
    public ModelAndView showPesquisarSistemaDetail(Model model, @PathVariable String empresa) {

        Parametro parametroSla = parametroService.findByNome(ParametroConstants.VALOR_SLA);

        Parametro parametroBH = parametroService.findByNome(ParametroConstants.BUSINESS_HOURS);

        LocalDate localDate = LocalDate.now();

        int ano = localDate.getYear();

        Month month = localDate.getMonth();

        BigDecimal totalMinutos = calculaIndisponibilidadeService.calculaMinutosBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        BigDecimal totalPercentual = calculaIndisponibilidadeService.calculaPercentualBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        model.addAttribute("sla_minutos", totalMinutos);

        model.addAttribute("sla_percentual", totalPercentual);

        model.addAttribute("empresa", empresa);

        model.addAttribute("ano", ano);

        model.addAttribute("mes", Meses.getObject(localDate.getMonthValue()).getExtension());

        return new ModelAndView(REQUEST_MAPPING_PAGE_CONSOLIDADO);
    }

    @RequestMapping(value = ConsolidadoNegocioEmpresaController.REDIRECT_PAGE_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ConsolidadoNegocioEmpresaBean>> carregar(IndisponibilidadeQueryParameterBean parameter) {

        LOGGER.debug("Carregando os consolidados de negocio");

        Optional<TipoAplicacao> tipoAplicacao = tipoAplicacaoService.findByAtivo(parameter.getTipoAplicacao());

        if (!tipoAplicacao.isPresent()) {

            LOGGER.error("Não foi possível localizar o tipo com nome: {}", parameter.getTipoAplicacao());

            return new ResponseEntity<List<ConsolidadoNegocioEmpresaBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        IdentificadorEmpresa identificador = IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(parameter.getEmpresa()));

        Optional<Empresa> empresa = empresaService.findByIdentificador(identificador);

        if (!empresa.isPresent()) {

            LOGGER.error("Não foi possível localizar empresa com Identificador: {}", parameter.getEmpresa());

            return new ResponseEntity<List<ConsolidadoNegocioEmpresaBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<ConsolidadoNegocioEmpresaBean> consolidados = adicionaConsolidado(tipoAplicacao, empresa);

        ConsolidadoNegocioEmpresaBean consolidado = adicionaConsolidadoGeral(tipoAplicacao, empresa);

        consolidados.add(consolidado);

        return new ResponseEntity<List<ConsolidadoNegocioEmpresaBean>>(consolidados, HttpStatus.OK);
    }

    private ConsolidadoNegocioEmpresaBean adicionaConsolidadoGeral(Optional<TipoAplicacao> tipoAplicacao, Optional<Empresa> empresa) {

        List<Servico> servicos = service.findAllAtivas();

        LocalDate atual = LocalDate.now();

        Integer ano = atual.getYear();

        Integer mes = atual.getMonthValue();

        ConsolidadoNegocioEmpresaBean bean = new ConsolidadoNegocioEmpresaBean();

        servicos.forEach(servico -> {

            List<ServicoAplicacao> servicosAplicacao = servicoAplicacaoService.findByEmpresa(empresa.get(), servico);

            List<Aplicacao> aplicacoes = servicosAplicacao.stream().map(servicoAplicacao -> servicoAplicacao.getAplicacao())
                    .filter(aplicacao -> tipoAplicacao.get().equals(aplicacao.getTipo())).distinct().collect(Collectors.toList());

            List<IndisponibilidadeAplicacaoMensal> indisponibilidades = indisponibilidadeAplicacaoMensalService.findByPeriodo(ano, mes, aplicacoes);

            if (!CollectionUtil.isEmpty(indisponibilidades)) {

                BigDecimal minutos = indisponibilidades.stream().map(indisponibilidade -> indisponibilidade.getTotalMinutos()).reduce(BigDecimal.ZERO,
                        BigDecimal::add);

                BigDecimal percentuais = indisponibilidades.stream().map(indisponibilidade -> indisponibilidade.getPercentualBase())
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                BigDecimal minutosAplicacao = minutos.divide(new BigDecimal(aplicacoes.size()), MathContext.DECIMAL32)
                        .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

                BigDecimal percentualAplicacao = percentuais.divide(new BigDecimal(aplicacoes.size()), MathContext.DECIMAL32)
                        .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

                MinutosIndisponibilidade minutosIndisponibilidade = new MinutosIndisponibilidade(converter.convert(minutosAplicacao),
                        percentualAplicacao);

                AdicionaConsolidadoNegocioServico.getObject(servico.getNome().toUpperCase()).adiciona(minutosIndisponibilidade, bean);
            }

        });

        return bean;
    }

    private List<ConsolidadoNegocioEmpresaBean> adicionaConsolidado(Optional<TipoAplicacao> tipoAplicacao, Optional<Empresa> empresa) {

        LocalDate atual = LocalDate.now();

        Integer ano = atual.getYear();

        Integer mes = atual.getMonthValue();

        List<ConsolidadoNegocioEmpresaBean> consolidados = new ArrayList<>();

        List<ServicoAplicacao> servicosAplicacao = servicoAplicacaoService.findByEmpresa(empresa.get());

        List<Aplicacao> aplicacoes = servicosAplicacao.stream().map(servicoAplicacao -> servicoAplicacao.getAplicacao())
                .filter(aplicacao -> tipoAplicacao.get().equals(aplicacao.getTipo())).distinct().collect(Collectors.toList());

        aplicacoes.forEach(aplicacao -> {

            ConsolidadoNegocioEmpresaBean bean = new ConsolidadoNegocioEmpresaBean();

            bean.setAplicacao(aplicacao.getDescricao());

            List<Servico> servicos = servicosAplicacao.stream().filter(servicoAplicacao -> aplicacao.equals(servicoAplicacao.getAplicacao()))
                    .map(servicoAplicacao -> servicoAplicacao.getServico()).distinct().collect(Collectors.toList());

            servicos.stream().forEach(servico -> {

                List<IndisponibilidadeAplicacaoMensal> indisponibilidades = indisponibilidadeAplicacaoMensalService.findByPeriodoAplicacao(ano, mes,
                        aplicacao);

                if (!CollectionUtil.isEmpty(indisponibilidades)) {

                    BigDecimal minutos = indisponibilidades.stream().map(indisponibilidade -> indisponibilidade.getTotalMinutos())
                            .reduce(BigDecimal.ZERO, BigDecimal::add);

                    BigDecimal percentuais = indisponibilidades.stream().map(indisponibilidade -> indisponibilidade.getPercentualBase())
                            .reduce(BigDecimal.ZERO, BigDecimal::add);

                    MinutosIndisponibilidade minutosIndisponibilidade = new MinutosIndisponibilidade(converter.convert(minutos), percentuais);

                    AdicionaConsolidadoNegocioServico.getObject(servico.getNome().toUpperCase()).adiciona(minutosIndisponibilidade, bean);
                }

            });

            consolidados.add(bean);
        });

        return consolidados;
    }

}
