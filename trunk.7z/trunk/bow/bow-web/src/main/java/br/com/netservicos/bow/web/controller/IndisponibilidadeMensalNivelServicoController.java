package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Multimap;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.DateUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.common.util.ResourceUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.enums.TipoNivelServico;
import br.com.netservicos.bow.service.AplicacaoBookService;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.IndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.ParametroService;
import br.com.netservicos.bow.service.collector.MultimapCollector;
import br.com.netservicos.bow.web.bean.IndisponibilidadeAplicacaoMensalBean;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;
import br.com.netservicos.bow.web.enums.AdicionaIndisponibilidadeMensal;

@RestController
public class IndisponibilidadeMensalNivelServicoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeMensalNivelServicoController.class);

    private static final List<Integer> MESES = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL_SISTEMA = "indisponibilidade/pesquisarindisponibilidadenivelservico";

    private static final String EMPTY_VALUE = "";

    private static final String REQUEST_MAPPING_CARREGAR_MENSAL = "/indisponibilidade-mensal/carregar-nivelservico";

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    @Autowired
    private AplicacaoBookService aplicacaoBookService;

    @Autowired
    private IndisponibilidadeAplicacaoMensalService service;

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    @Autowired
    private ParametroService parametroService;

    @RequestMapping(value = "/indisponibilidade-mensal/pesquisar/sla/{servico}", method = RequestMethod.GET)
    public ModelAndView show(Model model, @PathVariable Integer servico) {

        Parametro parametroSla = parametroService.findByNome(ParametroConstants.VALOR_SLA);

        Parametro parametroBH = parametroService.findByNome(ParametroConstants.BUSINESS_HOURS);

        LocalDate localDate = LocalDate.now();

        int ano = localDate.getYear();

        Month month = localDate.getMonth();

        BigDecimal totalMinutos = calculaIndisponibilidadeService.calculaMinutosBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        BigDecimal totalPercentual = calculaIndisponibilidadeService.calculaPercentualBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        model.addAttribute("sla_minutos", totalMinutos);

        model.addAttribute("sla_percentual", totalPercentual);

        model.addAttribute("servico", servico);

        model.addAttribute("empresa", EMPTY_VALUE);

        model.addAttribute("tipoAplicacao", EMPTY_VALUE);

        String description = TipoNivelServico.getTipoNivelServico(servico).getDescription();

        String mensagem = ResourceUtil.getMensagem(description);

        model.addAttribute("nomeempresa", mensagem);

        model.addAttribute("ano", ano);

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR_MENSAL_SISTEMA);
    }

    @RequestMapping(value = REQUEST_MAPPING_CARREGAR_MENSAL, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>> carregar(IndisponibilidadeQueryParameterBean parameter) {

        TipoNivelServico nivelServico = TipoNivelServico.getTipoNivelServico(parameter.getTipo());

        List<AplicacaoBook> aplicacoesBook = aplicacaoBookService.findFetchAllByTipoComSla(nivelServico);

        if (CollectionUtil.isEmpty(aplicacoesBook)) {

            LOGGER.error("Não foi possível localizar as aplicações que compõe o book");

            return new ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<IndisponibilidadeAplicacaoMensalBean> indisponibilidades = carregarIndisponibilidade(aplicacoesBook);

        return new ResponseEntity<List<IndisponibilidadeAplicacaoMensalBean>>(indisponibilidades, HttpStatus.OK);
    }

    private List<IndisponibilidadeAplicacaoMensalBean> carregarIndisponibilidade(List<AplicacaoBook> aplicacoesBook) {

        List<Aplicacao> aplicacoes = aplicacoesBook.stream().map(AplicacaoBook::getAplicacao).collect(Collectors.toList());

        List<IndisponibilidadeAplicacaoMensal> indisponibilidadesMensais = service.findByAno(DateUtil.getYear(new Date()), aplicacoes);

        List<IndisponibilidadeAplicacaoMensalBean> indisponibilidades = new ArrayList<>();

        try {

            final Integer ano = DateUtil.getYear(new Date());

            Multimap<Empresa, Aplicacao> empresas = aplicacoes.stream().collect(MultimapCollector.toMultimap(Aplicacao::getEmpresa));

            int totalEmpresa = empresas.asMap().keySet().size();

            empresas.asMap().keySet().forEach(empresa -> {

                Collection<Aplicacao> aplicacoesPorEmpresa = empresas.get(empresa);

                aplicacoesPorEmpresa.forEach(new Consumer<Aplicacao>() {

                    @Override
                    public void accept(Aplicacao aplicacao) {

                        IndisponibilidadeAplicacaoMensalBean bean = new IndisponibilidadeAplicacaoMensalBean();

                        if (totalEmpresa > NumberUtil.INTEGER_ONE) {

                            bean.setAplicacao(String.join(" - ", aplicacao.getDescricao(), empresa.getDescricao()));

                        } else {

                            bean.setAplicacao(aplicacao.getDescricao());
                        }

                        List<IndisponibilidadeAplicacaoMensal> indisponibilidadesPorAplicacao = indisponibilidadesMensais.stream()
                                .filter(indisponibilidade -> indisponibilidade.getAplicacao().equals(aplicacao)).collect(Collectors.toList());

                        MESES.forEach(mes -> {

                            LocalDate periodo = LocalDate.of(ano, mes, NumberUtil.INTEGER_ONE);

                            Optional<IndisponibilidadeAplicacaoMensal> indisponibilidadeMensal = service
                                    .filterByPeriodo(indisponibilidadesPorAplicacao, periodo);

                            if (indisponibilidadeMensal.isPresent()) {

                                AdicionaIndisponibilidadeMensal.getObject(mes).adiciona(indisponibilidadeMensal.get(), bean);
                            }

                        });

                        String consolidado = calculaIndisponibilidadeService.calculaMediaMinutos(indisponibilidadesPorAplicacao);

                        String consolidadoPercentual = calculaIndisponibilidadeService.calculaMediaPercentual(indisponibilidadesPorAplicacao);

                        bean.setConsolidadoMinutosMensal(consolidado);

                        bean.setConsolidadoPercentualMensal(consolidadoPercentual);

                        indisponibilidades.add(bean);
                    }
                });

                if (totalEmpresa > NumberUtil.INTEGER_ONE) {

                    IndisponibilidadeAplicacaoMensalBean indisponbilidadePorEmpresa = adicionaIndisponibilidadePorEmpresa(indisponibilidadesMensais,
                            ano, empresa, aplicacoesPorEmpresa);

                    indisponibilidades.add(indisponbilidadePorEmpresa);
                }

            });

            IndisponibilidadeAplicacaoMensalBean indisponbilidadeGeral = createIndisponibilidadeGeral(ano, aplicacoesBook, indisponibilidadesMensais);

            indisponibilidades.add(indisponbilidadeGeral);

        } catch (Exception ex) {

            LOGGER.error("Error ao carregar as indisponibilidades por aplicação: {}", ex);
        }

        return indisponibilidades;
    }

    private IndisponibilidadeAplicacaoMensalBean adicionaIndisponibilidadePorEmpresa(List<IndisponibilidadeAplicacaoMensal> indisponibilidadesMensais,
            final Integer ano, Empresa empresa, Collection<Aplicacao> aplicacoesPorEmpresa) {

        List<IndisponibilidadeAplicacaoMensal> indisponibilidadesPorEmpresa = indisponibilidadesMensais.stream()
                .filter(indisponibilidade -> empresa.equals(indisponibilidade.getAplicacao().getEmpresa())).collect(Collectors.toList());

        IndisponibilidadeAplicacaoMensalBean indisponbilidadePorEmpresa = createConsolidadoGeral(indisponibilidadesPorEmpresa, ano,
                aplicacoesPorEmpresa.size());

        return indisponbilidadePorEmpresa;
    }

    private IndisponibilidadeAplicacaoMensalBean createIndisponibilidadeGeral(final Integer ano, List<AplicacaoBook> aplicacoes,
            List<IndisponibilidadeAplicacaoMensal> indisponibilidades) {

        IndisponibilidadeAplicacaoMensalBean indisponbilidadeGeral = createConsolidadoGeral(indisponibilidades, ano, aplicacoes.size());

        int totalEmpresa = aplicacoes.stream().map(aplicacao -> aplicacao.getAplicacao().getEmpresa()).distinct().collect(Collectors.toList()).size();

        if (totalEmpresa > NumberUtil.INTEGER_ONE) {

            List<String> descricoesEmpresa = aplicacoes.stream().map(aplicacao -> aplicacao.getAplicacao().getEmpresa().getDescricao()).distinct()
                    .collect(Collectors.toList());

            indisponbilidadeGeral.setAplicacao(String.join(" - ", descricoesEmpresa));
        }

        return indisponbilidadeGeral;
    }

    private IndisponibilidadeAplicacaoMensalBean createConsolidadoGeral(List<IndisponibilidadeAplicacaoMensal> indisponibilidades, Integer ano,
            Integer total) {

        IndisponibilidadeAplicacaoMensalBean bean = new IndisponibilidadeAplicacaoMensalBean();

        List<BigDecimal> consolidadosMinutos = new ArrayList<>();

        List<BigDecimal> consolidadosPercentuais = new ArrayList<>();

        MESES.forEach(new Consumer<Integer>() {

            @Override
            public void accept(Integer mes) {

                LocalDate periodo = LocalDate.of(ano, mes, NumberUtil.INTEGER_ONE);

                BigDecimal minutos = calculaIndisponibilidadeService.calculaMinutos(indisponibilidades, total, periodo);

                BigDecimal resultadoPercentual = calculaIndisponibilidadeService.calculaPercentual(indisponibilidades, total, periodo);

                consolidadosMinutos.add(minutos);

                consolidadosPercentuais.add(resultadoPercentual);

                IndisponibilidadeAplicacaoMensal indisponibilidadeAplicacaoMensal = new IndisponibilidadeAplicacaoMensal(minutos,
                        resultadoPercentual);

                AdicionaIndisponibilidadeMensal.getObject(mes).adiciona(indisponibilidadeAplicacaoMensal, bean);
            }

        });

        adicionaMinutos(bean, consolidadosMinutos);

        adicionaPercentual(bean, consolidadosPercentuais);

        return bean;
    }

    private void adicionaPercentual(IndisponibilidadeAplicacaoMensalBean bean, List<BigDecimal> consolidadosPercentuais) {

        int divisor = LocalDate.now().getMonthValue();

        BigDecimal consolidadoMensalPercentual = consolidadosPercentuais.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(new BigDecimal(divisor), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        bean.setConsolidadoPercentualMensal(String.valueOf(consolidadoMensalPercentual));
    }

    private void adicionaMinutos(IndisponibilidadeAplicacaoMensalBean bean, List<BigDecimal> consolidadosMinutos) {

        int divisor = LocalDate.now().getMonthValue();

        BigDecimal consolidadoMensalMinutos = consolidadosMinutos.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(new BigDecimal(divisor), MathContext.DECIMAL32).setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

        BigDecimal minutos = converter.convert(consolidadoMensalMinutos);

        bean.setConsolidadoMinutosMensal(String.valueOf(minutos));
    }
}
