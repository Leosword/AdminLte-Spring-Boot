package br.com.netservicos.bow.web.validation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ValidationResponse implements Serializable {

    private static final long serialVersionUID = 854879902734658567L;

    private List<MessageError> fieldErrors = new ArrayList<>();

    private String status;

    public ValidationResponse() {
        // Construtor Padrão
    }

    public ValidationResponse(String status) {
        this.status = status;
    }

    public void addFieldError(String path, String message) {
        MessageError error = new MessageError(path, message);
        fieldErrors.add(error);
    }

    public List<MessageError> getFieldErrors() {
        return fieldErrors;
    }

    public void setFieldErrors(List<MessageError> fieldErrors) {
        this.fieldErrors = fieldErrors;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
