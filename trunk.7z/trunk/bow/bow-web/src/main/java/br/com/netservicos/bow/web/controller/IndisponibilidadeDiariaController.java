package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Multimap;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.DateUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.DashboardConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacao;
import br.com.netservicos.bow.model.TipoIndisponibilidadeEvento;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.service.DashboardConfiguracaoIndisponibilidadeService;
import br.com.netservicos.bow.service.EmpresaService;
import br.com.netservicos.bow.service.IndisponibilidadeAplicacaoService;
import br.com.netservicos.bow.service.collector.MultimapCollector;
import br.com.netservicos.bow.web.bean.DashboardIndisponnibilidadeDiaria;
import br.com.netservicos.bow.web.bean.IndisponibilidadeAplicacaoBean;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;
import br.com.netservicos.bow.web.enums.AdicionaLinhaDashboard;
import br.com.netservicos.bow.web.enums.TipoGraficoIndisponibilidade;

@RestController
@RequestMapping(value = IndisponibilidadeDiariaController.REQUEST_MAPPING_PAGE)
public class IndisponibilidadeDiariaController {

    private static final Logger LOGGER = LoggerFactory.getLogger(IndisponibilidadeDiariaController.class);

    protected static final String REQUEST_MAPPING_PAGE = "/indisponibilidade-diaria";

    private static final String TOTAL = "Total";

    private static final String PARCIAL = "Parcial";

    private static final String FUNCIONAL = "Funcional";

    private static final String PATTERN = "dd/MM/yyyy";

    private static final String REDIRECT_PAGE_PESQUISAR_DIARIA = "/pesquisar/{empresa}/{tipo}";

    private static final String REQUEST_MAPPING_DETALHES = "/carregar-detalhes";

    private static final String REQUEST_MAPPING_CARREGAR = "/carregar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR_DIARIA = "indisponibilidade/pesquisarindisponibilidadediaria";

    private static final String SEPARATOR_DETALHES = ", ";

    private static final String SEPARATOR_DASHBOARD = "_";
    
    private static final String MESSAGES_LOCALE = "/messages_pt_BR.properties";

    @Autowired
    private IndisponibilidadeAplicacaoService service;

    @Autowired
    private DashboardConfiguracaoIndisponibilidadeService dashboardService;

    @Autowired
    private EmpresaService empresaService;

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;
    
    @Autowired
    private MessageSource messageSource;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR_DIARIA, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, @PathVariable String empresa, @PathVariable Integer tipo) {

        model.addAttribute("empresa", empresa);

        model.addAttribute("tipo", tipo);

        model.addAttribute("descricaoTipo", TipoGraficoIndisponibilidade.getTipoGraficoIndisponibilidade(tipo).getLabel());

        model.addAttribute("nomeempresa", IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(empresa)).getDescription());

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR_DIARIA);
    }

    @RequestMapping(value = REQUEST_MAPPING_CARREGAR, method = RequestMethod.GET)
    public ResponseEntity<DashboardIndisponnibilidadeDiaria> carregar(IndisponibilidadeQueryParameterBean parameter) {

        LocalDate atual = LocalDate.now();

        LocalDate ultimo = atual.withDayOfMonth(atual.lengthOfMonth());

        LocalDate primeiro = ultimo.withDayOfMonth(NumberUtil.INTEGER_ONE);

        Date inicio = Date.from(primeiro.atStartOfDay(ZoneId.systemDefault()).toInstant());

        Date fim = Date.from(ultimo.atStartOfDay(ZoneId.systemDefault()).toInstant());

        LOGGER.debug("Pesquisando a indisponbilidade para o período: {}", inicio, fim);

        List<IndisponibilidadeAplicacao> indisponibilidades = service.findByPeriodo(inicio, fim, parameter.getEmpresa());

        DashboardIndisponnibilidadeDiaria values = createIndisponibilidade(ultimo, primeiro, indisponibilidades, parameter.getEmpresa(),
                parameter.getTipo());

        return new ResponseEntity<DashboardIndisponnibilidadeDiaria>(values, HttpStatus.OK);
    }

    @RequestMapping(value = REQUEST_MAPPING_DETALHES, method = RequestMethod.GET)
    public ResponseEntity<List<IndisponibilidadeAplicacaoBean>> detalhes(IndisponibilidadeQueryParameterBean parameter) {

        LocalDate atual = LocalDate.now();

        LocalDate ultimo = atual.withDayOfMonth(atual.lengthOfMonth());

        LocalDate primeiro = ultimo.withDayOfMonth(NumberUtil.INTEGER_ONE);

        Date inicio = Date.from(primeiro.atStartOfDay(ZoneId.systemDefault()).toInstant());

        Date fim = Date.from(ultimo.atStartOfDay(ZoneId.systemDefault()).toInstant());

        LOGGER.debug("Pesquisando a indisponbilidade para o período: {}", inicio, fim);

        List<IndisponibilidadeAplicacao> indisponibilidades = service.findByPeriodo(inicio, fim, parameter.getEmpresa());

        List<IndisponibilidadeAplicacaoBean> detalhes = new ArrayList<>();

        Multimap<TipoIndisponibilidadeEvento, IndisponibilidadeAplicacao> tiposIndisponibilidade = indisponibilidades.stream()
                .collect(MultimapCollector.toMultimap(IndisponibilidadeAplicacao::getTipoIndisponbilidade));

        tiposIndisponibilidade.asMap().keySet().iterator().forEachRemaining(tipo -> {

            Collection<IndisponibilidadeAplicacao> indisponibilidadesTipo = tiposIndisponibilidade.get(tipo);

            Multimap<Date, IndisponibilidadeAplicacao> indisponibilidadesDiaria = indisponibilidadesTipo.stream()
                    .collect(MultimapCollector.toMultimap(IndisponibilidadeAplicacao::getInicio));

            indisponibilidadesDiaria.asMap().keySet().iterator().forEachRemaining(dia -> {

                Collection<IndisponibilidadeAplicacao> indisponibilidadesAplicacoes = indisponibilidadesDiaria.get(dia);

                Set<String> aplicacoesValidas = indisponibilidadesAplicacoes.stream().map(IndisponibilidadeAplicacao::getAplicacao)
                        .map(Aplicacao::getDescricao).collect(Collectors.toSet());

                BigDecimal totalMinutos = indisponibilidadesAplicacoes.stream().map(indisponibilidade -> indisponibilidade.getTotalMinutos())
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                String descricoes = String.join(SEPARATOR_DETALHES, aplicacoesValidas);

                SimpleDateFormat sdf = new SimpleDateFormat(PATTERN);

                detalhes.add(new IndisponibilidadeAplicacaoBean(totalMinutos, descricoes, sdf.format(dia), tipo.getDescricao()));
            });
        });

        return new ResponseEntity<List<IndisponibilidadeAplicacaoBean>>(detalhes, HttpStatus.OK);
    }

    private DashboardIndisponnibilidadeDiaria createIndisponibilidade(LocalDate ultimo, LocalDate primeiro,
            List<IndisponibilidadeAplicacao> indisponibilidades, String identificador, Integer tipo) {

        DashboardIndisponnibilidadeDiaria dashboard = new DashboardIndisponnibilidadeDiaria("Total", "Parcial", "Funcional");

        List<IndisponibilidadeAplicacaoBean> indisponibilidadeAplicacoes = new ArrayList<>();

        List<String> dias = Stream.iterate(primeiro, date -> date.plusDays(NumberUtil.INTEGER_ONE))
                .limit(ChronoUnit.DAYS.between(primeiro, ultimo) + NumberUtil.INTEGER_ONE)
                .map(date -> DateTimeFormatter.ofPattern(PATTERN).format(date)).collect(Collectors.toList());

        Optional<Empresa> empresa = empresaService.findByIdentificador(IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(identificador)));

        if (!empresa.isPresent()) {

            LOGGER.error("Não foi possível localizar a empresa com o Id: {}", identificador);

            throw new BusinessException("Não foi possível localizar a empresa");
        }

        dias.forEach(new Consumer<String>() {

            @Override
            public void accept(String dia) {

                List<IndisponibilidadeAplicacao> indisponbilidadesPorDia = indisponibilidades.stream()
                        .filter(indisponibilidade -> new SimpleDateFormat(PATTERN).format(indisponibilidade.getInicio()).equals(dia))
                        .collect(Collectors.toList());

                if (!CollectionUtil.isEmpty(indisponbilidadesPorDia)) {

                    BigDecimal total = service.findByTipo(indisponbilidadesPorDia, TOTAL);

                    BigDecimal minutosTotal = converter.convert(total);

                    BigDecimal parcial = service.findByTipo(indisponbilidadesPorDia, PARCIAL);

                    BigDecimal minutosParcial = converter.convert(parcial);

                    BigDecimal funcional = service.findByTipo(indisponbilidadesPorDia, FUNCIONAL);

                    BigDecimal minutosFuncional = converter.convert(funcional);

                    IndisponibilidadeAplicacaoBean bean = new IndisponibilidadeAplicacaoBean(minutosTotal, minutosParcial, minutosFuncional, dia);

                    adicionaLinhaGrafico(tipo, empresa, dia, bean, dashboard);

                    indisponibilidadeAplicacoes.add(bean);

                } else {

                    IndisponibilidadeAplicacaoBean bean = new IndisponibilidadeAplicacaoBean(dia);

                    adicionaLinhaGrafico(tipo, empresa, dia, bean, dashboard);

                    indisponibilidadeAplicacoes.add(bean);
                }
            }

        });

        dashboard.setValues(indisponibilidadeAplicacoes);

        return dashboard;
    }

    private void adicionaLinhaGrafico(Integer tipo, Optional<Empresa> empresa, String dia, IndisponibilidadeAplicacaoBean bean,
            DashboardIndisponnibilidadeDiaria dashboardIndisponnibilidadeDiaria) {
        Empresa unidadeNegocio = empresa.get();

        List<DashboardConfiguracaoIndisponibilidade> configuracoes = dashboardService.findByEmpresa(unidadeNegocio, DateUtil.getDate(dia, PATTERN));

        TipoGraficoIndisponibilidade tipoGrafico = TipoGraficoIndisponibilidade.getTipoGraficoIndisponibilidade(tipo);

        String composite = String.join(SEPARATOR_DASHBOARD, unidadeNegocio.getIdentificador().name(), tipoGrafico.name());

        AdicionaLinhaDashboard tpGrafico = AdicionaLinhaDashboard.getObject(composite);
        tpGrafico.adiciona(configuracoes, bean);
        
        Locale localeValue = new Locale(MESSAGES_LOCALE);

        if (AdicionaLinhaDashboard.NET_TI_CONTACT_RATE.equals(tpGrafico)) {
            dashboardIndisponnibilidadeDiaria.setLabelLinha(messageSource.getMessage("bow_tipo_configuracao_rechamada", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setLabelSupport(messageSource.getMessage("bow_tipo_configuracao_quantidade_ligacao", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setSomenteUmaLinha(false);
        } else if(AdicionaLinhaDashboard.NET_TI_VENDAS.equals(tpGrafico)){
            dashboardIndisponnibilidadeDiaria.setLabelLinha(messageSource.getMessage("bow_tipo_configuracao_venda_bruta", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setSomenteUmaLinha(true);
        } else if(AdicionaLinhaDashboard.NET_TI_VISITA_TECNICA.equals(tpGrafico)){
            dashboardIndisponnibilidadeDiaria.setLabelLinha(messageSource.getMessage("bow_tipo_configuracao_visita_produtiva", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setLabelSupport(messageSource.getMessage("bow_tipo_configuracao_visita_improdutiva", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setSomenteUmaLinha(false);
        } else if(AdicionaLinhaDashboard.CLARO_MOVEL_TI_CONTACT_RATE.equals(tpGrafico)){
            dashboardIndisponnibilidadeDiaria.setLabelLinha(messageSource.getMessage("bow_tipo_configuracao_volume_ligacao", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setSomenteUmaLinha(true);
        } else if(AdicionaLinhaDashboard.CLARO_MOVEL_TI_VENDAS.equals(tpGrafico)){
            dashboardIndisponnibilidadeDiaria.setLabelLinha(messageSource.getMessage("bow_tipo_configuracao_ativacao_bruta", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setSomenteUmaLinha(true);
        } else if(AdicionaLinhaDashboard.CLARO_HDTV_TI_CONTACT_RATE.equals(tpGrafico)){
            dashboardIndisponnibilidadeDiaria.setLabelLinha(messageSource.getMessage("bow_tipo_configuracao_ativacao_bruta", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setSomenteUmaLinha(true);
        } else if(AdicionaLinhaDashboard.CLARO_HDTV_TI_VENDAS.equals(tpGrafico)){
            dashboardIndisponnibilidadeDiaria.setLabelLinha(messageSource.getMessage("bow_tipo_configuracao_venda_bruta", null, localeValue));
            dashboardIndisponnibilidadeDiaria.setSomenteUmaLinha(true);
        }else if(AdicionaLinhaDashboard.EMBRATEL_TI_CONTACT_RATE.equals(tpGrafico)){            
            dashboardIndisponnibilidadeDiaria.setSemLinha(true);
        }
    }

}