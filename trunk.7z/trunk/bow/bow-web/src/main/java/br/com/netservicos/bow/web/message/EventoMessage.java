package br.com.netservicos.bow.web.message;

import java.io.Serializable;
import java.util.Date;

import br.com.netservicos.bow.model.enums.SituacaoEvento;

public class EventoMessage implements Serializable {

    private static final long serialVersionUID = -503300434176877568L;

    private Long eventoId;

    private SituacaoEvento sitaucao;

    private Integer situacaoEvento;

    private Boolean eventoPai;

    private Date criacao;

    public EventoMessage() {

        criacao = new Date();
    }

    public Long getEventoId() {
        return eventoId;
    }

    public void setEventoId(Long eventoId) {
        this.eventoId = eventoId;
    }

    public SituacaoEvento getSitaucao() {
        return sitaucao;
    }

    public void setSitaucao(SituacaoEvento sitaucao) {
        this.sitaucao = sitaucao;
    }

    public Integer getSituacaoEvento() {
        return situacaoEvento;
    }

    public void setSituacaoEvento(Integer situacaoEvento) {
        this.situacaoEvento = situacaoEvento;
    }

    public Boolean getEventoPai() {
        return eventoPai;
    }

    public void setEventoPai(Boolean eventoPai) {
        this.eventoPai = eventoPai;
    }

    public Date getCriacao() {
        return criacao;
    }

    public void setCriacao(Date criacao) {
        this.criacao = criacao;
    }

}
