package br.com.netservicos.bow.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

@Controller(value = "loginController")
// @RequestMapping(value = LoginController.REQUEST_MAPPING_PAGE)
public class LoginController {

    protected static final String REQUEST_MAPPING_PAGE = "/login";

    protected static final String REDIRECT_PAGE = "login";

    // @RequestMapping(value = { "/", LoginController.REQUEST_MAPPING_PAGE },
    // method = RequestMethod.GET)
    public ModelAndView home() {

        ModelAndView model = new ModelAndView();

        model.setViewName(LoginController.REDIRECT_PAGE);

        return model;
    }

}
