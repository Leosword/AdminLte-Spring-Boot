package br.com.netservicos.bow.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController(value = "homeController")
public class HomeController {

    private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

    protected static final String REQUEST_MAPPING_PAGE = "/dashboard**";

    protected static final String REQUEST_MAPPING_LOGIN_PAGE = "/login";

    protected static final String REDIRECT_PAGE = "dashboard";

    protected static final String REDIRECT_LOGIN_PAGE = "login";

    @RequestMapping(value = { "/", "/dashboard**" }, method = RequestMethod.GET)
    public ModelAndView dashboard() {

        LOGGER.debug("Iniciando o dashboard");

        ModelAndView model = new ModelAndView();

        model.setViewName(HomeController.REDIRECT_PAGE);

        return model;
    }

    @RequestMapping(value = "/403", method = RequestMethod.GET)
    public ModelAndView accesssDenied() {

        ModelAndView model = new ModelAndView();

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (!(auth instanceof AnonymousAuthenticationToken)) {

            UserDetails userDetail = (UserDetails) auth.getPrincipal();

            model.addObject("username", userDetail.getUsername());
        }

        model.setViewName("error/error403");

        return model;
    }

    @RequestMapping(value = { HomeController.REQUEST_MAPPING_LOGIN_PAGE }, method = RequestMethod.GET)
    public ModelAndView login() {

        ModelAndView model = new ModelAndView();

        model.setViewName(HomeController.REDIRECT_LOGIN_PAGE);

        return model;
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public ModelAndView logoutPage(HttpServletRequest request, HttpServletResponse response) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null) {

            new SecurityContextLogoutHandler().logout(request, response, auth);
        }

        LOGGER.info("Executando o redirect");

        return new ModelAndView("redirect:login?logout");
    }

}
