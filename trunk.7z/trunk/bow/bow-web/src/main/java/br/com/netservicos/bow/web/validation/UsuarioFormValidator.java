package br.com.netservicos.bow.web.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.google.common.base.Strings;

import br.com.netservicos.bow.web.bean.UsuarioBean;

@Component
public class UsuarioFormValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return UsuarioBean.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {

        UsuarioBean usuarioBean = (UsuarioBean) target;

        if (usuarioBean.getId() == null) {

            if (Strings.isNullOrEmpty(usuarioBean.getSenha())) {
                errors.rejectValue("senha", "required", new Object[] { "'senha'" }, "Não pode estar em branco");
            }

            if (Strings.isNullOrEmpty(usuarioBean.getConfirmarSenha())) {
                errors.rejectValue("confirmarSenha", "required", new Object[] { "'confirmarSenha'" }, "Não pode estar em branco");
            }

        }

        if (usuarioBean.getId() != null && usuarioBean.isTrocarSenha()) {

            if (Strings.isNullOrEmpty(usuarioBean.getSenha())) {
                errors.rejectValue("senha", "required", new Object[] { "'senha'" }, "Campo não pode está em branco.");
            }

            if (Strings.isNullOrEmpty(usuarioBean.getConfirmarSenha())) {
                errors.rejectValue("confirmarSenha", "required", new Object[] { "'confirmarSenha'" }, "Campo não pode está em branco.");
            }
        }
    }

}
