package br.com.netservicos.bow.web.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum TipoGraficoIndisponibilidade {

    TI_CONTACT_RATE(1, "bow_menu_ti_negocios"), TI_VENDAS(2, "bow_menu_ti_vendas"), TI_VISITA_TECNICA(3, "bow_menu_ti_visitas");

    protected static final Map<Integer, TipoGraficoIndisponibilidade> values = new HashMap<>();

    static {
        values.putAll(Arrays.asList(values()).stream().collect(Collectors.toMap(TipoGraficoIndisponibilidade::getValue, Function.identity())));
    }

    private Integer value;
    private String label;

    private TipoGraficoIndisponibilidade(Integer value, String label) {
        this.value = value;
        this.label = label;
    }

    public static TipoGraficoIndisponibilidade getTipoGraficoIndisponibilidade(final Integer value) {
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

}
