package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class AplicacaoBookBean implements Serializable {

    private static final long serialVersionUID = 1111126278050215715L;

    private Long id;

    private String aplicacao;

    private String empresa;

    private String tipo;

    private Integer tipoId;

    private Long[] aplicacoesIds;

    private Boolean slaGeral;

    public AplicacaoBookBean() {
        // Construtor padrão
    }

    public AplicacaoBookBean(Long id, String aplicacao, String empresa, String tipo, Boolean slaGeral) {
        this.id = id;
        this.aplicacao = aplicacao;
        this.empresa = empresa;
        this.tipo = tipo;
        this.slaGeral = slaGeral;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getTipoId() {
        return tipoId;
    }

    public void setTipoId(Integer tipoId) {
        this.tipoId = tipoId;
    }

    public Long[] getAplicacoesIds() {
        return aplicacoesIds;
    }

    public void setAplicacoesIds(Long[] aplicacoesIds) {
        this.aplicacoesIds = aplicacoesIds;
    }

    public Boolean getSlaGeral() {
        return slaGeral;
    }

    public void setSlaGeral(Boolean slaGeral) {
        this.slaGeral = slaGeral;
    }

}
