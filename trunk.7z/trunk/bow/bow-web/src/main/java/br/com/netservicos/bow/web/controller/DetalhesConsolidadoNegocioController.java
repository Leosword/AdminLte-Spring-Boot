package br.com.netservicos.bow.web.controller;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.common.constants.ParametroConstants;
import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.NumberUtil;
import br.com.netservicos.bow.converter.ConverterDecimal;
import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.Empresa;
import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.model.MinutosIndisponibilidade;
import br.com.netservicos.bow.model.Parametro;
import br.com.netservicos.bow.model.Servico;
import br.com.netservicos.bow.model.ServicoAplicacao;
import br.com.netservicos.bow.model.TipoAplicacao;
import br.com.netservicos.bow.model.enums.IdentificadorEmpresa;
import br.com.netservicos.bow.service.CalculaIndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.EmpresaService;
import br.com.netservicos.bow.service.IndisponibilidadeAplicacaoMensalService;
import br.com.netservicos.bow.service.ParametroService;
import br.com.netservicos.bow.service.ServicoAplicacaoService;
import br.com.netservicos.bow.service.ServicoService;
import br.com.netservicos.bow.service.TipoAplicacaoService;
import br.com.netservicos.bow.web.bean.DetalhesConsolidadoNegocioBean;
import br.com.netservicos.bow.web.bean.IndisponibilidadeQueryParameterBean;
import br.com.netservicos.bow.web.enums.AdicionaConsolidadoNegocioMensal;

@RestController
public class DetalhesConsolidadoNegocioController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DetalhesConsolidadoNegocioController.class);

    private static final List<Integer> MESES = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);

    private static final String REDIRECT_PAGE_CARREGAR = "/negocio/detalhes-empresa/carregar";

    private static final String REQUEST_MAPPING_PAGE_CONSOLIDADO_DETALHES = "consolidadonegocios/pesquisardetalhesconsolidadonegocio";

    @Autowired
    private ServicoService service;

    @Autowired
    private ServicoAplicacaoService servicoAplicacaoService;

    @Autowired
    private IndisponibilidadeAplicacaoMensalService indisponibilidadeAplicacaoMensalService;

    @Autowired
    private CalculaIndisponibilidadeAplicacaoMensalService calculaIndisponibilidadeService;

    @Autowired
    private ParametroService parametroService;

    @Autowired
    private TipoAplicacaoService tipoAplicacaoService;

    @Autowired
    private EmpresaService empresaService;

    @Autowired
    @Qualifier("converterIndicador")
    private ConverterDecimal converter;

    @RequestMapping(value = "/negocio/detalhes/{tipoAplicacao}", method = RequestMethod.GET)
    public ModelAndView showPesquisarSistemaDetail(Model model, @PathVariable String tipoAplicacao) {

        Parametro parametroSla = parametroService.findByNome(ParametroConstants.VALOR_SLA);

        Parametro parametroBH = parametroService.findByNome(ParametroConstants.BUSINESS_HOURS);

        LocalDate localDate = LocalDate.now();

        int ano = localDate.getYear();

        Month month = localDate.getMonth();

        BigDecimal totalMinutos = calculaIndisponibilidadeService.calculaMinutosBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        BigDecimal totalPercentual = calculaIndisponibilidadeService.calculaPercentualBusinessHours(parametroBH.getValor(), parametroSla.getValor(),
                month.maxLength());

        model.addAttribute("sla_minutos", totalMinutos);

        model.addAttribute("sla_percentual", totalPercentual);

        model.addAttribute("ano", ano);

        model.addAttribute("tipoAplicacao", tipoAplicacao);

        return new ModelAndView(REQUEST_MAPPING_PAGE_CONSOLIDADO_DETALHES);
    }

    @RequestMapping(value = DetalhesConsolidadoNegocioController.REDIRECT_PAGE_CARREGAR, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DetalhesConsolidadoNegocioBean>> carregar(IndisponibilidadeQueryParameterBean parameter) {

        LOGGER.debug("Carregando os consolidados de negocio");

        List<Servico> servicos = service.findAllAtivas();

        if (CollectionUtil.isEmpty(servicos)) {

            LOGGER.error("Não foi possível localizar os serviços cadastrados");

            return new ResponseEntity<List<DetalhesConsolidadoNegocioBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        Optional<TipoAplicacao> tipoAplicacao = tipoAplicacaoService.findByAtivo(parameter.getTipoAplicacao());

        if (!tipoAplicacao.isPresent()) {

            LOGGER.error("Não foi possível localizar o tipo com nome: {}", parameter.getTipoAplicacao());

            return new ResponseEntity<List<DetalhesConsolidadoNegocioBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        IdentificadorEmpresa identificador = IdentificadorEmpresa.getIdentificadorEmpresa(Integer.valueOf(parameter.getEmpresa()));

        Optional<Empresa> empresa = empresaService.findByIdentificador(identificador);

        if (!empresa.isPresent()) {

            LOGGER.error("Não foi possível localizar empresa com Identificador: {}", parameter.getEmpresa());

            return new ResponseEntity<List<DetalhesConsolidadoNegocioBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<DetalhesConsolidadoNegocioBean> consolidados = addConsolidado(servicos, tipoAplicacao, empresa);

        return new ResponseEntity<List<DetalhesConsolidadoNegocioBean>>(consolidados, HttpStatus.OK);
    }

    private List<DetalhesConsolidadoNegocioBean> addConsolidado(List<Servico> servicos, Optional<TipoAplicacao> tipo, Optional<Empresa> empresa) {

        LocalDate atual = LocalDate.now();

        Integer ano = atual.getYear();

        List<DetalhesConsolidadoNegocioBean> consolidados = new ArrayList<>();

        servicos.forEach(servico -> {

            DetalhesConsolidadoNegocioBean bean = new DetalhesConsolidadoNegocioBean();

            bean.setServico(servico.getNome());

            List<ServicoAplicacao> servicosAplicacao = servicoAplicacaoService.findByEmpresa(empresa.get(), servico);

            List<Aplicacao> aplicacoes = servicosAplicacao.stream().map(servicoAplicacao -> servicoAplicacao.getAplicacao())
                    .filter(aplicacao -> tipo.get().equals(aplicacao.getTipo())).distinct().collect(Collectors.toList());

            MESES.forEach(new Consumer<Integer>() {

                @Override
                public void accept(Integer mes) {

                    List<IndisponibilidadeAplicacaoMensal> indisponibilidades = indisponibilidadeAplicacaoMensalService.findByPeriodo(ano, mes,
                            aplicacoes);

                    if (!CollectionUtil.isEmpty(indisponibilidades)) {

                        BigDecimal minutos = indisponibilidades.stream().map(indisponibilidade -> indisponibilidade.getTotalMinutos())
                                .reduce(BigDecimal.ZERO, BigDecimal::add);

                        BigDecimal percentuais = indisponibilidades.stream().map(indisponibilidade -> indisponibilidade.getPercentualBase())
                                .reduce(BigDecimal.ZERO, BigDecimal::add);

                        BigDecimal minutosAplicacao = minutos.divide(new BigDecimal(aplicacoes.size()), MathContext.DECIMAL32)
                                .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

                        BigDecimal percentualAplicacao = percentuais.divide(new BigDecimal(aplicacoes.size()), MathContext.DECIMAL32)
                                .setScale(NumberUtil.INTEGER_TWO, RoundingMode.HALF_EVEN);

                        MinutosIndisponibilidade minutosIndisponibilidade = new MinutosIndisponibilidade(converter.convert(minutosAplicacao),
                                percentualAplicacao);

                        AdicionaConsolidadoNegocioMensal.getObject(mes).adiciona(minutosIndisponibilidade, bean);
                    }
                }
            });

            consolidados.add(bean);
        });

        return consolidados;
    }

}
