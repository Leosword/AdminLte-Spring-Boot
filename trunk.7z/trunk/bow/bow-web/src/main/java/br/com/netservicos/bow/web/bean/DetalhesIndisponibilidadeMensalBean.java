package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class DetalhesIndisponibilidadeMensalBean implements Serializable {

    private static final long serialVersionUID = -4193501059835702077L;

    private String mes;

    private String aplicacao;

    public DetalhesIndisponibilidadeMensalBean() {
        // Construtor padrão
    }

    public DetalhesIndisponibilidadeMensalBean(String mes, String aplicacao) {
        this.mes = mes;
        this.aplicacao = aplicacao;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

}
