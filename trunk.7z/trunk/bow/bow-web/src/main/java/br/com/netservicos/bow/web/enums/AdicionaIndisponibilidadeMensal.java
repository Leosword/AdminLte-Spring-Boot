package br.com.netservicos.bow.web.enums;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import br.com.netservicos.bow.model.IndisponibilidadeAplicacaoMensal;
import br.com.netservicos.bow.web.bean.IndisponibilidadeAplicacaoMensalBean;

public enum AdicionaIndisponibilidadeMensal {

    JANEIRO(1) {
        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosJaneiro(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualJaneiro(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchJaneiro(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchJaneiro(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));

            }
        }
    },
    FEVEREIRO(2) {
        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosFevereiro(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualFevereiro(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchFevereiro(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchFevereiro(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));

            }
        }
    },
    MARCO(3) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosMarco(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualMarco(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchMarco(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchMarco(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));

            }
        }

    },
    ABRIL(4) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosAbril(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualAbril(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchAbril(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchAbril(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));
            }
        }

    },
    MAIO(5) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosMaio(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualMaio(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchMaio(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchMaio(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));

            }
        }
    },
    JUNHO(6) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosJunho(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualJunho(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchJunho(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchJunho(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));

            }
        }
    },
    JULHO(7) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosJulho(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualJulho(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchJulho(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchJulho(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));
            }
        }
    },
    AGOSTO(8) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosAgosto(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualAgosto(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchAgosto(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchAgosto(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));
            }
        }
    },
    SETEMBRO(9) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosSetembro(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualSetembro(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchSetembro(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchSetembro(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));
            }
        }
    },
    OUTUBRO(10) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosOutubro(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualOutubro(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchOutubro(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchOutubro(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));
            }
        }
    },
    NOVEMBRO(11) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosNovembro(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualNovembro(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchNovembro(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchNovembro(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));
            }
        }
    },
    DEZEMBRO(12) {

        @Override
        public void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidade, IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensal) {

            indisponibilidadeMensal.setMinutosDezembro(String.valueOf(indisponibilidade.getTotalMinutos()));

            indisponibilidadeMensal.setPercentualDezembro(String.valueOf(indisponibilidade.getPercentualBase()));

            if (Objects.nonNull(indisponibilidade.getTotalMinutosPosPatch())) {

                indisponibilidadeMensal.setMinutosPosPatchDezembro(String.valueOf(indisponibilidade.getTotalMinutosPosPatch()));

                indisponibilidadeMensal.setPercentualPosPatchDezembro(String.valueOf(indisponibilidade.getPercentualBasePosPatch()));
            }

        }
    };

    protected static final Map<Integer, AdicionaIndisponibilidadeMensal> values = new HashMap<>();

    private Integer value;

    static {

        for (AdicionaIndisponibilidadeMensal situacao : values()) {
            values.put(situacao.value, situacao);
        }
    }

    private AdicionaIndisponibilidadeMensal(Integer value) {
        this.value = value;
    }

    public static final AdicionaIndisponibilidadeMensal getObject(final Integer value) {
        return values.get(value);
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public abstract void adiciona(IndisponibilidadeAplicacaoMensal indisponibilidadeAplicacaoMensal,
            IndisponibilidadeAplicacaoMensalBean indisponibilidadeMensalBean);

}
