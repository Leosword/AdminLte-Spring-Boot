package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.common.util.ResourceUtil;
import br.com.netservicos.bow.exception.BusinessException;
import br.com.netservicos.bow.model.AplicacaoBook;
import br.com.netservicos.bow.model.enums.TipoNivelServico;
import br.com.netservicos.bow.service.AplicacaoBookService;
import br.com.netservicos.bow.web.bean.AplicacaoBookBean;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = AplicacaoBookController.REQUEST_MAPPING_PAGE)
public class AplicacaoBookController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AplicacaoBookController.class);

    private static final String MODEL_NAME = "aplicacaoBookBean";

    private static final String REDIRECT_PAGE_INCLUIR = "/incluir";

    private static final String REDIRECT_PAGE_SALVAR = "/salvar";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR = "aplicacaobook/incluiraplicacaobook";

    private static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "aplicacaobook/pesquisaraplicacaobook";

    protected static final String REQUEST_MAPPING_PAGE = "/aplicacao-book";

    @Autowired
    private AplicacaoBookService aplicacaoBookService;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AplicacaoBookBean>> carregar() {

        LOGGER.debug("Iniciando o carregamento das aplicações que contém base.");

        List<AplicacaoBook> aplicacoes = aplicacaoBookService.findFecthAll();

        if (aplicacoes.isEmpty()) {

            return new ResponseEntity<List<AplicacaoBookBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<AplicacaoBookBean> aplicacoesBookBean = aplicacoes.stream().map(aplicacaoBook -> {

            String description = ResourceUtil.getMensagem(aplicacaoBook.getTipo().getDescription());

            AplicacaoBookBean aplicacaoBookBean = new AplicacaoBookBean(aplicacaoBook.getId(), aplicacaoBook.getAplicacao().getDescricao(),
                    aplicacaoBook.getAplicacao().getEmpresa().getDescricao(), description, aplicacaoBook.getSlaGeral());

            return aplicacaoBookBean;

        }).collect(Collectors.toList());

        return new ResponseEntity<List<AplicacaoBookBean>>(aplicacoesBookBean, HttpStatus.OK);
    }

    @RequestMapping(value = REDIRECT_PAGE_INCLUIR, method = RequestMethod.GET)
    public ModelAndView viewIncluir(ModelMap model, HttpServletRequest request) {

        model.addAttribute(MODEL_NAME, new AplicacaoBookBean());

        model.addAttribute("tipos", TipoNivelServico.values());

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = REDIRECT_PAGE_SALVAR, method = RequestMethod.POST)
    public ResponseEntity<ValidationResponse> salvar(@Valid @RequestBody AplicacaoBookBean aplicacaoBookBean) {

        if (aplicacaoBookBean.getAplicacoesIds() == null) {

            LOGGER.error("Não foi possível as aplicações para processeguir com o processo.");

            return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.PRECONDITION_FAILED);
        }

        aplicacaoBookService.salvar(aplicacaoBookBean.getTipoId(), aplicacaoBookBean.getAplicacoesIds(), aplicacaoBookBean.getSlaGeral());

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @RequestMapping(value = "/remover/{ids}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> deletar(@PathVariable("ids") Long[] ids) {

        LOGGER.debug("Aplicação book a serem removidos: {}", new Object[] { ids });

        aplicacaoBookService.deletar(ids);

        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(BusinessException.class)
    public String handleBusinessExceptionException(BusinessException exception) {

        ModelAndView model = new ModelAndView();

        model.addObject("exception", exception.getMessage());

        model.setViewName(REQUEST_MAPPING_PAGE_INCLUIR);

        return exception.getMessage();
    }

}