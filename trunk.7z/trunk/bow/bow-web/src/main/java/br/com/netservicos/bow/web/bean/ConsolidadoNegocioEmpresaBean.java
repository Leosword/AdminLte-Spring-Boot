package br.com.netservicos.bow.web.bean;

import java.io.Serializable;

public class ConsolidadoNegocioEmpresaBean implements Serializable {

    private static final long serialVersionUID = 5616885261458510426L;

    private String aplicacao;

    private String minutosVender;

    private String percentualVender;

    private String minutosAtivar;

    private String percentualAtivar;

    private String minutosAtender;

    private String percentualAtender;

    private String minutosFaturar;

    private String percentualFaturar;

    private String minutosArrecadar;

    private String percentualArrecadar;

    private String minutosContabilizar;

    private String percentualContabilizar;

    public ConsolidadoNegocioEmpresaBean() {
        // Construtor padrão
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

    public String getMinutosVender() {
        return minutosVender;
    }

    public void setMinutosVender(String minutosVender) {
        this.minutosVender = minutosVender;
    }

    public String getPercentualVender() {
        return percentualVender;
    }

    public void setPercentualVender(String percentualVender) {
        this.percentualVender = percentualVender;
    }

    public String getMinutosAtivar() {
        return minutosAtivar;
    }

    public void setMinutosAtivar(String minutosAtivar) {
        this.minutosAtivar = minutosAtivar;
    }

    public String getPercentualAtivar() {
        return percentualAtivar;
    }

    public void setPercentualAtivar(String percentualAtivar) {
        this.percentualAtivar = percentualAtivar;
    }

    public String getMinutosAtender() {
        return minutosAtender;
    }

    public void setMinutosAtender(String minutosAtender) {
        this.minutosAtender = minutosAtender;
    }

    public String getPercentualAtender() {
        return percentualAtender;
    }

    public void setPercentualAtender(String percentualAtender) {
        this.percentualAtender = percentualAtender;
    }

    public String getMinutosFaturar() {
        return minutosFaturar;
    }

    public void setMinutosFaturar(String minutosFaturar) {
        this.minutosFaturar = minutosFaturar;
    }

    public String getPercentualFaturar() {
        return percentualFaturar;
    }

    public void setPercentualFaturar(String percentualFaturar) {
        this.percentualFaturar = percentualFaturar;
    }

    public String getMinutosArrecadar() {
        return minutosArrecadar;
    }

    public void setMinutosArrecadar(String minutosArrecadar) {
        this.minutosArrecadar = minutosArrecadar;
    }

    public String getPercentualArrecadar() {
        return percentualArrecadar;
    }

    public void setPercentualArrecadar(String percentualArrecadar) {
        this.percentualArrecadar = percentualArrecadar;
    }

    public String getMinutosContabilizar() {
        return minutosContabilizar;
    }

    public void setMinutosContabilizar(String minutosContabilizar) {
        this.minutosContabilizar = minutosContabilizar;
    }

    public String getPercentualContabilizar() {
        return percentualContabilizar;
    }

    public void setPercentualContabilizar(String percentualContabilizar) {
        this.percentualContabilizar = percentualContabilizar;
    }

}
