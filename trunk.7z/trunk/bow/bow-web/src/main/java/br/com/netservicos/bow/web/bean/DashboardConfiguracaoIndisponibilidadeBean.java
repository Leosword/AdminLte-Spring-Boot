package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

public class DashboardConfiguracaoIndisponibilidadeBean implements Serializable {

    private static final long serialVersionUID = -6995037853379517403L;

    private Long id;

    private String empresa;

    private String tipo;

    private Integer tipoId;

    private Long empresaId;

    private Long[] configuracoesIds;

    @NotNull
    private BigDecimal valor;

    private String dia;

    public DashboardConfiguracaoIndisponibilidadeBean() {
        // Construtor padrão
    }

    public DashboardConfiguracaoIndisponibilidadeBean(Long id, String empresa, String tipo, BigDecimal valor, String dia) {
        this.id = id;
        this.empresa = empresa;
        this.tipo = tipo;
        this.valor = valor;
        this.dia = dia;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getTipoId() {
        return tipoId;
    }

    public void setTipoId(Integer tipoId) {
        this.tipoId = tipoId;
    }

    public Long getEmpresaId() {
        return empresaId;
    }

    public void setEmpresaId(Long empresaId) {
        this.empresaId = empresaId;
    }

    public Long[] getConfiguracoesIds() {
        return configuracoesIds;
    }

    public void setConfiguracoesIds(Long[] configuracoesIds) {
        this.configuracoesIds = configuracoesIds;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

}
