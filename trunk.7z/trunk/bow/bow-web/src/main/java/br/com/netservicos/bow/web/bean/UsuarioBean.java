package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;

import br.com.netservicos.bow.model.Usuario;

public class UsuarioBean implements Serializable {

    private static final long serialVersionUID = 5443984920735396331L;

    private Long id;

    @NotBlank
    private String nome;

    @NotBlank
    private String sobrenome;

    @NotBlank
    private String login;

    @NotBlank
    private String telefone;

    @NotBlank
    private String email;

    private String senha;

    private Long version;

    private String confirmarSenha;

    private String nomePerfil;

    private boolean trocarSenha;

    private boolean habilitaCampos;

    public UsuarioBean() {
        // Construtor Padrão
    }

    public UsuarioBean(boolean trocarSenha) {
        this.trocarSenha = trocarSenha;
        this.habilitaCampos = true;
    }

    public UsuarioBean(Long id, String nome, String sobrenome, String login, String telefone, String email, String nomePerfil) {
        this.id = id;
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.login = login;
        this.telefone = telefone;
        this.email = email;
        this.nomePerfil = nomePerfil;
    }

    public UsuarioBean(Long id, String nome, String sobrenome, String login, String telefone, String email, String nomePerfil, Long version) {
        this.id = id;
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.login = login;
        this.telefone = telefone;
        this.email = email;
        this.nomePerfil = nomePerfil;
        this.version = version;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getConfirmarSenha() {
        return confirmarSenha;
    }

    public void setConfirmarSenha(String confirmarSenha) {
        this.confirmarSenha = confirmarSenha;
    }

    public String getNomePerfil() {
        return nomePerfil;
    }

    public void setNomePerfil(String nomePerfil) {
        this.nomePerfil = nomePerfil;
    }

    public boolean isTrocarSenha() {
        return trocarSenha;
    }

    public void setTrocarSenha(boolean trocarSenha) {
        this.trocarSenha = trocarSenha;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public boolean isHabilitaCampos() {
        return habilitaCampos;
    }

    public void setHabilitaCampos(boolean habilitaCampos) {
        this.habilitaCampos = habilitaCampos;
    }

    public static List<UsuarioBean> bindingProperties(List<Usuario> usuarios) {

        List<UsuarioBean> usuariosBean = new ArrayList<>();

        usuarios.forEach(usuario -> {

            UsuarioBean usuarioBean = new UsuarioBean(usuario.getId(), usuario.getNome(), usuario.getSobrenome(), usuario.getLogin(),
                    usuario.getTelefone(), usuario.getEmail(), usuario.getNomePerfil(), usuario.getVersion());

            usuariosBean.add(usuarioBean);
        });

        return usuariosBean;
    }

}
