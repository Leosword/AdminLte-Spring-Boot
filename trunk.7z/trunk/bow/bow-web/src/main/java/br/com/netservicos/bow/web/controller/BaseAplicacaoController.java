package br.com.netservicos.bow.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.netservicos.bow.model.Aplicacao;
import br.com.netservicos.bow.model.BaseAplicacao;
import br.com.netservicos.bow.service.BaseAplicacaoService;
import br.com.netservicos.bow.service.PaggableSelect;
import br.com.netservicos.bow.web.bean.AplicacaoBean;
import br.com.netservicos.bow.web.bean.BaseAplicacaoBean;

@RestController
@RequestMapping(value = BaseAplicacaoController.REQUEST_MAPPING_PAGE)
public class BaseAplicacaoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseAplicacaoController.class);

    private static final String VALUE_SEPARATOR = " - ";

    protected static final String REQUEST_MAPPING_PAGE = "/base-aplicacao";

    @Autowired
    private BaseAplicacaoService baseAplicacaoService;

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<BaseAplicacaoBean>> carregar(PaggableSelect paggable) {

        LOGGER.debug("Carregando as aplicações com a pagina: {}", paggable);

        List<BaseAplicacao> aplicacoes = baseAplicacaoService.findByPaggebleSelect(paggable);

        if (aplicacoes.isEmpty()) {

            return new ResponseEntity<List<BaseAplicacaoBean>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<BaseAplicacaoBean> baseAplicacoes = new ArrayList<>();

        aplicacoes.forEach(aplicacaoBase -> {

            Aplicacao aplicacao = aplicacaoBase.getAplicacao();

            String nomeCompleto = String.join(VALUE_SEPARATOR, aplicacao.getDescricao(), aplicacao.getEmpresa().getDescricao(),
                    aplicacaoBase.getBase().getNome());

            BaseAplicacaoBean baseAplicacao = new BaseAplicacaoBean(aplicacaoBase.getId(), nomeCompleto);

            baseAplicacoes.add(baseAplicacao);
        });

        return new ResponseEntity<List<BaseAplicacaoBean>>(baseAplicacoes, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarAplicacao", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Aplicacao>> carregarAplicacao(Long baseId) {

        List<BaseAplicacao> baseAplicacoes = baseAplicacaoService.findByAplicacoes(baseId);

        if (baseAplicacoes.isEmpty()) {

            return new ResponseEntity<List<Aplicacao>>(new ArrayList<>(), HttpStatus.NO_CONTENT);
        }

        List<Aplicacao> aplicacoes = baseAplicacoes.stream().map(baseAplicacao -> AplicacaoBean.formaterField(baseAplicacao.getAplicacao()))
                .collect(Collectors.toList());

        return new ResponseEntity<List<Aplicacao>>(aplicacoes, HttpStatus.OK);
    }

    @RequestMapping(value = "/carregarPorId", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BaseAplicacaoBean> carregarPorId(Long baseAplicacaoId) {

        if (baseAplicacaoId != null) {

            Optional<BaseAplicacao> aplicacaoBase = baseAplicacaoService.findFetchAllById(baseAplicacaoId);

            if (!aplicacaoBase.isPresent()) {

                return new ResponseEntity<BaseAplicacaoBean>(HttpStatus.NO_CONTENT);
            }

            BaseAplicacao baseAplicacao = aplicacaoBase.get();

            String nomeCompleto = String.join(VALUE_SEPARATOR, baseAplicacao.getAplicacao().getDescricao(), baseAplicacao.getBase().getNome());

            BaseAplicacaoBean baseAplicacaoBean = new BaseAplicacaoBean(baseAplicacao.getId(), nomeCompleto);

            return new ResponseEntity<BaseAplicacaoBean>(baseAplicacaoBean, HttpStatus.OK);
        }

        return new ResponseEntity<BaseAplicacaoBean>(HttpStatus.NO_CONTENT);
    }

}
