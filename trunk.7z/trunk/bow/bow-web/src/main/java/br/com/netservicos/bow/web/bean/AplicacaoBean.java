package br.com.netservicos.bow.web.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;

import br.com.netservicos.bow.model.Aplicacao;

public class AplicacaoBean implements Serializable {

    private static final long serialVersionUID = 2761607862016604202L;

    private static final String SEPARATOR = " - ";

    private Long id;

    private String empresa;

    private String descricao;

    @NotBlank
    private String complemento;

    @NotBlank
    private String impacto;

    public AplicacaoBean() {
        // Construtor padrao
    }

    public AplicacaoBean(Long id, String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    public AplicacaoBean(Long id, String empresa, String descricao) {
        this.id = id;
        this.empresa = empresa;
        this.descricao = descricao;
    }

    public AplicacaoBean(Long id, String empresa, String descricao, String complemento, String impacto) {
        this.id = id;
        this.empresa = empresa;
        this.descricao = descricao;
        this.complemento = complemento;
        this.impacto = impacto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getImpacto() {
        return impacto;
    }

    public void setImpacto(String impacto) {
        this.impacto = impacto;
    }

    public static List<Aplicacao> formaterFields(List<Aplicacao> aplicacoes) {

        List<Aplicacao> aplicacaoesBean = new ArrayList<>();

        aplicacoes.forEach(aplicacao -> {

            String descricao = String.join(SEPARATOR, aplicacao.getDescricao(), aplicacao.getEmpresa().getDescricao());

            aplicacaoesBean.add(new Aplicacao(aplicacao.getId(), descricao));
        });

        return aplicacaoesBean;
    }

    public static Aplicacao formaterField(Aplicacao aplicacao) {

        String descricao = String.join(SEPARATOR, aplicacao.getDescricao(), aplicacao.getEmpresa().getDescricao());

        return new Aplicacao(aplicacao.getId(), descricao);
    }

}
