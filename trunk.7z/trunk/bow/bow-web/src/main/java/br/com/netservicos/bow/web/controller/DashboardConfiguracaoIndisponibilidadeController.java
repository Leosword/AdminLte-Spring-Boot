package br.com.netservicos.bow.web.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.netservicos.bow.common.util.CollectionUtil;
import br.com.netservicos.bow.common.util.ResourceUtil;
import br.com.netservicos.bow.model.DashboardConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.model.enums.TipoConfiguracaoIndisponibilidade;
import br.com.netservicos.bow.service.DashboardConfiguracaoIndisponibilidadeService;
import br.com.netservicos.bow.web.bean.DashboardConfiguracaoIndisponibilidadeBean;
import br.com.netservicos.bow.web.validation.ValidationResponse;

@RestController
@RequestMapping(value = DashboardConfiguracaoIndisponibilidadeController.REQUEST_MAPPING_PAGE)
public class DashboardConfiguracaoIndisponibilidadeController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardConfiguracaoIndisponibilidadeController.class);

    private static final String MODEL_NAME = "dashboardConfiguracaoIndisponibilidadeBean";

    private static final String PATTERN = "dd/MM/yyyy";

    private static final String REDIRECT_PAGE_INCLUIR = "/incluir";

    private static final String REDIRECT_PAGE_SALVAR = "/salvar";

    private static final String REQUEST_MAPPING_PAGE_INCLUIR = "configuracao/incluirdashboardconfiguracaoindisponibilidade";

    private static final String REDIRECT_PAGE_PESQUISAR = "/pesquisar";

    private static final String REQUEST_MAPPING_PAGE_PESQUISAR = "configuracao/pesquisardashboardconfiguracaoindisponibilidade";

    protected static final String REQUEST_MAPPING_PAGE = "/configuracao";

    @Autowired
    private DashboardConfiguracaoIndisponibilidadeService service;

    @RequestMapping(value = REDIRECT_PAGE_PESQUISAR, method = RequestMethod.GET)
    public ModelAndView showPesquisar(Model model, HttpServletRequest request) {

        return new ModelAndView(REQUEST_MAPPING_PAGE_PESQUISAR);
    }

    @RequestMapping(value = "/carregar", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DashboardConfiguracaoIndisponibilidadeBean>> carregar() {

        LOGGER.debug("Iniciando o carregamento das aplicações que contém base.");

        List<DashboardConfiguracaoIndisponibilidade> configuracoes = service.findFecthAll();

        if (CollectionUtil.isEmpty(configuracoes)) {

            LOGGER.debug("Não foi possível localizar configurações");

            return new ResponseEntity<List<DashboardConfiguracaoIndisponibilidadeBean>>(new ArrayList<>(), HttpStatus.OK);
        }

        List<DashboardConfiguracaoIndisponibilidadeBean> configuracoesBean = configuracoes.stream()
                .map(configuracao -> new DashboardConfiguracaoIndisponibilidadeBean(configuracao.getId(), configuracao.getEmpresa().getDescricao(),
                        ResourceUtil.getMensagem(configuracao.getTipo().getDescription()), configuracao.getValor(),
                        getDataFormatada(configuracao.getData())))
                .collect(Collectors.toList());

        return new ResponseEntity<List<DashboardConfiguracaoIndisponibilidadeBean>>(configuracoesBean, HttpStatus.OK);
    }

    @RequestMapping(value = REDIRECT_PAGE_INCLUIR, method = RequestMethod.GET)
    public ModelAndView viewIncluir(ModelMap model, HttpServletRequest request) {

        model.addAttribute(MODEL_NAME, new DashboardConfiguracaoIndisponibilidadeBean());

        model.addAttribute("tipos", TipoConfiguracaoIndisponibilidade.values());

        return new ModelAndView(REQUEST_MAPPING_PAGE_INCLUIR);
    }

    @RequestMapping(value = REDIRECT_PAGE_SALVAR, method = RequestMethod.POST)
    public ResponseEntity<ValidationResponse> salvar(@Valid @RequestBody DashboardConfiguracaoIndisponibilidadeBean bean, BindingResult result) {

        if (result.hasErrors()) {

            ValidationResponse validationResponse = new ValidationResponse("ERROR");

            List<FieldError> fieldErrors = result.getFieldErrors();

            fieldErrors.forEach(fieldError -> {

                validationResponse.addFieldError(fieldError.getField(), fieldError.getDefaultMessage());
            });

            return new ResponseEntity<ValidationResponse>(validationResponse, HttpStatus.CONFLICT);
        }

        DashboardConfiguracaoIndisponibilidade configuracao = new DashboardConfiguracaoIndisponibilidade(bean.getValor(),
                getDataFormatada(bean.getDia()));

        service.salvar(bean.getTipoId(), bean.getEmpresaId(), configuracao);

        return new ResponseEntity<ValidationResponse>(new ValidationResponse(), HttpStatus.CREATED);
    }

    @RequestMapping(value = "/remover/{ids}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> deletar(@PathVariable("ids") Long[] ids) {

        LOGGER.debug("Aplicação book a serem removidos: {}", new Object[] { ids });

        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    private String getDataFormatada(Date data) {

        SimpleDateFormat formatter = new SimpleDateFormat(PATTERN);

        return formatter.format(data);
    }

    private Date getDataFormatada(String data) {

        SimpleDateFormat formatter = new SimpleDateFormat(PATTERN);

        try {

            return formatter.parse(data);

        } catch (ParseException e) {

            LOGGER.error("Erro ao converter a data com o valor : {}", data);

            return null;
        }

    }

}