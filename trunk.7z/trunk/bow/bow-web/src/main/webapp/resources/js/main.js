function startBlockUI()	{
	$.blockUI({ message: '<i class="fa fa-cog fa-spin fa-5x fa-fw"></i>' });
}

function paginar(params) {
    return {
        page: (params.offset / params.limit),
        offset: params.offset,
        limit: params.limit,
        order: params.order,
        sort: params.sort
    };
}


function responseHandler(res) {
    $.each(res.rows, function (i, row) {
        row.state = $.inArray(row.id, selections) !== -1;
    });
    return res;
}


function formatar(value) {
	return value;
}

function estilizarCheckbox(value) {
	return value;
}