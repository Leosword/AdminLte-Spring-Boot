package br.com.net.cotibot.comando;

import java.rmi.RemoteException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;
import br.com.net.cotibot.dao.ChamadoCAUsuarioDAO;
import br.com.net.cotibot.dao.ComentarioChamadoCADAO;
import br.com.net.cotibot.model.ChamadoCAUsuario;
import br.com.net.cotibot.model.ComentarioChamadoCA;
import br.com.net.cotibot.model.enumerator.SolicitacaoChamadoEnum;
import br.com.net.cotibot.model.enumerator.StatusServiceDeskEnum;
import br.com.net.cotibot.model.enumerator.TipoChamadoEnum;
import br.com.net.cotibot.service.EnvioEmailService;
import br.com.net.cotibot.service.TelegramComandoService;
import br.com.net.cotibot.util.FormataData;
import br.com.net.cotibot.webserviceclient.USD_Connection;
import br.com.net.cotibot.webserviceclient.USD_GetAttribute;

public class TelegramComandoCA extends TelegramComandoService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TelegramComandoCA.class);

	private USD_Connection usd = AutoWiringSpringBeanJobFactory.getBean(USD_Connection.class);

	private USD_GetAttribute getAttribute = AutoWiringSpringBeanJobFactory.getBean(USD_GetAttribute.class);

	private ChamadoCAUsuarioDAO chamadoCAusuarioDAO = AutoWiringSpringBeanJobFactory.getBean(ChamadoCAUsuarioDAO.class);
	
	private ComentarioChamadoCADAO comentarioChamadoCADAO = AutoWiringSpringBeanJobFactory.getBean(ComentarioChamadoCADAO.class);

	private FormataData formataData = AutoWiringSpringBeanJobFactory.getBean(FormataData.class);

	private EnvioEmailService envioEmailService = AutoWiringSpringBeanJobFactory.getBean(EnvioEmailService.class);

	int sid = 0;
	String username = "";
	String password = "";
	String numeroChamado = null;
	String idUltimaRequisicao = null;
	String mensagemViolado;
	String tpRequisicao;
	String corpoMensagem;

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		String[] splitTexto = texto.split(" ");
		if (splitTexto.length >= 2) {
			tpRequisicao = splitTexto[0];
			numeroChamado = splitTexto[1];
			idUltimaRequisicao = splitTexto[2];
		}
		if (numeroChamado == null || numeroChamado.equals("")) {
			ChamadoCAUsuario obj = new ChamadoCAUsuario();
			obj.setIdUsuario(idUsuario);
			obj.setTipoChamado(TipoChamadoEnum.get(texto).getLabel());
			chamadoCAusuarioDAO.adicionaUsuarioCA(obj, SolicitacaoChamadoEnum.PENDENTE.getNome());

			SendMessage mensagemSemChamado = new SendMessage(chatId,
					"<b>Digite o número do " + TipoChamadoEnum.get(texto).getLabel() + ".</b>")
							.parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
			bot.execute(mensagemSemChamado);
		} else {
			try {
				SendMessage mensagemSemChamado = new SendMessage(chatId,
						"<b>Aguarde. Estamos processando sua requisição..</b>").parseMode(ParseMode.HTML)
								.replyMarkup(getRemoveKeyboard());
				bot.execute(mensagemSemChamado);

				sid = usd.getUsd().login(username, password);
				if (sid <= 0) {
					LOGGER.info("Falha na autenticação com o Service Desk.");
					return;
				} else {
					LOGGER.info("Autenticação com o Service Desk realizada com sucesso");
					String[] arrayFields = { "type", "open_date", "customer.last_name", "group.last_name",
							"zsrelatev.fire_time", "status", "resolve_date", "sla_violation" };
					
					String queryChamado = usd.getUsd().doSelect(sid, TipoChamadoEnum.get(tpRequisicao + "query").getLabel(), "ref_num='" + numeroChamado + "'", -1,
							arrayFields);

					String tipoChamado = getAttribute.retornaAtributo(queryChamado, "type");
					String status = getAttribute.retornaAtributo(queryChamado, "status");
					String grupoSolucionador = getAttribute.retornaAtributo(queryChamado, "group.last_name");
					String dtCriacao = getAttribute.retornaAtributo(queryChamado, "open_date");
					String dtResolvido = getAttribute.retornaAtributo(queryChamado, "resolve_date");
					String dtSlaViolado = getAttribute.retornaAtributo(queryChamado, "zsrelatev.fire_time");
					String slaViolado = getAttribute.retornaAtributo(queryChamado, "sla_violation");
					String dataFormatada = formataData.formataData(dtCriacao);
					String dataFormatadaSLA = formataData.formataData(dtSlaViolado);
					String dataFormatadaResolvido = formataData.formataData(dtResolvido);
					
					ComentarioChamadoCA comentarioChamado = comentarioChamadoCADAO.getComentarioChamado(StatusServiceDeskEnum.get(status).getLabel());
					mensagemViolado = comentarioChamado.getComentario();
					
					if (slaViolado.equals("1") && !StatusServiceDeskEnum.RESOLVIDO.getNome().equals(status)
							&& !StatusServiceDeskEnum.ENCERRADO.getNome().equals(status)) {
						int enviaEmail = 0;
						mensagemViolado = "Seu chamado está com o SLA Violado.\nJá iniciamos o processo de priorização e escalonamento, favor aguarde o atendimento";
						List<ChamadoCAUsuario> validaEmailEnviado = chamadoCAusuarioDAO.validaEmailEnviado(numeroChamado);
						for (ChamadoCAUsuario chamadoCAUsuario : validaEmailEnviado) {
							if(chamadoCAUsuario.getSituacaoEmail() != null){
								enviaEmail = 1;
							}
						}
						if(enviaEmail == 0){							
							envioEmailService.EnvioEmail(numeroChamado);
							chamadoCAusuarioDAO.atualizaEmailChamado(idUltimaRequisicao);
						}
					}

					LOGGER.info("Consulta Incidente realizada por: {}", nome);
					LOGGER.info("Chamado consultado: {}", numeroChamado);

					if (TipoChamadoEnum.get(tipoChamado).getLabel().equals(TipoChamadoEnum.get(tpRequisicao).getLabel())) {
						String dataMensagem = "";
						if (StatusServiceDeskEnum.RESOLVIDO.getNome().equals(status)
								|| StatusServiceDeskEnum.ENCERRADO.getNome().equals(status)) {
							if (!dataFormatadaResolvido.contains("vazio")) {
								dataMensagem = "\n<b>Resolvido em:</b> " + dataFormatadaResolvido;
							}
						} else {
							if (!dataFormatadaSLA.contains("vazio")) {
								dataMensagem = "\n<b>SLA:</b> " + dataFormatadaSLA;
							}
						}
						if (slaViolado.equals("1") && !StatusServiceDeskEnum.RESOLVIDO.getNome().equals(status)
								&& !StatusServiceDeskEnum.ENCERRADO.getNome().equals(status)) {
							corpoMensagem = "<b>Status do " + TipoChamadoEnum.get(tpRequisicao).getLabel() + " Nº: " + numeroChamado
									+ "</b>\n...............................................\n<b>Tipo:</b> " + TipoChamadoEnum.get(tpRequisicao).getLabel() + "\n<b>Status:</b> "
									+ StatusServiceDeskEnum.get(status).getLabel()
									+ "\n<b>Grupo Solucionador:</b> " + grupoSolucionador
									+ "\n<b>Aberto em:</b> " + dataFormatada + dataMensagem
									+ "\n<b>Situação: </b>" + mensagemViolado + ".";							
						} else if(mensagemViolado != null){
							corpoMensagem = "<b>Status do " + TipoChamadoEnum.get(tpRequisicao).getLabel() + " Nº: " + numeroChamado
									+ "</b>\n...............................................\n<b>Tipo:</b> " + TipoChamadoEnum.get(tpRequisicao).getLabel() + "\n<b>Status:</b> "
									+ StatusServiceDeskEnum.get(status).getLabel()
									+ "\n<b>Grupo Solucionador:</b> " + grupoSolucionador
									+ "\n<b>Aberto em:</b> " + dataFormatada + dataMensagem
									+ "\n<b>Situação: </b>" + mensagemViolado + ".";
						} else {
							corpoMensagem = "<b>Status do " + TipoChamadoEnum.get(tpRequisicao).getLabel() + " Nº: " + numeroChamado
									+ "</b>\n...............................................\n<b>Tipo:</b> " + TipoChamadoEnum.get(tpRequisicao).getLabel() + "\n<b>Status:</b> "
									+ StatusServiceDeskEnum.get(status).getLabel()
									+ "\n<b>Grupo Solucionador:</b> " + grupoSolucionador
									+ "\n<b>Aberto em:</b> " + dataFormatada + dataMensagem + ".";
						}
						SendMessage mensagemComChamado = new SendMessage(idUsuario, corpoMensagem).parseMode(ParseMode.HTML)
								.replyMarkup(getRemoveKeyboard());
						bot.execute(mensagemComChamado);
						SendMessage novaConsulta = new SendMessage(idUsuario, "Deseja realizar uma nova consulta?")
								.parseMode(ParseMode.HTML).replyMarkup(getMarkupInlinePergunta());
						bot.execute(novaConsulta);
						chamadoCAusuarioDAO.atualizaStatusChamado(SolicitacaoChamadoEnum.SUCESSO.getNome(),
								idUltimaRequisicao, numeroChamado);
					} else {
						SendMessage mensagemComChamado = new SendMessage(chatId,
								"<b>O " + TipoChamadoEnum.get(tpRequisicao).getLabel() + " " + numeroChamado
										+ " não foi encontrado!</b>\nVerifique o número do chamado e tente novamente.")
												.parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
						bot.execute(mensagemComChamado);
						SendMessage novaConsulta = new SendMessage(idUsuario, "Deseja realizar uma nova consulta?")
								.parseMode(ParseMode.HTML).replyMarkup(getMarkupInlinePergunta());
						bot.execute(novaConsulta);
						chamadoCAusuarioDAO.atualizaStatusChamado(SolicitacaoChamadoEnum.ERRO.getNome(),
								idUltimaRequisicao, numeroChamado);
					}

				}

			} catch (RemoteException e) {
				LOGGER.error("RemoteException: {}", e);
			} catch (NumberFormatException e) {
				SendMessage mensagemComChamado = new SendMessage(chatId,
						"<b>O " + TipoChamadoEnum.get(tpRequisicao).getLabel() + " " + numeroChamado
								+ " não foi encontrado!</b>\nVerifique o número do chamado e tente novamente.")
										.parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
				bot.execute(mensagemComChamado);
				SendMessage novaConsulta = new SendMessage(idUsuario, "Deseja realizar uma nova consulta?")
						.parseMode(ParseMode.HTML).replyMarkup(getMarkupInlinePergunta());
				bot.execute(novaConsulta);
				chamadoCAusuarioDAO.atualizaStatusChamado(SolicitacaoChamadoEnum.ERRO.getNome(), idUltimaRequisicao, numeroChamado);
			} catch (Exception e) {
				LOGGER.error(e.toString());
			}
		}
	}
}
