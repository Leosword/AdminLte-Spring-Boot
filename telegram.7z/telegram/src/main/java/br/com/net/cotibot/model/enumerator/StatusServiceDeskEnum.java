package br.com.net.cotibot.model.enumerator;

public enum StatusServiceDeskEnum {
	ABERTO("OP", "Aberto"), AGENDADO("AGENDADO", "Agendado"), AGUARDANDO_CORRECAO("AG_COR",
			"Aguardando Correção"), AGUARDANDO_ORCAMENTO("AGAP_ORC", "Aguardando Orçamento"), AGUARDANDO_PECAS("AGPE",
					"Aguardando Peças"), ANALISADO("analisado", "Analisando"), DIRECIONADO("DIR",
							"Direcionado"), EM_ANALISE("Em_analise", "Em Análise"), EM_TRABALHO("EMTRAB",
									"Em Trabalho"), EMPRESTIMO_EQUIPAMENTO("EMP_EQUIP",
											"Emprestimo de Equipamento"), PENDENTE_CLIENTE("pend_cnt",
													"Pendente Cliente"), PENDENTE_FORNECEDOR("PEND_FORNE",
															"Pendente Fornecedor"), PENDENTE_USUARIO("PENDUSER",
																	"Pendente Usuário"), PENDENTE_CONSULTOR_REGIONAL("PND_CONS_REG",
																			"Pendente Consultor Regional"), RESOLVIDO("RE",
																			"Resolvido"), EM_TRANSITO("EM_TRANSITO",
																					"Em Trânsito"), ENCERRADO("CL",
																					"Encerrado"), VAZIO("NA", "Não Encontrado");

	public static StatusServiceDeskEnum get(String nome) {
		for (StatusServiceDeskEnum obj : StatusServiceDeskEnum.values()) {
			if (obj.getNome().equalsIgnoreCase(nome))
				return obj;
		}
		return VAZIO;
	}

	String nome;
	String label;

	public String getNome() {
		return nome;
	}

	public String getLabel() {
		return label;
	}

	StatusServiceDeskEnum(String nome, String label) {
		this.nome = nome;
		this.label = label;
	}

}
