package br.com.net.cotibot.model;

public class Eventos {

    private String tratados;

    private String naoTratados;

	public String getTratados() {
		return tratados;
	}

	public void setTratados(String tratados) {
		this.tratados = tratados;
	}

	public String getNaoTratados() {
		return naoTratados;
	}

	public void setNaoTratados(String naoTratados) {
		this.naoTratados = naoTratados;
	}
   

}
