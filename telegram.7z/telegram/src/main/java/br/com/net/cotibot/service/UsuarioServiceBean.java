package br.com.net.cotibot.service;

import java.text.ParseException;
import java.util.List;

import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;
import br.com.net.cotibot.dao.UsuarioDAO;
import br.com.net.cotibot.model.Usuario;

@Service
@Transactional(readOnly=true)
public class UsuarioServiceBean implements UsuarioService{
	
	private UsuarioDAO usuarioDAO = AutoWiringSpringBeanJobFactory.getBean(UsuarioDAO.class);

	@Override
	public Long validaUsuario(Long id) {
		return usuarioDAO.validaUsuario(id);
	}
	
	@Override
	public Long verificaUsuarioAtivo(Long id) {
		return usuarioDAO.verificaUsuarioAtivo(id);
	}

	@Override
	public Long verificaUsuarioInativo(Long id) {
		return usuarioDAO.verificaUsuarioInativo(id);
	}

	@Override
	@Transactional
	public void adicionaUsuario(String idTelegram, String nome, String sobrenome, String telefone) {
		
		MaskFormatter telefoneFormatter = null;
		try {
			telefoneFormatter = new MaskFormatter("## (##) #####-####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		JFormattedTextField txtTelefone = new JFormattedTextField(telefoneFormatter);
		txtTelefone.setText(telefone);
		
		Usuario obj = new Usuario();
		obj.setIdTelegram(idTelegram);
		obj.setNome(nome);
		obj.setSobrenome(sobrenome);
		obj.setTelefone(telefone);
		obj.setStatus(0);
		obj.setPerfil("Usuario");
		usuarioDAO.adicionaUsuario(obj);		
	}

	@Override
	public List<Usuario> obterAdministradores() {
		return usuarioDAO.listaAdministradores();
	}

	@Override
	public Usuario getUsuario(Long idUsuario) {
		return usuarioDAO.getUsuario(idUsuario);
	}

	@Override
	@Transactional
	public void ativaUsuario(int id, String nome, String sobreNome) {
		usuarioDAO.ativaUsuario(id, nome, sobreNome);
	}

	@Override
	@Transactional
	public void removeUsuario(int id) {
		usuarioDAO.removeUsuario(id);
		
	}
}
