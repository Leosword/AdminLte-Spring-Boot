package br.com.net.cotibot.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.net.cotibot.model.ComentarioChamadoCA;

public class ComentarioChamadoCARowMapper implements RowMapper<ComentarioChamadoCA> {

    @Override
    public ComentarioChamadoCA mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        final ComentarioChamadoCA comentarioChamadoCA = new ComentarioChamadoCA();

        comentarioChamadoCA.setId(rs.getInt("id_comentario_chamado"));
        comentarioChamadoCA.setTipoStatusChamado(rs.getString("tp_status_chamado"));
        comentarioChamadoCA.setComentario(rs.getString("ds_comentario"));

        return comentarioChamadoCA;
    }
}