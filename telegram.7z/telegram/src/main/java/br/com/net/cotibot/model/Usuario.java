package br.com.net.cotibot.model;

public class Usuario {
    private int id;

    private String nome;

    private String sobrenome;

    private String idTelegram;
    
    private String telefone;
    
    private int status;
    
    private String perfil;
    
    private String aprovador;

	public int getId() {
        return id;
    }

    public void setId(final int id) {
        this.id = id;
    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public String getIdTelegram() {
		return idTelegram;
	}

	public void setIdTelegram(String idTelegram) {
		this.idTelegram = idTelegram;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getPerfil() {
		return perfil;
	}

	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}

	public String getAprovador() {
		return aprovador;
	}

	public void setAprovador(String aprovador) {
		this.aprovador = aprovador;
	}
	
}
