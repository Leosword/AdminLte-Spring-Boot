package br.com.net.cotibot.service;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;

import com.pengrad.telegrambot.TelegramBotAdapter;
import com.pengrad.telegrambot.model.request.InlineKeyboardButton;
import com.pengrad.telegrambot.model.request.InlineKeyboardMarkup;
import com.pengrad.telegrambot.model.request.Keyboard;
import com.pengrad.telegrambot.model.request.KeyboardButton;
import com.pengrad.telegrambot.model.request.ReplyKeyboardMarkup;
import com.pengrad.telegrambot.model.request.ReplyKeyboardRemove;

import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;

public abstract class TelegramComandoService {
	/*TOKEN PRODUCAO*/
	//public static final String TOKEN = "443263263:AAHHWD2Q4VeyXMgVLIwo4IPZaeyK3iCroDg";
	/*TOKEN DESENVOLVIMENTO*/
	public static final String TOKEN = "442489243:AAHmRWMP-aD_KVva76bHpcFDkchzGbysE1g";
	public static final String TOKEN_INFORMA = "443201211:AAFrMTjtnkG_RisJTIxu_bm6Jt5amxowbOY";
	
	protected com.pengrad.telegrambot.TelegramBot bot = TelegramBotAdapter.buildCustom(TOKEN, client("", 8080, "", ""));
	protected com.pengrad.telegrambot.TelegramBot botInforma = TelegramBotAdapter.buildCustom(TOKEN_INFORMA, client("", 8080, "", ""));

	public abstract void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone);

	protected Keyboard getRemoveKeyboard() {
		return new ReplyKeyboardRemove();
	}

	protected InlineKeyboardMarkup getAtivaUsuarioKeyboard(String idUsuario) {
		return new InlineKeyboardMarkup(
				new InlineKeyboardButton[] {new InlineKeyboardButton("Ativar Usuário").callbackData("/AtivarUsuario " + idUsuario + ""),
						new InlineKeyboardButton("Recusar Usuário").callbackData("/RecusarUsuario " + idUsuario + "")});
	}
	
	protected InlineKeyboardMarkup getBotaoAcesso() {
		return new InlineKeyboardMarkup(
				new InlineKeyboardButton[] {new InlineKeyboardButton("Solicitar Acesso").callbackData("/acesso")});
	}

	protected Keyboard getSolicitaTelefoneKeyboard() {
		return new ReplyKeyboardMarkup(
				new KeyboardButton[] { new KeyboardButton("/Enviar meu número").requestContact(true) },
				new KeyboardButton[] { new KeyboardButton("/Cancelar") }).oneTimeKeyboard(true).resizeKeyboard(true)
						.selective(true);
	}
	
	protected InlineKeyboardMarkup getMarkupInline(){
		
		return new InlineKeyboardMarkup(
				new InlineKeyboardButton[] {new InlineKeyboardButton("Consultar Chamado").callbackData("/chamadoca")/*,
						new InlineKeyboardButton("Volumetria de Eventos").callbackData("/EventosAbertos")},
				new InlineKeyboardButton[] {
						new InlineKeyboardButton("Cadeia de Ativacao - PFC").callbackData("/ordenspfcoti")*/}
				);
	}
	protected InlineKeyboardMarkup getMarkupInlineTpChamadoCA(){
		
		return new InlineKeyboardMarkup(
				new InlineKeyboardButton[] { new InlineKeyboardButton("Um Incidente").callbackData("/incidente"),
						new InlineKeyboardButton("Uma Solicitação").callbackData("/solicitacao")}
				);
	}
	
	protected InlineKeyboardMarkup getMarkupInlinePergunta(){
		
		return new InlineKeyboardMarkup(
				new InlineKeyboardButton[] { new InlineKeyboardButton("Sim").callbackData("/chamadoca"),
						new InlineKeyboardButton("Não").callbackData("/vazio")}
				);
	}
	
	protected InlineKeyboardMarkup getMarkupInlinePerguntaCancelaChamado(){
		
		return new InlineKeyboardMarkup(
				new InlineKeyboardButton[] { new InlineKeyboardButton("Cancelar").callbackData("/cancelachamado")}
				);
	}
	protected InlineKeyboardMarkup getMarkupInlineVoltar(){
		
		return new InlineKeyboardMarkup(
				new InlineKeyboardButton[] { new InlineKeyboardButton("Voltar ao menu").callbackData("/start")}
				);
	}
	
	public static OkHttpClient client(final String proxyHost, final int proxyPort, final String userName, final String password) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();

        final Authenticator proxyAuthenticator = new Authenticator() {
            public Request authenticate(Route route, Response response) throws IOException {
                String credential = Credentials.basic(userName, password);
                return response.request().newBuilder()
                        .header("Proxy-Authorization", credential)    
                        .build();
            }
        };

        builder.proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort)))
        .proxyAuthenticator(proxyAuthenticator)
        .retryOnConnectionFailure(true);

        return builder.build();
    }
}
