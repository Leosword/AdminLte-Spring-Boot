package br.com.net.cotibot.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.net.cotibot.model.Usuario;

public class UsuarioRowMapper implements RowMapper<Usuario> {

    @Override
    public Usuario mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        final Usuario usuario = new Usuario();

        usuario.setId(rs.getInt("id"));
        usuario.setNome(rs.getString("nm_usuario"));
        usuario.setSobrenome(rs.getString("nm_sobrenome"));
        usuario.setIdTelegram(rs.getString("id_telegram"));
        usuario.setStatus(rs.getInt("fl_status"));
        usuario.setTelefone(rs.getString("num_telefone"));
        usuario.setPerfil(rs.getString("nm_perfil"));
        usuario.setAprovador(rs.getString("nm_aprovador"));

        return usuario;
    }
}