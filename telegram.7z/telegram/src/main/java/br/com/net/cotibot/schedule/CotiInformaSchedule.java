package br.com.net.cotibot.schedule;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import br.com.net.cotibot.model.enumerator.TelegramComandoEnum;

@Component
public class CotiInformaSchedule {

	private static final Logger log = LoggerFactory.getLogger(CotiInformaSchedule.class);
	Date instanteAtual;	

	@Scheduled(initialDelay = 0, fixedRate = 3600000)
	public void run() {
		instanteAtual = new Date();
		log.info(instanteAtual.toString());
		//TelegramComandoEnum.getImplementacaoPfc().executa(TelegramComandoEnum.PFC.getNome(), "-1001148181930", "-1001148181930", "", "", "schedule");
	}

}