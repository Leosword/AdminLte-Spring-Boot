package br.com.net.cotibot.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.pengrad.telegrambot.TelegramBotAdapter;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;

@Service
public class RunBotService implements Runnable {

	private CotiBotListenerService cotiBotListener;
	private static final Logger LOGGER = LoggerFactory.getLogger(RunBotService.class);

	/*TOKEN PRODUCAO*/
	//public static final String TOKEN = "443263263:AAHHWD2Q4VeyXMgVLIwo4IPZaeyK3iCroDg";
	/*TOKEN DESENVOLVIMENTO*/
	public static final String TOKEN = "442489243:AAHmRWMP-aD_KVva76bHpcFDkchzGbysE1g";
	
	public void run() {
		cotiBotListener = AutoWiringSpringBeanJobFactory.getBean(CotiBotListenerService.class);
		try {
			com.pengrad.telegrambot.TelegramBot bot = TelegramBotAdapter.buildCustom(TOKEN,
					TelegramComandoService.client("", 8080, "", ""));

			bot.setUpdatesListener(cotiBotListener);
		} catch (Exception e1) {
			LOGGER.error(e1.toString());
		}
	}
}
