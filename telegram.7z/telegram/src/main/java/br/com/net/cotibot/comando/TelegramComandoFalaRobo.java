/**
 * 
 */
package br.com.net.cotibot.comando;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.service.TelegramComandoService;

/**
 * @author Leandro Celestino 29 de jun de 2017
 *
 */
public class TelegramComandoFalaRobo extends TelegramComandoService {

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		SendMessage mensagem = new SendMessage(chatId, "Atendimento Coti").parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
		bot.execute(mensagem);
	}

}
