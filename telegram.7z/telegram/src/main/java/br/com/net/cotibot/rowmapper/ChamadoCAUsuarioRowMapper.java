package br.com.net.cotibot.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.net.cotibot.model.ChamadoCAUsuario;

public class ChamadoCAUsuarioRowMapper implements RowMapper<ChamadoCAUsuario> {

    @Override
    public ChamadoCAUsuario mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        final ChamadoCAUsuario chamadoCAUsuario = new ChamadoCAUsuario();

        chamadoCAUsuario.setId(rs.getInt("id_tipo_chamado_ca"));
        chamadoCAUsuario.setTipoChamado(rs.getString("tp_chamado"));
        chamadoCAUsuario.setIdUsuario(rs.getString("id_usuario_telegram"));
        chamadoCAUsuario.setChamadoRespondido(rs.getString("ds_chamado_respondido"));
        chamadoCAUsuario.setSituacaoEmail(rs.getString("ds_situacao_email"));
        chamadoCAUsuario.setNumeroChamado(rs.getString("num_chamado"));

        return chamadoCAUsuario;
    }
}