package br.com.net.cotibot.model;

import java.util.Date;

public class Pfc {

	private int id;

	private String vlPendenteEnvio;

	private String vlEnviada;

	private String vlProcessando;

	private String tipoColeta;

	private String NomeBase;

	private Date dtCadastro;

	private Date dtColeta;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVlPendenteEnvio() {
		return vlPendenteEnvio;
	}

	public void setVlPendenteEnvio(String vlPendenteEnvio) {
		this.vlPendenteEnvio = vlPendenteEnvio;
	}

	public String getVlEnviada() {
		return vlEnviada;
	}

	public void setVlEnviada(String vlEnviada) {
		this.vlEnviada = vlEnviada;
	}

	public String getVlProcessando() {
		return vlProcessando;
	}

	public void setVlProcessando(String vlProcessando) {
		this.vlProcessando = vlProcessando;
	}

	public String getTipoColeta() {
		return tipoColeta;
	}

	public void setTipoColeta(String tipoColeta) {
		this.tipoColeta = tipoColeta;
	}

	public String getNomeBase() {
		return NomeBase;
	}

	public void setNomeBase(String nomeBase) {
		NomeBase = nomeBase;
	}

	public Date getDtCadastro() {
		return dtCadastro;
	}

	public void setDtCadastro(Date dtCadastro) {
		this.dtCadastro = dtCadastro;
	}

	public Date getDtColeta() {
		return dtColeta;
	}

	public void setDtColeta(Date dtColeta) {
		this.dtColeta = dtColeta;
	}
}
