package br.com.net.cotibot;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public final class AutoWiringSpringBeanJobFactory implements ApplicationContextAware {

	private static ApplicationContext context;

    private AutoWiringSpringBeanJobFactory(){}

    public static ApplicationContext getApplicationContext() {
        return context;
    }

    public  static <T> T getBean(Class<T> aClass){
        return context.getBean(aClass);
    }

    @Override
    public void setApplicationContext(ApplicationContext ctx) throws BeansException {
        context = ctx;
    }

}
