package br.com.net.cotibot.comando;

import java.util.List;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;
import br.com.net.cotibot.model.Usuario;
import br.com.net.cotibot.service.TelegramComandoService;
import br.com.net.cotibot.service.UsuarioService;

public class TelegramComandoRecusaUsuario extends TelegramComandoService {
	
	private UsuarioService usuarioService = AutoWiringSpringBeanJobFactory.getBean(UsuarioService.class);

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		String[] splitTexto = texto.split(" ");
		String idUsuarioRecusado = splitTexto[1];									
											
		if(usuarioService.validaUsuario(Long.parseLong(idUsuarioRecusado)) == 0){
			SendMessage mensagemParaUsuarioInativo = new SendMessage(chatId,
					"<b>Usuário já foi recusado!</b>.").parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
			bot.execute(mensagemParaUsuarioInativo);
		}else{
			Usuario retornoUsuarioRecusado = usuarioService.getUsuario(Long.parseLong(idUsuarioRecusado));
			usuarioService.removeUsuario(retornoUsuarioRecusado.getId());
			List<Usuario> listaAdministradores = usuarioService.obterAdministradores();
			for (Usuario listaAprovadores : listaAdministradores) {
				SendMessage mensagemParaAdministradores = new SendMessage(Long.parseLong(listaAprovadores.getIdTelegram()),
						"<b>Usuário recusado!</b>\nEste usuário foi recusado por " + nome + " " + sobreNome + ".").parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
				bot.execute(mensagemParaAdministradores);
			}
			SendMessage mensagemParaUsuarioRecusado = new SendMessage(idUsuarioRecusado,
					"<b>Sua solicitação foi negada!</b>\nSolicite ao seu Gestor e tente novamente.").parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
			bot.execute(mensagemParaUsuarioRecusado);
		}
	}

}
