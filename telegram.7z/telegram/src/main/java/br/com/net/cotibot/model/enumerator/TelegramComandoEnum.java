package br.com.net.cotibot.model.enumerator;

import br.com.net.cotibot.comando.MensagemInicioRobo;
import br.com.net.cotibot.comando.TelegramComandoAtivaUsuario;
import br.com.net.cotibot.comando.TelegramComandoCA;
import br.com.net.cotibot.comando.TelegramComandoCancelaSolicitacao;
import br.com.net.cotibot.comando.TelegramComandoChamadoCA;
import br.com.net.cotibot.comando.TelegramComandoChamadoNaoEncontrado;
import br.com.net.cotibot.comando.TelegramComandoEventosAberto;
import br.com.net.cotibot.comando.TelegramComandoMeuNumero;
import br.com.net.cotibot.comando.TelegramComandoOrdensPfc;
import br.com.net.cotibot.comando.TelegramComandoOrdensPfcCoti;
import br.com.net.cotibot.comando.TelegramComandoRecusaUsuario;
import br.com.net.cotibot.comando.TelegramComandoSolicitaAcesso;
import br.com.net.cotibot.mensagem.MensagemListaComandosDisponiveis;
import br.com.net.cotibot.mensagem.MensagemPadrao;
import br.com.net.cotibot.mensagem.MensagemPendenteAtivacao;
import br.com.net.cotibot.mensagem.MensagemUsuarioConstaAtivo;
import br.com.net.cotibot.service.TelegramComandoService;

public enum TelegramComandoEnum {
	ATIVA_USUARIO("/ativarusuario"), FALA_ROBO("/falarobo"), EVENTOS_ABERTOS("/eventosabertos"), SOLICITA_ACESSO(
			"/acesso"), RECUSAR_USUARIO("/recusarusuario"), MEU_NUMERO("/enviar meu número"), CANCELAR_SOLICITACAO(
					"/cancelar"), PFC("/ordenspfc"), PFC_COTI("/ordenspfcoti"), CHAMADO_CA(
							"/chamadoca"), SOLICITACAO_CA(
									"/solicitacao"), INCIDENTE_CA("/incidente"), INICIO("/start"), CHAMADO_NAO_ENCONTRADO("/chamadonaoencontrado"), VAZIO("/vazio");

	public static TelegramComandoEnum get(String nome) {
		for (TelegramComandoEnum obj : TelegramComandoEnum.values()) {
			if (obj.getNome().equalsIgnoreCase(nome))
				return obj;
		}
		return VAZIO;
	}

	public static TelegramComandoService getImplementacao(String comando, Long validaUsuario,
			Long verificaUsuarioInativo, Long verificaUsuarioAtivo) {
		if (comando.contains(ATIVA_USUARIO.getNome())) {

			if (validaUsuario != 0 && verificaUsuarioAtivo == 1) {
				return new TelegramComandoAtivaUsuario();
			} else {
				return new MensagemPadrao();
			}
		} else if (comando.contains(RECUSAR_USUARIO.getNome())) {
			if (validaUsuario != 0 && verificaUsuarioAtivo == 1) {
				return new TelegramComandoRecusaUsuario();
			} else {
				return new MensagemPadrao();
			}
		} else if (comando.contains(CHAMADO_NAO_ENCONTRADO.getNome())) {
			if (validaUsuario != 0 && verificaUsuarioAtivo == 1) {
				return new TelegramComandoChamadoNaoEncontrado();
			} else {
				return new MensagemPadrao();
			}
		} else if (comando.contains(SOLICITACAO_CA.getNome()) || comando.contains(INCIDENTE_CA.getNome())) {
			if (validaUsuario != 0 && verificaUsuarioAtivo == 1) {
				return new TelegramComandoCA();
			} else {
				return new MensagemPadrao();
			}
		} else {
			switch (get(comando)) {
			case SOLICITA_ACESSO:
				if (validaUsuario == 0) {
					return new TelegramComandoSolicitaAcesso();
				} else {
					if (verificaUsuarioAtivo == 1) {
						return new MensagemUsuarioConstaAtivo();
					} else {
						return new MensagemPendenteAtivacao();
					}
				}
			case CANCELAR_SOLICITACAO:

				return new TelegramComandoCancelaSolicitacao();
			case EVENTOS_ABERTOS:
				if (validaUsuario != 0 && verificaUsuarioAtivo == 1) {
					return new TelegramComandoEventosAberto();
				} else {
					return new MensagemPadrao();
				}
			case CHAMADO_CA:
				if (validaUsuario != 0 && verificaUsuarioAtivo == 1) {
					return new TelegramComandoChamadoCA();
				} else {
					return new MensagemPadrao();
				}
			case PFC:
				if (validaUsuario != 0 && verificaUsuarioAtivo == 1) {
					return new TelegramComandoOrdensPfc();
				} else {
					return new MensagemPadrao();
				}
			case PFC_COTI:
				if (validaUsuario != 0 && verificaUsuarioAtivo == 1) {
					return new TelegramComandoOrdensPfcCoti();
				} else {
					return new MensagemPadrao();
				}
			case MEU_NUMERO:
				if (validaUsuario == 0) {
					return new TelegramComandoMeuNumero();
				} else {
					if (verificaUsuarioAtivo == 1) {
						return new MensagemUsuarioConstaAtivo();
					} else {
						return new MensagemPendenteAtivacao();
					}
				}
			case INICIO:
				if (validaUsuario == 0) {
					return new MensagemPadrao();
				} else {
					if (verificaUsuarioAtivo == 1) {
						return new MensagemInicioRobo();
					} else {
						return new MensagemPendenteAtivacao();
					}
				}
			default:
				if (validaUsuario == 0) {
					return new MensagemPadrao();
				} else {
					if (verificaUsuarioAtivo == 1) {
						return new MensagemListaComandosDisponiveis();
					} else {
						return new MensagemPendenteAtivacao();
					}
				}
			}
		}

	}

	String nome;

	public String getNome() {
		return nome;
	}

	TelegramComandoEnum(String nome) {
		this.nome = nome;
	}

	public static TelegramComandoService getImplementacaoEventosAbertos() {
		return new TelegramComandoEventosAberto();
	}

	public static TelegramComandoService getImplementacaoPfc() {
		return new TelegramComandoOrdensPfc();
	}

	public static TelegramComandoService getComandosDisponiveis() {
		return new MensagemInicioRobo();
	}
}
