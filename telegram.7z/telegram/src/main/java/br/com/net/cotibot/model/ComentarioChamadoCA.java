package br.com.net.cotibot.model;

public class ComentarioChamadoCA {
    private int id;

    private String tipoStatusChamado;

    private String comentario;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTipoStatusChamado() {
		return tipoStatusChamado;
	}

	public void setTipoStatusChamado(String tipoStatusChamado) {
		this.tipoStatusChamado = tipoStatusChamado;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
    
}
