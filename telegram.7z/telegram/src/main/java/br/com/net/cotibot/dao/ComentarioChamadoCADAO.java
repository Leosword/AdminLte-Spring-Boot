package br.com.net.cotibot.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import br.com.net.cotibot.model.ComentarioChamadoCA;
import br.com.net.cotibot.rowmapper.ComentarioChamadoCARowMapper;
import br.com.net.cotibot.sqlcodetranslator.CustomSQLErrorCodeTranslator;

@Repository
public class ComentarioChamadoCADAO {

    private JdbcTemplate jdbcTemplate;

    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    SimpleJdbcInsert simpleJdbcInsert;

    @Autowired
    public void setDataSource(final DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
        final CustomSQLErrorCodeTranslator customSQLErrorCodeTranslator = new CustomSQLErrorCodeTranslator();
        jdbcTemplate.setExceptionTranslator(customSQLErrorCodeTranslator);

        namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
        simpleJdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("tb_telegram_comentario_chamado");

    }
    
   /* public List<ComentarioChamadoCA> getComentarioChamado(final String tipoStatusChamado) {
    	return jdbcTemplate.query("SELECT * FROM tb_telegram_comentario_chamado "
    			+ "WHERE tp_status_chamado = '" + tipoStatusChamado + "'", new ComentarioChamadoCARowMapper());
    }*/
    
    public ComentarioChamadoCA getComentarioChamado(final String tipoStatusChamado) {
        final String query = "SELECT * FROM tb_telegram_comentario_chamado WHERE tp_status_chamado = ?";
        return jdbcTemplate.queryForObject(query, new Object[] { tipoStatusChamado }, new ComentarioChamadoCARowMapper());
    }
}
