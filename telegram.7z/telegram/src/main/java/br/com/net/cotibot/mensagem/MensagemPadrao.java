package br.com.net.cotibot.mensagem;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.service.TelegramComandoService;

public class MensagemPadrao extends TelegramComandoService {

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String message) {
		SendMessage respostaPadrao = new SendMessage(chatId,
				"<b>Você não está cadastrado!</b>\nPara solicitar o cadastro clique no botao abaixo:.")
						.parseMode(ParseMode.HTML).replyMarkup(getBotaoAcesso());
		bot.execute(respostaPadrao);
	}

}
