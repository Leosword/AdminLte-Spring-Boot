package br.com.net.cotibot.comando;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.service.TelegramComandoService;

public class TelegramComandoChamadoCA extends TelegramComandoService {

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		SendMessage request = new SendMessage(chatId, "<b>O que você deseja consultar?:</b>").parseMode(ParseMode.HTML)
				.replyMarkup(getMarkupInlineTpChamadoCA());
		bot.execute(request);

	}

}
