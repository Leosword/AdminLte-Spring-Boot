package br.com.net.cotibot.comando;

import java.util.List;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;
import br.com.net.cotibot.dao.EventosDAO;
import br.com.net.cotibot.model.Eventos;
import br.com.net.cotibot.service.TelegramComandoService;

public class TelegramComandoEventosAberto extends TelegramComandoService {
	
	private EventosDAO eventosDAO;

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		eventosDAO = AutoWiringSpringBeanJobFactory.getBean(EventosDAO.class);
		
		List<Eventos> eventos = eventosDAO.getEventos();
		StringBuilder listaEventos = new StringBuilder();
		for (Eventos iterateEventos : eventos) {
			listaEventos.append("<i>Eventos Abertos Diário de Bordo</i>\n\n<b>TRATADOS</b>= " + iterateEventos.getTratados().toString()
					+ "\n<b>NÃO TRATADOS</b>= " + iterateEventos.getNaoTratados().toString() + "\n");
		}
		SendMessage mensagem = new SendMessage(chatId, listaEventos.toString())
				.parseMode(ParseMode.HTML).replyMarkup(getMarkupInlineVoltar());
		bot.execute(mensagem);
	}

}
