package br.com.net.cotibot.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pengrad.telegrambot.UpdatesListener;
import com.pengrad.telegrambot.model.Message;
import com.pengrad.telegrambot.model.Update;

import br.com.net.cotibot.dao.ChamadoCAUsuarioDAO;
import br.com.net.cotibot.model.ChamadoCAUsuario;
import br.com.net.cotibot.model.enumerator.SolicitacaoChamadoEnum;
import br.com.net.cotibot.model.enumerator.TelegramComandoEnum;
import br.com.net.cotibot.model.enumerator.TipoChamadoEnum;

@Component
public class CotiBotListenerService implements UpdatesListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(CotiBotListenerService.class);
	@Autowired
	private UsuarioService usuarioService;
	
	@Autowired
	private ChamadoCAUsuarioDAO chamadoCAUsuarioDAO;

	@Override
	public int process(List<Update> updates) {
		for (Update update : updates) {
			operacaoComando(update);
		}
		return UpdatesListener.CONFIRMED_UPDATES_ALL;
	}

	private void operacaoComando(Update update) {
		try {			
			boolean isCallBack = false;
			Message message = update.message();
			
			if(message == null)	{
				isCallBack = true;
				if(update.callbackQuery() != null){				
					message = update.callbackQuery().message();
				}
			}
			
			if (message != null) {
				
				Long chatId = message.chat().id();
				Integer idUsuario = isCallBack ? update.callbackQuery().from().id() : message.from().id();
				String nome = isCallBack ? update.callbackQuery().from().firstName() : message.from().firstName();
				String sobreNome = isCallBack ? update.callbackQuery().from().lastName() : message.from().lastName();
				String texto = isCallBack ? update.callbackQuery().data() : message.text();
				String telefone = "vazio";
				
				if (message.contact() != null) {
					telefone = message.contact().phoneNumber();
					texto = "/Enviar meu número";
				}
				
				if(texto == null){
					texto = "vazio";
				}
				
				List<ChamadoCAUsuario> validaUltimaSolicitacao = chamadoCAUsuarioDAO.validaUltimaSolicitacao(Long.parseLong(idUsuario.toString()));
				if(validaUltimaSolicitacao.size() != 0){				
					for (ChamadoCAUsuario chamadoCAUsuario : validaUltimaSolicitacao) {				
						if(chamadoCAUsuario.getChamadoRespondido() == null){
							chamadoCAUsuario.setChamadoRespondido(SolicitacaoChamadoEnum.SUCESSO.getNome());
						}
						if(chamadoCAUsuario.getChamadoRespondido().equals("pendente")){				
							if (texto.matches("[0-9]+") && texto.length() > 2) {
								String tipoChamado = chamadoCAUsuario.getTipoChamado();
								if(tipoChamado.equals(TipoChamadoEnum.INCIDENTE.getLabel())){
									texto = "/incidente " + texto.trim() + " " + chamadoCAUsuario.getId();
								}else{
									texto = "/solicitacao " + texto.trim() + " " + chamadoCAUsuario.getId();
								}					
							}else{
								texto = "/chamadoNaoEncontrado " + texto.trim() + " " + chamadoCAUsuario.getId();
							}
						}
					}
				}
				
				if (texto.contains("/")) {
					Long validaUsuario = usuarioService.validaUsuario(Long.parseLong("" + idUsuario + ""));
					Long verificaUsuarioInativo = usuarioService
							.verificaUsuarioInativo(Long.parseLong("" + idUsuario + ""));
					Long verificaUsuarioAtivo = usuarioService.verificaUsuarioAtivo(Long.parseLong("" + idUsuario + ""));
					
					TelegramComandoService comando = TelegramComandoEnum.getImplementacao(texto.toLowerCase(), validaUsuario,
							verificaUsuarioInativo, verificaUsuarioAtivo);
					
					comando.executa(texto.toLowerCase(), "" + chatId + "", "" + idUsuario + "", nome, sobreNome, telefone);
				}			
			}		
		} catch (Exception e) {
			LOGGER.error(e.toString());
		}
	}
}
