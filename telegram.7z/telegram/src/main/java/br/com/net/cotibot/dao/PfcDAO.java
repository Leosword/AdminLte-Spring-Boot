package br.com.net.cotibot.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import br.com.net.cotibot.model.Pfc;
import br.com.net.cotibot.rowmapper.PfcRowMapper;
import br.com.net.cotibot.sqlcodetranslator.CustomSQLErrorCodeTranslator;

@Repository
public class PfcDAO {

	private JdbcTemplate jdbcTemplate;

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private SimpleJdbcInsert simpleJdbcInsert;

	@Autowired
	public void setDataSource(final DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		final CustomSQLErrorCodeTranslator customSQLErrorCodeTranslator = new CustomSQLErrorCodeTranslator();
		jdbcTemplate.setExceptionTranslator(customSQLErrorCodeTranslator);

		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
		simpleJdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("tb_telegram_vol_ordem");

	}

	public List<Pfc> getOrdens() {
		return jdbcTemplate.query(
				"SELECT * FROM tb_telegram_vol_ordem WHERE id_volume_ordens IN (SELECT MAX(id_volume_ordens) FROM tb_telegram_vol_ordem WHERE fl_lido IS NULL GROUP BY nm_base )",
				new PfcRowMapper());
	}
	
	public List<Pfc> getOrdensAtualizadas() {
		return jdbcTemplate.query(
				"SELECT * FROM tb_telegram_vol_ordem WHERE id_volume_ordens IN (SELECT MAX(id_volume_ordens) FROM tb_telegram_vol_ordem GROUP BY nm_base )",
				new PfcRowMapper());
	}
	
	public int marcarLinhaLida(final int id) {
        return jdbcTemplate.update("UPDATE tb_telegram_vol_ordem SET fl_lido = 1 WHERE id_volume_ordens ="+ id);
    }
}
