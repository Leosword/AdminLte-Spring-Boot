package br.com.net.cotibot;

import javax.sql.DataSource;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import br.com.net.cotibot.service.RunBotService;

@Configuration
public class SpringJdbcConfig {
	
	@Bean
	public TaskExecutor taskExecutor() {
	    return new SimpleAsyncTaskExecutor();
	}
	
	@Bean
	public CommandLineRunner schedulingRunner(final TaskExecutor executor) {
	    return new CommandLineRunner() {
	        public void run(String... args) throws Exception {
	            executor.execute(new RunBotService());
	        }
	    };
	}
	
    @Bean
    public DataSource mysqlDataSource() {
        final DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://10.29.220.19:3381/coti_prd");
        dataSource.setUsername("root");
        dataSource.setPassword("#nettools@");

        return dataSource;
    }
}
