package br.com.net.cotibot.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import br.com.net.cotibot.model.ChamadoCAUsuario;
import br.com.net.cotibot.rowmapper.ChamadoCAUsuarioRowMapper;
import br.com.net.cotibot.sqlcodetranslator.CustomSQLErrorCodeTranslator;

@Repository
public class ChamadoCAUsuarioDAO {

    private JdbcTemplate jdbcTemplate;

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private SimpleJdbcInsert simpleJdbcInsert;

    @Autowired
    public void setDataSource(final DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
        final CustomSQLErrorCodeTranslator customSQLErrorCodeTranslator = new CustomSQLErrorCodeTranslator();
        jdbcTemplate.setExceptionTranslator(customSQLErrorCodeTranslator);

        namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
        simpleJdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("tb_telegram_tipo_chamado_ca_usuario");

    }

    public List<ChamadoCAUsuario> validaUltimaSolicitacao(final Long idTelegram) {
        return jdbcTemplate.query("SELECT * FROM tb_telegram_tipo_chamado_ca_usuario "
        		+ "WHERE id_tipo_chamado_ca IN (SELECT MAX(id_tipo_chamado_ca) "
        		+ "FROM tb_telegram_tipo_chamado_ca_usuario "
        		+ "WHERE id_usuario_telegram = " + idTelegram + " )", new ChamadoCAUsuarioRowMapper());
    }
    
    public List<ChamadoCAUsuario> validaEmailEnviado(final String numChamado) {
    	return jdbcTemplate.query("SELECT * FROM tb_telegram_tipo_chamado_ca_usuario "
    			+ "WHERE num_chamado = '" + numChamado + "'", new ChamadoCAUsuarioRowMapper());
    }

    public int adicionaUsuarioCA(final ChamadoCAUsuario chamadoCAusuario, String situacaoChamado) {
        final Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("tp_chamado", chamadoCAusuario.getTipoChamado());
        parameters.put("id_usuario_telegram", chamadoCAusuario.getIdUsuario());
        parameters.put("ds_chamado_respondido", situacaoChamado);

        return simpleJdbcInsert.execute(parameters);
    }
    
    public int atualizaStatusChamado(final String situacao, final String id, String numeroChamado) {
        return jdbcTemplate.update("UPDATE tb_telegram_tipo_chamado_ca_usuario SET ds_chamado_respondido = '" + situacao + "', num_chamado = '" + numeroChamado + "' WHERE id_tipo_chamado_ca ="+ id);
    }
    
    public int atualizaEmailChamado(final String id) {
    	return jdbcTemplate.update("UPDATE tb_telegram_tipo_chamado_ca_usuario SET ds_situacao_email = 'enviado' WHERE id_tipo_chamado_ca ="+ id);
    }
}
