package br.com.net.cotibot.comando;

import java.util.List;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;
import br.com.net.cotibot.model.Usuario;
import br.com.net.cotibot.model.enumerator.TelegramComandoEnum;
import br.com.net.cotibot.service.TelegramComandoService;
import br.com.net.cotibot.service.UsuarioService;

public class TelegramComandoAtivaUsuario extends TelegramComandoService {
	
	private UsuarioService usuarioService = AutoWiringSpringBeanJobFactory.getBean(UsuarioService.class);

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		String[] splitTexto = texto.split(" ");
		String idUsuarioDesativado = splitTexto[1];									
		Usuario retornoUsuario = usuarioService.getUsuario(Long.parseLong(idUsuarioDesativado));
		
		if(usuarioService.verificaUsuarioAtivo(Long.parseLong(idUsuarioDesativado)) == 1){
			SendMessage mensagemParaUsuarioInativo = new SendMessage(chatId,
					"<b>Usuário já está ativado!</b>\nEste usuário foi ativado por " + retornoUsuario.getAprovador() + ".").parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
			bot.execute(mensagemParaUsuarioInativo);
		}else{
			usuarioService.ativaUsuario(retornoUsuario.getId(), nome, sobreNome);
			List<Usuario> listaAdministradores = usuarioService.obterAdministradores();
			for (Usuario listaAprovadores : listaAdministradores) {
				SendMessage mensagemParaAdministradores = new SendMessage(Integer.parseInt(listaAprovadores.getIdTelegram()),
						"<b>Usuário ativado com sucesso!</b>\nEste usuário foi ativado por " + nome + " " + sobreNome + ".").parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
				bot.execute(mensagemParaAdministradores);
			}
			SendMessage mensagemParaUsuarioAtivado = new SendMessage(retornoUsuario.getIdTelegram(),
					"<b>Seu usuário foi ativado com sucesso!").parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
			bot.execute(mensagemParaUsuarioAtivado);
			TelegramComandoEnum.getComandosDisponiveis().executa(null, retornoUsuario.getIdTelegram(), null, null, null, null);
		}
		
	}

}
