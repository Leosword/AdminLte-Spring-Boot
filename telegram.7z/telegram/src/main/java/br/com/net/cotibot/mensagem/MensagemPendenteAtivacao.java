package br.com.net.cotibot.mensagem;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.service.TelegramComandoService;

public class MensagemPendenteAtivacao extends TelegramComandoService {

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String message) {
		SendMessage request = new SendMessage(idUsuario,
				"<b>Atenção!</b>\nSeu usuário está pendente de aprovação.")
						.parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
		bot.execute(request);
	}

}
