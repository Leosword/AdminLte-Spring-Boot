package br.com.net.cotibot.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import br.com.net.cotibot.model.Usuario;
import br.com.net.cotibot.rowmapper.UsuarioRowMapper;
import br.com.net.cotibot.sqlcodetranslator.CustomSQLErrorCodeTranslator;

@Repository
public class UsuarioDAO {

    private JdbcTemplate jdbcTemplate;

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private SimpleJdbcInsert simpleJdbcInsert;

    @Autowired
    public void setDataSource(final DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
        final CustomSQLErrorCodeTranslator customSQLErrorCodeTranslator = new CustomSQLErrorCodeTranslator();
        jdbcTemplate.setExceptionTranslator(customSQLErrorCodeTranslator);

        namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
        simpleJdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("tb_telegram_usuario");

    }

    public int getCountUsuarios() {
        return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM tb_telegram_usuario", Integer.class);
    }

    public Long validaUsuario(Long idTelegram) {
        return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM tb_telegram_usuario where id_telegram = "+idTelegram, Long.class);
    }
    
    public Long verificaUsuarioInativo(Long idTelegram) {
    	return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM tb_telegram_usuario where id_telegram = "+idTelegram+" and fl_status = 0", Long.class);
    }
    public Long verificaUsuarioAtivo(Long idTelegram) {
    	return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM tb_telegram_usuario where id_telegram = "+idTelegram+" and fl_status = 1", Long.class);
    }
    
    public List<Usuario> listaAdministradores() {
    	return jdbcTemplate.query("SELECT * FROM tb_telegram_usuario where nm_perfil = 'Administrador'", new UsuarioRowMapper());
    }
    
    public Usuario getUsuario(final Long idTelegram) {
        final String query = "SELECT * FROM tb_telegram_usuario WHERE id_telegram = ?";
        return jdbcTemplate.queryForObject(query, new Object[] { idTelegram }, new UsuarioRowMapper());
    }
    
    public int ativaUsuario(final int id, String nome, String sobreNome) {
        return jdbcTemplate.update("UPDATE tb_telegram_usuario set fl_status = 1, nm_aprovador = '" + nome + " " + sobreNome + "' where id ="+ id);
    }
    
    public int removeUsuario(final int id) {
    	return jdbcTemplate.update("DELETE FROM tb_telegram_usuario where id ="+ id);
    }

    public int adicionaUsuario(final Usuario usuario) {
        final Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("nm_usuario", usuario.getNome());
        parameters.put("nm_sobrenome", usuario.getSobrenome());
        parameters.put("id_telegram", usuario.getIdTelegram());
        parameters.put("fl_status", 0);
        parameters.put("num_telefone", usuario.getTelefone());
        parameters.put("nm_perfil", "Usuario");
        parameters.put("nm_aprovador", null);

        return simpleJdbcInsert.execute(parameters);
    }
}
