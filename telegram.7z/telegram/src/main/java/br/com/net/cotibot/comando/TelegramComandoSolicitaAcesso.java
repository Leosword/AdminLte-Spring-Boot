package br.com.net.cotibot.comando;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.service.TelegramComandoService;

public class TelegramComandoSolicitaAcesso extends TelegramComandoService {

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		SendMessage request = new SendMessage(idUsuario,
				"<b>Atenção!</b>\nPara interagir com o robo é necessario enviar o numero do seu telefone clicando em <b>'Enviar meu número.'</b>")
						.parseMode(ParseMode.HTML).replyMarkup(getSolicitaTelefoneKeyboard());
		bot.execute(request);
	}

}
