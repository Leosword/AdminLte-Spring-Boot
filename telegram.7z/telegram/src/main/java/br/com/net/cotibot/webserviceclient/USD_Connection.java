package br.com.net.cotibot.webserviceclient;

import java.net.MalformedURLException;

import javax.xml.rpc.ServiceException;

import org.springframework.stereotype.Component;

@Component
public class USD_Connection {
	USD_WebServiceSoap usd;

	public USD_Connection() {
		/*URL PRD*/
		String endpoint = "http://10.208.255.124:8080/axis/services/USD_R11_WebService?wsdl";
		/*URL HOM*/
		//String endpoint = "http://10.208.255.10:8080/axis/services/USD_R11_WebService?wsdl";
		USD_WebServiceLocator ws = new USD_WebServiceLocator();
		java.net.URL url;
		try {
			url = new java.net.URL(endpoint);
			usd = ws.getUSD_WebServiceSoap(url);

		} catch (MalformedURLException | ServiceException e) {
			e.printStackTrace();
		}
	}

	public USD_WebServiceSoap getUsd() {
		return usd;
	}

	public void setUsd(USD_WebServiceSoap usd) {
		this.usd = usd;
	}

}
