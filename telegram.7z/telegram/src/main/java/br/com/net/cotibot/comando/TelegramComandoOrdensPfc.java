package br.com.net.cotibot.comando;

import java.text.SimpleDateFormat;
import java.util.List;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;
import br.com.net.cotibot.dao.PfcDAO;
import br.com.net.cotibot.model.Pfc;
import br.com.net.cotibot.service.TelegramComandoService;

public class TelegramComandoOrdensPfc extends TelegramComandoService {

	private PfcDAO pfcDAO;

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		pfcDAO = AutoWiringSpringBeanJobFactory.getBean(PfcDAO.class);

		List<Pfc> ordens = pfcDAO.getOrdens();
		if (ordens.size() > 0) {
			StringBuilder listaOrdens = new StringBuilder();
			String dataColeta = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(ordens.iterator().next().getDtColeta());
			listaOrdens.append("<b>Cadeia de Ativação</b>\n");
			listaOrdens.append("<b>Data/Hora Status</b>: "+ dataColeta +"\n.................................................\n");
			for (Pfc iteraOrdens : ordens) {
				pfcDAO.marcarLinhaLida(iteraOrdens.getId());
				listaOrdens.append("<b>" + iteraOrdens.getNomeBase() + "</b>: Pend(" + iteraOrdens.getVlPendenteEnvio()
						+ ") | Env(" + iteraOrdens.getVlEnviada() + ") | Proc(" + iteraOrdens.getVlProcessando()
						+ ")\n");
			}
			SendMessage mensagem = new SendMessage(chatId, listaOrdens.toString()).parseMode(ParseMode.HTML);
			if (telefone.equals("schedule")) {
				botInforma.execute(mensagem);
			} else {
				bot.execute(mensagem);
			}
		}

	}

}
