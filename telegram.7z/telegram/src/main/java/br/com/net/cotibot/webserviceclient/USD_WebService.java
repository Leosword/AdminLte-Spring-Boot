/**
 * USD_WebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.net.cotibot.webserviceclient;

public interface USD_WebService extends javax.xml.rpc.Service {
    public java.lang.String getUSD_WebServiceSoapAddress();

    public br.com.net.cotibot.webserviceclient.USD_WebServiceSoap getUSD_WebServiceSoap() throws javax.xml.rpc.ServiceException;

    public br.com.net.cotibot.webserviceclient.USD_WebServiceSoap getUSD_WebServiceSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
