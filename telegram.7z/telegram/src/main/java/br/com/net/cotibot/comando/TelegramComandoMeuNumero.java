package br.com.net.cotibot.comando;

import java.util.List;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;
import br.com.net.cotibot.model.Usuario;
import br.com.net.cotibot.service.TelegramComandoService;
import br.com.net.cotibot.service.UsuarioService;

public class TelegramComandoMeuNumero extends TelegramComandoService {
	
	private UsuarioService usuarioService = AutoWiringSpringBeanJobFactory.getBean(UsuarioService.class);

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		
		usuarioService.adicionaUsuario("" + idUsuario + "", nome, sobreNome, telefone);

		SendMessage mensagemParaNovoUsuario = new SendMessage(idUsuario,
				"<b>Usuario Cadastrado!</b>\nSeu usuário foi cadastrado e está pendente de Ativação!:\nAguarde o processo de análise dos nossos Administradores")
						.parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
		bot.execute(mensagemParaNovoUsuario);

		List<Usuario> listaAdministradores = usuarioService.obterAdministradores();

		for (Usuario listaAprovadores : listaAdministradores) {
			SendMessage mensagemParaAdministradores = new SendMessage(
					Integer.parseInt(listaAprovadores.getIdTelegram()),
					"<b>Aprovação pendente!</b>\nDados do usuário:\nidTelegram:" + idUsuario + "\nNome:"
							+ nome + " " + sobreNome + "\nTelefone:" + telefone	+ ".").parseMode(ParseMode.HTML)
									.replyMarkup(getAtivaUsuarioKeyboard("" + idUsuario +  ""));
			bot.execute(mensagemParaAdministradores);
		}
		
	}

}
