package br.com.net.cotibot.comando;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.model.enumerator.TelegramComandoEnum;
import br.com.net.cotibot.service.TelegramComandoService;

public class MensagemInicioRobo extends TelegramComandoService {

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		TelegramComandoEnum[] comandosDisponiveis = TelegramComandoEnum.values();
		StringBuilder listacomandos = new StringBuilder();
		for (TelegramComandoEnum telegramComandoEnum : comandosDisponiveis) {
			listacomandos.append(telegramComandoEnum.getNome() + "\n");
		}

		SendMessage request = new SendMessage(chatId,
				"<b>Bem vindo ao Autoatendimento COTI.</b>\n........................................................\n<i>Selecione abaixo a opção desejada:</i>")
						.parseMode(ParseMode.HTML).replyMarkup(getMarkupInline());
		bot.execute(request);

	}

}
