package br.com.net.cotibot.util;

import java.text.SimpleDateFormat;

import org.springframework.stereotype.Component;

@Component
public class FormataData {
	public String formataData(String data) {
		if(data.isEmpty() || data == null){
			return "vazio";
		}
		String dataConvertida = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Long.parseLong(data) * 1000L);
		if(dataConvertida.contains("1970")){
			return "vazio";
		}
		return dataConvertida;
	}
}
