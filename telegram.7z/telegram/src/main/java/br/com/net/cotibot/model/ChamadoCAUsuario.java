package br.com.net.cotibot.model;

public class ChamadoCAUsuario {
    private int id;

    private String tipoChamado;

    private String idUsuario;
    
    private String chamadoRespondido;
    
    private String situacaoEmail;
    
    private String numeroChamado;

	public int getId() {
        return id;
    }

    public void setId(final int id) {
        this.id = id;
    }

	public String getTipoChamado() {
		return tipoChamado;
	}

	public void setTipoChamado(String tipoChamado) {
		this.tipoChamado = tipoChamado;
	}

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getChamadoRespondido() {
		return chamadoRespondido;
	}

	public void setChamadoRespondido(String chamadoRespondido) {
		this.chamadoRespondido = chamadoRespondido;
	}

	public String getSituacaoEmail() {
		return situacaoEmail;
	}

	public void setSituacaoEmail(String situacaoEmail) {
		this.situacaoEmail = situacaoEmail;
	}

	public String getNumeroChamado() {
		return numeroChamado;
	}

	public void setNumeroChamado(String numeroChamado) {
		this.numeroChamado = numeroChamado;
	}		
	
}
