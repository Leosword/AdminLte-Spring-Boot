package br.com.net.cotibot.comando;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.service.TelegramComandoService;

public class TelegramComandoCancelaSolicitacao extends TelegramComandoService {

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome, String telefone) {
		SendMessage request = new SendMessage(chatId, "<b>Solicitação Cancelada!</b>").parseMode(ParseMode.HTML)
				.replyMarkup(getRemoveKeyboard());
		bot.execute(request);
	}

}
