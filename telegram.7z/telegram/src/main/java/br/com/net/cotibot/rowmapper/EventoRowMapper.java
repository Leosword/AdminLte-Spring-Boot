package br.com.net.cotibot.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.net.cotibot.model.Eventos;

public class EventoRowMapper implements RowMapper<Eventos> {

    @Override
    public Eventos mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        final Eventos eventos = new Eventos();

        eventos.setTratados(rs.getString("TRATADOS"));
        eventos.setNaoTratados(rs.getString("NAO_TRATADOS"));

        return eventos;
    }
}