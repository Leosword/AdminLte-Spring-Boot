/**
 * 
 */
package br.com.net.cotibot.comando;

import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;

import br.com.net.cotibot.AutoWiringSpringBeanJobFactory;
import br.com.net.cotibot.dao.ChamadoCAUsuarioDAO;
import br.com.net.cotibot.model.enumerator.SolicitacaoChamadoEnum;
import br.com.net.cotibot.service.TelegramComandoService;

/**
 * @author Leandro Celestino 29 de jun de 2017
 *
 */
public class TelegramComandoChamadoNaoEncontrado extends TelegramComandoService {

	private ChamadoCAUsuarioDAO chamadoCAusuarioDAO = AutoWiringSpringBeanJobFactory.getBean(ChamadoCAUsuarioDAO.class);
	String chamado;
	String idUltimaRequisicao = null;

	@Override
	public void executa(String texto, String chatId, String idUsuario, String nome, String sobreNome,
			String numeroChamado) {
		String[] splitTexto = texto.split(" ");
		if (splitTexto.length >= 2) {
			chamado = splitTexto[1];
			idUltimaRequisicao = splitTexto[2];
		}

		SendMessage mensagemComChamado = new SendMessage(chatId,
				"<b>O Chamado " + chamado
						+ " é inválido!</b>\nVerifique o número do chamado e tente novamente.")
								.parseMode(ParseMode.HTML).replyMarkup(getRemoveKeyboard());
		bot.execute(mensagemComChamado);
		SendMessage novaConsulta = new SendMessage(idUsuario, "Deseja realizar uma nova consulta?")
				.parseMode(ParseMode.HTML).replyMarkup(getMarkupInlinePergunta());
		bot.execute(novaConsulta);
		chamadoCAusuarioDAO.atualizaStatusChamado(SolicitacaoChamadoEnum.ERRO.getNome(), idUltimaRequisicao, chamado);
	}
}
