package br.com.net.cotibot.model.enumerator;

public enum TipoChamadoEnum {
	INCIDENTE("I", "Incidente"), SOLICITACAO("R", "Solicitação"), TIPO_INCIDENTE("/incidente",
			"Incidente"), TIPO_SOLICITACAO("/solicitacao", "Solicitação"), TIPO_QUERY_INCIDENTE("/incidentequery",
					"in"), TIPO_QUERY_SOLICITACAO("/solicitacaoquery", "cr"), VAZIO("NA", "Tipo Desconhecido");

	public static TipoChamadoEnum get(String nome) {
		for (TipoChamadoEnum obj : TipoChamadoEnum.values()) {
			if (obj.getNome().equalsIgnoreCase(nome))
				return obj;
		}
		return VAZIO;
	}

	String nome;
	String label;

	public String getNome() {
		return nome;
	}

	public String getLabel() {
		return label;
	}

	TipoChamadoEnum(String nome, String label) {
		this.nome = nome;
		this.label = label;
	}

}
