package br.com.net.cotibot.model.enumerator;

public enum SolicitacaoChamadoEnum {

	SUCESSO("sucesso"), ERRO("erro"), PENDENTE("pendente"), CANCELADO("cancelado");

	public static SolicitacaoChamadoEnum get(String nome) {
		for(SolicitacaoChamadoEnum obj : SolicitacaoChamadoEnum.values()){
			if(obj.getNome().equalsIgnoreCase(nome))
				return obj;
		}
		return null;
	}

	String nome;
	
	public String getNome() {
		return nome;
	}

	SolicitacaoChamadoEnum(String nome) {
		this.nome = nome;
	}
	
}