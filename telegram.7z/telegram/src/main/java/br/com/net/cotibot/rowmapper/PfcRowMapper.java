package br.com.net.cotibot.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.net.cotibot.model.Pfc;

public class PfcRowMapper implements RowMapper<Pfc> {

    @Override
    public Pfc mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        final Pfc pfc = new Pfc();

        pfc.setId(rs.getInt("id_volume_ordens"));
        pfc.setVlPendenteEnvio(rs.getString("vl_pendente_envio"));
        pfc.setVlEnviada(rs.getString("vl_enviada"));
        pfc.setVlProcessando(rs.getString("vl_processando"));
        pfc.setTipoColeta(rs.getString("tp_coleta"));
        pfc.setNomeBase(rs.getString("nm_base"));
        pfc.setDtCadastro(rs.getDate("dt_cadastro"));
        pfc.setDtColeta(rs.getTimestamp("dt_coleta"));

        return pfc;
    }
}