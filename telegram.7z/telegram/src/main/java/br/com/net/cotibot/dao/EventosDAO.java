package br.com.net.cotibot.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import br.com.net.cotibot.model.Eventos;
import br.com.net.cotibot.rowmapper.EventoRowMapper;
import br.com.net.cotibot.sqlcodetranslator.CustomSQLErrorCodeTranslator;

@Repository
public class EventosDAO {

	private JdbcTemplate jdbcTemplate;

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private SimpleJdbcInsert simpleJdbcInsert;

	@Autowired
	public void setDataSource(final DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		final CustomSQLErrorCodeTranslator customSQLErrorCodeTranslator = new CustomSQLErrorCodeTranslator();
		jdbcTemplate.setExceptionTranslator(customSQLErrorCodeTranslator);

		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
		simpleJdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("tb_eventos");

	}

	public List<Eventos> getEventos() {
		return jdbcTemplate.query(
				"SELECT ( SELECT count(1) FROM tb_eventos WHERE id_status = 2 AND id_usuario_tratamento <> 0 AND fl_evento_filho = 0 ) AS TRATADOS, ( SELECT count(1) FROM tb_eventos WHERE id_status = 2 AND id_usuario_tratamento = 0 AND fl_evento_filho = 0 ) AS NAO_TRATADOS",
				new EventoRowMapper());
	}
}
