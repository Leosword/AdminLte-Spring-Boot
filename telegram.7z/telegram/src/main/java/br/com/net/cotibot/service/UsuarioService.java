package br.com.net.cotibot.service;

import java.util.List;

import br.com.net.cotibot.model.Usuario;

/**
 * 
 * @author Leandro Celestino 27 de jun de 2017
 *
 */
public interface UsuarioService {
	Long validaUsuario(Long id);
	Long verificaUsuarioAtivo(Long id);
	Long verificaUsuarioInativo(Long id);
	void adicionaUsuario(String idTelegram, String nome, String sobrenome, String telefone);
	List<Usuario> obterAdministradores();
	Usuario getUsuario(Long idUsuario);
	void ativaUsuario(int id, String nome, String sobreNome);
	void removeUsuario(int id);
}
