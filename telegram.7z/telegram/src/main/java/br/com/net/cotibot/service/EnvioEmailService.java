package br.com.net.cotibot.service;

import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;

import org.springframework.stereotype.Component;

@Component
public class EnvioEmailService {

	public void EnvioEmail(String numeroChamado) throws Exception {
		try{
            String host = "";//host do email aqui
            String from = "";//email aqui
            Properties props = System.getProperties();
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.user", from);
            props.put("mail.smtp.port", "25");
            props.put("mail.smtp.auth", "false");

            String[] to = {"Celestino.Leandro@terceiros.net.com.br", "Jefferson.Ruiz@net.com.br", "Marlon.ColomboFerreira@netservicos.com.br", "Renan.Coelho@netservicos.com.br"};
            
            String mensagem = "Monitoria,<br>";
            mensagem += "O chamado <font color=red>" + numeroChamado + "</font> foi consultado via <b>TELEGRAM</b> e est&aacute com o SLA violado.<br>";
            mensagem += "Favor seguir o escalation para o grupo solucionador.<br><br><br>";
            mensagem += "Atenciosamente<br>COTI & Service Desk.";

            Session session = Session.getDefaultInstance(props, null);
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            InternetAddress[] toAddress = new InternetAddress[to.length];

            for( int i=0; i < to.length; i++ ) {
                toAddress[i] = new InternetAddress(to[i]);
            }

            for( int i=0; i < toAddress.length; i++) {
                message.addRecipient(Message.RecipientType.TO, toAddress[i]);
            }
            
            message.setHeader("Content-type", "text/plan; charset=UTF-8");
            message.setSubject("Priorização Cotilda - Chamado Nº " + numeroChamado + "");
            message.setSentDate(new Date());
            message.setContent(mensagem, "text/html");
            Transport transport = session.getTransport("smtp");
            transport.connect(host, from);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
	}
}
