package br.com.net.cotibot.webserviceclient;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.InputSource;

@Component
public class USD_GetAttribute {

	private String retornoAtributo = "";

	public String retornaAtributo(String result, String attribute_name) {
		try {

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new InputSource(new StringReader(result)));
			Element root = doc.getDocumentElement();
			NodeList udsObjectList = root.getElementsByTagName("UDSObject");
			Element udsObjectElement = (Element) root;

			NodeList attributesList = udsObjectElement.getElementsByTagName("Attributes");
			if (attributesList.getLength() > 0) {
				Element attributesElement = (Element) attributesList.item(0);
				NodeList attributeList = attributesElement.getElementsByTagName("Attribute");

				for (int i = 0; i < attributeList.getLength(); i++) {
					Element attributeElement = (Element) attributeList.item(i);
					NodeList attrNameList = attributeElement.getElementsByTagName("AttrName");

					Element attrNameElement = (Element) attrNameList.item(0);
					Text attrNameText = (Text) attrNameElement.getFirstChild();
					String attrNameString = attrNameText.getNodeValue();
					if (attrNameString.equalsIgnoreCase(attribute_name)) {
						// Each Attribute element will have one AttrValue,
						// though it may be null
						NodeList attrValueList = attributeElement.getElementsByTagName("AttrValue");
						Element attrValueElement = (Element) attrValueList.item(0);
						Text attrValueText = (Text) attrValueElement.getFirstChild();
						if (attrValueText != null)
							retornoAtributo = attrValueText.getNodeValue();
						break;
					}

				}
			}else{
				retornoAtributo = "nao existente";
			}
		} catch (Exception ex) {
			System.out.println("Exception occurred:" + ex.getMessage());
			ex.printStackTrace(System.out);
		}
		return retornoAtributo;
	}
}
